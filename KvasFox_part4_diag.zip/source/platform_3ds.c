/* platform_3ds.c - Nintendo 3DS implementation of platform.h (libctru + citro2d + NDSP).
 * Rendering: citro2d.  Audio: NDSP (needs DSP firmware dump; without it the game runs silently).
 * Assets: romfs:/  Saves: sdmc:/3ds/KvasFox/ */
#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <errno.h>
#include "platform.h"

struct PTex { C3D_Tex tex; Tex3DS_Texture ts; };

static C3D_RenderTarget *s_top, *s_bot;
static C2D_TextBuf s_textbuf, s_measbuf;
static bool s_exit;
static float s_lineh = 30.0f;
static bool s_audio_ok, s_audio_tried;
static bool s_gpu_ready;
static char s_diag_prev[96], s_diag_info[160];

/* ----------------------------------------------------------------------------- lifecycle */
/* ---- diagnostic helpers: every startup step waits for A so we can see which one triggers the crash */
void plat_diag_result(const char *fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    vsnprintf(s_diag_info, sizeof s_diag_info, fmt, ap);
    va_end(ap);
}

void plat_diag(const char *step)
{
    if (!s_gpu_ready) return;
    PInput in;
    do {
        plat_begin_frame(&in);
        plat_target(0);
        plat_text("Kvas Fox - diagnostic build", 10, 8, 0.6f, RGBA(255, 255, 0, 255));
        if (s_diag_prev[0]) {
            char line[140]; snprintf(line, sizeof line, "Done: %s", s_diag_prev);
            plat_text(line, 10, 52, 0.42f, RGBA(120, 255, 120, 255));
        }
        if (s_diag_info[0]) plat_text(s_diag_info, 10, 78, 0.42f, RGBA(120, 255, 120, 255));
        plat_text("NEXT STEP:", 10, 124, 0.5f, RGBA(255, 255, 255, 255));
        plat_text(step, 10, 150, 0.5f, RGBA(255, 255, 255, 255));
        plat_text("Press A to run it", 10, 200, 0.5f, RGBA(255, 255, 0, 255));
        plat_end_frame();
    } while (plat_running() && !(in.down & K_A));
    snprintf(s_diag_prev, sizeof s_diag_prev, "%s", step);
    s_diag_info[0] = 0;
}

/* ----------------------------------------------------------------------------- lifecycle */
bool plat_init(void)
{
    osSetSpeedupEnable(true);                 /* New 3DS: 804 MHz */
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(8192);
    C2D_Prepare();
    s_top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    s_bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    s_textbuf = C2D_TextBufNew(8192);
    s_measbuf = C2D_TextBufNew(1024);
    {   /* measure the real line height of the system font once */
        C2D_Text t; float w, h;
        C2D_TextParse(&t, s_measbuf, "Ag");
        C2D_TextGetDimensions(&t, 1.0f, 1.0f, &w, &h);
        if (h > 4.0f) s_lineh = h;
        C2D_TextBufClear(s_measbuf);
    }
    s_gpu_ready = true;

    plat_diag("1: screens work (the game has started)");
    plat_diag("2: open the game files (romfsInit)");
    Result rrc = romfsInit();
    plat_diag_result("romfsInit returned %08lX (0 = OK)", (unsigned long)rrc);

    plat_diag("3: create the save folder on the SD card");
    errno = 0;
    int m1 = mkdir("sdmc:/3ds", 0777); int e1 = errno;
    errno = 0;
    int m2 = mkdir("sdmc:/3ds/KvasFox", 0777); int e2 = errno;
    plat_diag_result("mkdir results: %d (errno %d), %d (errno %d)  [errno 17 = already exists, fine]", m1, e1, m2, e2);

    plat_diag("4: start sound (NDSP / DSP firmware)");
    plat_audio_init();
    return true;
}

void plat_shutdown(void)
{
    if (s_audio_ok) ndspExit();
    C2D_TextBufDelete(s_textbuf);
    C2D_TextBufDelete(s_measbuf);
    C2D_Fini();
    C3D_Fini();
    gfxExit();
    romfsExit();
}

bool plat_running(void) { return aptMainLoop() && !s_exit; }
void plat_exit_request(void) { s_exit = true; }

/* ----------------------------------------------------------------------------- frame + input */
void plat_begin_frame(PInput *in)
{
    hidScanInput();
    u32 down = hidKeysDown(), held = hidKeysHeld(), up = hidKeysUp();
    static const struct { u32 key; u32 bit; } map[] = {
        { KEY_A, K_A }, { KEY_B, K_B }, { KEY_X, K_X }, { KEY_Y, K_Y }, { KEY_L, K_L }, { KEY_R, K_R },
        { KEY_START, K_START }, { KEY_SELECT, K_SELECT }, { KEY_ZL, K_ZL }, { KEY_ZR, K_ZR },
        { KEY_DUP | KEY_CPAD_UP, K_UP }, { KEY_DDOWN | KEY_CPAD_DOWN, K_DOWN },
        { KEY_DLEFT | KEY_CPAD_LEFT, K_LEFT }, { KEY_DRIGHT | KEY_CPAD_RIGHT, K_RIGHT },
    };
    in->held = in->down = in->up = 0;
    for (unsigned i = 0; i < sizeof map / sizeof map[0]; i++) {
        if (held & map[i].key) in->held |= map[i].bit;
        if (down & map[i].key) in->down |= map[i].bit;
        if (up & map[i].key) in->up |= map[i].bit;
    }
    static int lastx, lasty;
    in->touching = (held & KEY_TOUCH) != 0;
    in->touch_down = (down & KEY_TOUCH) != 0;
    in->touch_up = (up & KEY_TOUCH) != 0;
    if (in->touching) {
        touchPosition tp; hidTouchRead(&tp);
        lastx = tp.px; lasty = tp.py;
    }
    in->tx = lastx; in->ty = lasty;            /* keeps the last position on release */

    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    C2D_TextBufClear(s_textbuf);
    C2D_TargetClear(s_top, C2D_Color32(0, 0, 0, 255));
    C2D_TargetClear(s_bot, C2D_Color32(0, 0, 0, 255));
    C2D_SceneBegin(s_top);
}

void plat_end_frame(void) { C3D_FrameEnd(0); }
void plat_target(int screen) { C2D_SceneBegin(screen ? s_bot : s_top); }

/* ----------------------------------------------------------------------------- textures / drawing */
PTex *plat_tex_load(const char *name)
{
    char path[96];
    snprintf(path, sizeof path, "romfs:/gfx/%s.t3x", name);
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    PTex *t = calloc(1, sizeof *t);
    if (!t) { fclose(f); return NULL; }
    t->ts = Tex3DS_TextureImportStdio(f, &t->tex, NULL, false);
    fclose(f);
    if (!t->ts) { free(t); return NULL; }
    C3D_TexSetFilter(&t->tex, GPU_NEAREST, GPU_NEAREST);
    C3D_TexSetWrap(&t->tex, GPU_CLAMP_TO_EDGE, GPU_CLAMP_TO_EDGE);
    return t;
}

void plat_tex_free(PTex *t)
{
    if (!t) return;
    Tex3DS_TextureFree(t->ts);
    C3D_TexDelete(&t->tex);
    free(t);
}

void plat_blit(PTex *t, int sx, int sy, int sw, int sh, float dx, float dy, float scale, bool flipx, int alpha)
{
    if (!t || alpha <= 0) return;
    float tw = (float)t->tex.width, th = (float)t->tex.height;
    Tex3DS_SubTexture st;
    st.width = (u16)sw; st.height = (u16)sh;
    st.left = sx / tw; st.right = (sx + sw) / tw;
    st.top = 1.0f - sy / th; st.bottom = 1.0f - (sy + sh) / th;
    if (flipx) { float tmp = st.left; st.left = st.right; st.right = tmp; }
    C2D_Image img = { &t->tex, &st };
    if (alpha < 255) {
        C2D_ImageTint tint;
        C2D_AlphaImageTint(&tint, alpha / 255.0f);
        C2D_DrawImageAt(img, dx, dy, 0.5f, &tint, scale, scale);
    } else {
        C2D_DrawImageAt(img, dx, dy, 0.5f, NULL, scale, scale);
    }
}

void plat_rect(float x, float y, float w, float h, uint32_t color) { C2D_DrawRectSolid(x, y, 0.5f, w, h, color); }

void plat_text(const char *s, float x, float y, float scale, uint32_t color)
{
    if (scale <= 0.0f || !s || !*s) return;
    C2D_Text t;
    C2D_TextParse(&t, s_textbuf, s);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, 0.5f, scale, scale, color);
}

float plat_text_w(const char *s, float scale)
{
    if (!s || !*s) return 0.0f;
    C2D_Text t; float w = 0, h = 0;
    C2D_TextBufClear(s_measbuf);
    C2D_TextParse(&t, s_measbuf, s);
    C2D_TextGetDimensions(&t, scale, scale, &w, &h);
    return w;
}
float plat_text_h(float scale) { return s_lineh * scale; }

/* ----------------------------------------------------------------------------- files */
uint8_t *plat_read_file(const char *rel, size_t *size)
{
    char path[160];
    snprintf(path, sizeof path, "romfs:/%s", rel);
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *b = malloc((size_t)n + 4);
    if (!b || fread(b, 1, (size_t)n, f) != (size_t)n) { fclose(f); free(b); return NULL; }
    fclose(f);
    *size = (size_t)n;
    return b;
}
FILE *plat_open_rom(const char *rel)
{
    char path[160];
    snprintf(path, sizeof path, "romfs:/%s", rel);
    return fopen(path, "rb");
}
FILE *plat_open_user(const char *name, bool write)
{
    char path[160];
    snprintf(path, sizeof path, "sdmc:/3ds/KvasFox/%s", name);
    return fopen(path, write ? "wb" : "rb");
}

/* ----------------------------------------------------------------------------- audio (NDSP) */
#define BGM_BUFS 6
#define BGM_CAP 4096
#define SE_CHANNELS 6
#define SE_CAP (22050 * 4)

static ndspWaveBuf s_bgm_wb[BGM_BUFS];
static int16_t *s_bgm_data[BGM_BUFS];
static ndspWaveBuf s_se_wb[SE_CHANNELS];
static int16_t *s_se_data[SE_CHANNELS];
static float s_bgm_vol = 1.0f;
static int s_se_next;

static void set_mix(int ch, float v)
{
    float mix[12] = { 0 };
    mix[0] = mix[1] = v;
    ndspChnSetMix(ch, mix);
}

bool plat_audio_init(void)
{
    if (s_audio_tried) return s_audio_ok;     /* already done (the engine calls this again from audio_init) */
    s_audio_tried = true;
    Result nrc = ndspInit();
    plat_diag_result("ndspInit returned %08lX (0 = OK, otherwise the game runs silent)", (unsigned long)nrc);
    if (R_FAILED(nrc)) { s_audio_ok = false; return false; }   /* no dspfirm.cdc: run without sound */
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    for (int i = 0; i < BGM_BUFS; i++) {
        s_bgm_data[i] = linearAlloc(BGM_CAP * sizeof(int16_t));
        memset(&s_bgm_wb[i], 0, sizeof s_bgm_wb[i]);
        s_bgm_wb[i].status = NDSP_WBUF_DONE;
    }
    for (int i = 0; i < SE_CHANNELS; i++) {
        s_se_data[i] = linearAlloc(SE_CAP * sizeof(int16_t));
        memset(&s_se_wb[i], 0, sizeof s_se_wb[i]);
    }
    s_audio_ok = true;
    return true;
}

static bool wb_free(const ndspWaveBuf *w) { return w->status == NDSP_WBUF_DONE || w->status == NDSP_WBUF_FREE; }

int plat_bgm_free_buffers(void)
{
    if (!s_audio_ok) return 0;
    int n = 0;
    for (int i = 0; i < BGM_BUFS; i++) if (wb_free(&s_bgm_wb[i])) n++;
    return n;
}

void plat_bgm_start(int rate)
{
    if (!s_audio_ok) return;
    ndspChnReset(0);
    ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
    ndspChnSetRate(0, (float)rate);
    ndspChnSetFormat(0, NDSP_FORMAT_MONO_PCM16);
    set_mix(0, s_bgm_vol);
    for (int i = 0; i < BGM_BUFS; i++) s_bgm_wb[i].status = NDSP_WBUF_DONE;
}

void plat_bgm_queue(const int16_t *pcm, int n)
{
    if (!s_audio_ok || n <= 0 || n > BGM_CAP) return;
    for (int i = 0; i < BGM_BUFS; i++) {
        if (!wb_free(&s_bgm_wb[i])) continue;
        memcpy(s_bgm_data[i], pcm, (size_t)n * sizeof(int16_t));
        DSP_FlushDataCache(s_bgm_data[i], (u32)n * sizeof(int16_t));
        s_bgm_wb[i].data_vaddr = s_bgm_data[i];
        s_bgm_wb[i].nsamples = (u32)n;
        s_bgm_wb[i].looping = false;
        ndspChnWaveBufAdd(0, &s_bgm_wb[i]);
        return;
    }
}

void plat_bgm_stop(void)
{
    if (!s_audio_ok) return;
    ndspChnWaveBufClear(0);
    ndspChnReset(0);
    for (int i = 0; i < BGM_BUFS; i++) s_bgm_wb[i].status = NDSP_WBUF_DONE;
}

void plat_bgm_volume(float v)
{
    s_bgm_vol = v < 0 ? 0 : (v > 1 ? 1 : v);
    if (s_audio_ok) set_mix(0, s_bgm_vol);
}

bool plat_bgm_busy(void)
{
    if (!s_audio_ok) return false;
    for (int i = 0; i < BGM_BUFS; i++) if (!wb_free(&s_bgm_wb[i])) return true;
    return false;
}

void plat_se_play(const int16_t *pcm, int n, int rate, float vol, float pitch)
{
    if (!s_audio_ok || n <= 0) return;
    if (n > SE_CAP) n = SE_CAP;
    int slot = s_se_next; s_se_next = (s_se_next + 1) % SE_CHANNELS;
    int ch = 1 + slot;
    ndspChnReset(ch);
    ndspChnSetInterp(ch, NDSP_INTERP_LINEAR);
    ndspChnSetRate(ch, (float)rate * (pitch > 0.1f ? pitch : 1.0f));
    ndspChnSetFormat(ch, NDSP_FORMAT_MONO_PCM16);
    set_mix(ch, vol < 0 ? 0 : (vol > 1 ? 1 : vol));
    memcpy(s_se_data[slot], pcm, (size_t)n * sizeof(int16_t));
    DSP_FlushDataCache(s_se_data[slot], (u32)n * sizeof(int16_t));
    memset(&s_se_wb[slot], 0, sizeof s_se_wb[slot]);
    s_se_wb[slot].data_vaddr = s_se_data[slot];
    s_se_wb[slot].nsamples = (u32)n;
    s_se_wb[slot].looping = false;
    ndspChnWaveBufAdd(ch, &s_se_wb[slot]);
}
