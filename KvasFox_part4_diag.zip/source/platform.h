/* platform.h - the only interface between the portable game engine and the system.
 * Implemented by platform_3ds.c (citro2d / ndsp / romfs) and platform_host.c (PC test build). */
#ifndef PLATFORM_H
#define PLATFORM_H

#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>

typedef struct PTex PTex;

/* button bits */
enum {
    K_A = 1 << 0, K_B = 1 << 1, K_X = 1 << 2, K_Y = 1 << 3,
    K_L = 1 << 4, K_R = 1 << 5, K_START = 1 << 6, K_SELECT = 1 << 7,
    K_UP = 1 << 8, K_DOWN = 1 << 9, K_LEFT = 1 << 10, K_RIGHT = 1 << 11,
    K_ZL = 1 << 12, K_ZR = 1 << 13
};

typedef struct {
    uint32_t held, down, up;          /* digital buttons (circle pad is merged into K_UP.. K_RIGHT) */
    bool touching, touch_down, touch_up;
    int tx, ty;                       /* touch position on the bottom screen (320x240) */
} PInput;

/* colours are packed R | G<<8 | B<<16 | A<<24 (same as C2D_Color32) */
#define RGBA(r, g, b, a) ((((uint32_t)(r)) & 255u) | ((((uint32_t)(g)) & 255u) << 8) | ((((uint32_t)(b)) & 255u) << 16) | ((((uint32_t)(a)) & 255u) << 24))

#define SCR_W 400
#define SCR_H 240
#define BSCR_W 320
#define BSCR_H 240

bool plat_init(void);
void plat_diag(const char *step);              /* DIAGNOSTIC BUILD: shows the next startup step, waits for A */
void plat_diag_result(const char *fmt, ...);   /* DIAGNOSTIC BUILD: text shown on the next diag screen */
void plat_shutdown(void);
bool plat_running(void);
void plat_exit_request(void);            /* ask the main loop to stop (Exit button) */                 /* false when the user quits via HOME menu */
void plat_begin_frame(PInput *in);       /* poll input + start rendering */
void plat_end_frame(void);               /* finish rendering, swap, vsync */

void plat_target(int screen);            /* 0 = top (400x240), 1 = bottom (320x240) */
PTex *plat_tex_load(const char *name);   /* loads romfs:/gfx/<name>.t3x ; NULL on failure */
void plat_tex_free(PTex *t);
void plat_blit(PTex *t, int sx, int sy, int sw, int sh, float dx, float dy,
               float scale, bool flipx, int alpha /*0..255*/);
void plat_rect(float x, float y, float w, float h, uint32_t color);
void plat_text(const char *utf8, float x, float y, float scale, uint32_t color);
float plat_text_w(const char *utf8, float scale);
float plat_text_h(float scale);          /* height of one text line */

uint8_t *plat_read_file(const char *relpath, size_t *size);   /* from romfs; malloc'd; NULL on failure */
FILE *plat_open_rom(const char *relpath);
FILE *plat_open_user(const char *name, bool write);           /* save-data folder on the SD card */

/* audio: the engine decodes IMA-ADPCM itself and streams PCM16 mono */
bool plat_audio_init(void);
int plat_bgm_free_buffers(void);
void plat_bgm_start(int rate);
void plat_bgm_queue(const int16_t *pcm, int n);
void plat_bgm_stop(void);
void plat_bgm_volume(float v);
bool plat_bgm_busy(void);                /* true while queued samples are still playing */
void plat_se_play(const int16_t *pcm, int n, int rate, float vol, float pitch);

#endif
