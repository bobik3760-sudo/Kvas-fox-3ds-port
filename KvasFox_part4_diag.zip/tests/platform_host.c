/* platform_host.c - PC implementation of platform.h for tests and screenshots (not shipped to 3DS) */
#include "../source/platform.h"
#include "host.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <sys/stat.h>

struct PTex { int w, h; uint8_t *px; };

static char s_romfs[512] = "romfs", s_gfx[512] = "tests/hostgfx", s_user[512] = "tests/user";
static uint8_t s_top[SCR_W * SCR_H * 4], s_bot[BSCR_W * BSCR_H * 4];
static int s_cur = 0;
static uint32_t s_held, s_prev;
static bool s_touch, s_ptouch; static int s_tx, s_ty;
static bool s_run = true;
static FILE *s_textlog;
static char s_textbuf[1 << 20]; static size_t s_textlen;
int host_se_count, host_bgm_starts;
static int s_bgm_free = 2;

void host_set_roots(const char *r, const char *g, const char *u)
{
    snprintf(s_romfs, sizeof s_romfs, "%s", r); snprintf(s_gfx, sizeof s_gfx, "%s", g); snprintf(s_user, sizeof s_user, "%s", u);
}
void host_set_held(uint32_t m) { s_held = m; }
void host_set_touch(bool t, int x, int y) { s_touch = t; s_tx = x; s_ty = y; }
void host_quit(void) { s_run = false; }

bool plat_init(void) { memset(s_top, 0, sizeof s_top); memset(s_bot, 0, sizeof s_bot); mkdir(s_user, 0777); return true; }
void plat_shutdown(void) {}
bool plat_running(void) { return s_run; }
void plat_exit_request(void) { s_run = false; }

void plat_begin_frame(PInput *in)
{
    in->held = s_held; in->down = s_held & ~s_prev; in->up = ~s_held & s_prev;
    in->touching = s_touch; in->touch_down = s_touch && !s_ptouch; in->touch_up = !s_touch && s_ptouch;
    in->tx = s_tx; in->ty = s_ty;
    s_prev = s_held; s_ptouch = s_touch; s_bgm_free = 2;
    memset(s_top, 0, sizeof s_top); memset(s_bot, 0, sizeof s_bot); s_textlen = 0;
}
void plat_end_frame(void) {}
void plat_target(int s) { s_cur = s; }

static uint8_t *fb(int *w, int *h)
{
    if (s_cur == 0) { *w = SCR_W; *h = SCR_H; return s_top; }
    *w = BSCR_W; *h = BSCR_H; return s_bot;
}

PTex *plat_tex_load(const char *name)
{
    char path[1024]; snprintf(path, sizeof path, "%s/%s.rgba", s_gfx, name);
    FILE *f = fopen(path, "rb"); if (!f) return NULL;
    uint32_t hd[2]; if (fread(hd, 4, 2, f) != 2) { fclose(f); return NULL; }
    PTex *t = calloc(1, sizeof *t); t->w = hd[0]; t->h = hd[1];
    t->px = malloc((size_t)t->w * t->h * 4);
    if (fread(t->px, 4, (size_t)t->w * t->h, f) != (size_t)t->w * t->h) { fclose(f); free(t->px); free(t); return NULL; }
    fclose(f); return t;
}
void plat_tex_free(PTex *t) { if (t) { free(t->px); free(t); } }

void plat_blit(PTex *t, int sx, int sy, int sw, int sh, float dx, float dy, float scale, bool flipx, int alpha)
{
    if (!t) return;
    int W, H; uint8_t *d = fb(&W, &H);
    int ow = (int)(sw * scale + 0.5f), oh = (int)(sh * scale + 0.5f);
    int x0 = (int)floorf(dx), y0 = (int)floorf(dy);
    for (int y = 0; y < oh; y++) {
        int py = y0 + y; if (py < 0 || py >= H) continue;
        int srcy = sy + (int)(y / scale); if (srcy < 0 || srcy >= t->h) continue;
        for (int x = 0; x < ow; x++) {
            int px = x0 + x; if (px < 0 || px >= W) continue;
            int xx = (int)(x / scale); if (flipx) xx = sw - 1 - xx;
            int srcx = sx + xx; if (srcx < 0 || srcx >= t->w) continue;
            const uint8_t *s = t->px + ((size_t)srcy * t->w + srcx) * 4;
            int a = s[3] * alpha / 255; if (!a) continue;
            uint8_t *o = d + ((size_t)py * W + px) * 4;
            for (int c = 0; c < 3; c++) o[c] = (uint8_t)((s[c] * a + o[c] * (255 - a)) / 255);
            o[3] = 255;
        }
    }
}

void plat_rect(float x, float y, float w, float h, uint32_t col)
{
    int W, H; uint8_t *d = fb(&W, &H);
    int a = (col >> 24) & 255, r = col & 255, g = (col >> 8) & 255, b = (col >> 16) & 255;
    for (int j = (int)y; j < (int)(y + h + 0.5f); j++) {
        if (j < 0 || j >= H) continue;
        for (int i = (int)x; i < (int)(x + w + 0.5f); i++) {
            if (i < 0 || i >= W) continue;
            uint8_t *o = d + ((size_t)j * W + i) * 4;
            o[0] = (uint8_t)((r * a + o[0] * (255 - a)) / 255);
            o[1] = (uint8_t)((g * a + o[1] * (255 - a)) / 255);
            o[2] = (uint8_t)((b * a + o[2] * (255 - a)) / 255);
            o[3] = 255;
        }
    }
}

static int cp_count(const char *s) { int n = 0; for (; *s; s++) if ((*s & 0xC0) != 0x80) n++; return n; }
float plat_text_w(const char *s, float scale) { return cp_count(s) * 14.5f * scale; }
float plat_text_h(float scale) { return 30.0f * scale; }
void plat_text(const char *s, float x, float y, float scale, uint32_t col)
{
    int n = snprintf(s_textbuf + s_textlen, sizeof s_textbuf - s_textlen, "%d\t%.1f\t%.1f\t%.2f\t%08x\t%s\n",
                     s_cur, x, y, scale, col, s);
    if (n > 0 && s_textlen + n < sizeof s_textbuf) s_textlen += n;
}

void host_dump(const char *prefix)
{
    char p[1024];
    for (int i = 0; i < 2; i++) {
        snprintf(p, sizeof p, "%s_%s.ppm", prefix, i ? "bottom" : "top");
        FILE *f = fopen(p, "wb"); if (!f) continue;
        int W = i ? BSCR_W : SCR_W, H = SCR_H; uint8_t *src = i ? s_bot : s_top;
        fprintf(f, "P6\n%d %d\n255\n", W, H);
        for (int k = 0; k < W * H; k++) fwrite(src + k * 4, 1, 3, f);
        fclose(f);
    }
    snprintf(p, sizeof p, "%s_text.txt", prefix);
    FILE *f = fopen(p, "wb"); if (f) { fwrite(s_textbuf, 1, s_textlen, f); fclose(f); }
}

uint8_t *plat_read_file(const char *rel, size_t *size)
{
    char path[1024]; snprintf(path, sizeof path, "%s/%s", s_romfs, rel);
    FILE *f = fopen(path, "rb"); if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *b = malloc(n + 4);
    if (fread(b, 1, n, f) != (size_t)n) { fclose(f); free(b); return NULL; }
    fclose(f); *size = n; return b;
}
FILE *plat_open_rom(const char *rel)
{
    char path[1024]; snprintf(path, sizeof path, "%s/%s", s_romfs, rel); return fopen(path, "rb");
}
FILE *plat_open_user(const char *name, bool w)
{
    char path[1024]; snprintf(path, sizeof path, "%s/%s", s_user, name); return fopen(path, w ? "wb" : "rb");
}

bool plat_audio_init(void) { return true; }
void plat_diag(const char *s) { (void)s; }
void plat_diag_result(const char *fmt, ...) { (void)fmt; }
int plat_bgm_free_buffers(void) { return s_bgm_free; }
void plat_bgm_start(int rate) { (void)rate; host_bgm_starts++; }
void plat_bgm_queue(const int16_t *pcm, int n) { (void)pcm; (void)n; if (s_bgm_free > 0) s_bgm_free--; }
void plat_bgm_stop(void) {}
void plat_bgm_volume(float v) { (void)v; }
bool plat_bgm_busy(void) { return false; }
void plat_se_play(const int16_t *pcm, int n, int rate, float vol, float pitch) { (void)pcm; (void)n; (void)rate; (void)vol; (void)pitch; host_se_count++; }
