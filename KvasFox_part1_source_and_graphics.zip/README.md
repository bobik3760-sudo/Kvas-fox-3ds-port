# Kvas Fox — Nintendo 3DS port (Russian / English)

A port of the RPG Maker MZ game **Kvas Fox / Квас лиса** to the Nintendo 3DS.

* **Top screen** = the game (map, dialogue, battles, cutscenes)
* **Bottom screen** = touch menu (party status, Items / Skills / Equip / Status / Save / Load / Language / Title, dialogue choices, shop, battle commands)
* **Icon** = your first image, **banner** = your second image
* **Language switch**: the *Русский / English* button on the bottom screen (or press **SELECT** at any time, including in the middle of a dialogue). The choice is remembered.

## Controls

| Button | Action |
|---|---|
| Circle Pad / D-Pad | move, move cursor |
| **A** | interact / talk / confirm |
| **B** | cancel / back / "decline" |
| **Y** (hold) | sprint |
| X | open Items menu |
| L / R | open Skills / Status menu |
| START | open Save menu |
| SELECT | switch language (RU ⇄ EN) |
| Touch screen | tap any button / list row / dialogue choice; drag a list to scroll |

## How to get the `.CIA` (works from a phone browser)

The `.CIA` is built online by GitHub (free), so you don't need any tools.

1. Make a free account on **github.com** and create a **new repository** (name it anything, set it to **Public**).
2. In the repository tap **Add file → Upload files** and upload all the `KvasFox_*.zip` files (do not unzip them).
   Tap **Commit changes**.
3. Tap **Add file → Create new file**. For the name type exactly `.github/workflows/build-cia.yml`
   (typing the `/` creates the folders). Paste the text from `build-cia.yml.txt`. Tap **Commit changes**.
4. Open the **Actions** tab → **Build Kvas Fox CIA** → **Run workflow**. Wait ~10 minutes (green tick = done).
   (If Actions is off, tap the green "I understand my workflows, go ahead and enable them" button first.)
5. Open the repository's **Releases** (right side / "Releases" link). There you'll find
   `KvasFox.cia`, `KvasFox.3dsx` and `KvasFox_QR.png`.

### Installing on the 3DS

* **QR code (no SD card needed):** open `KvasFox_QR.png` on your phone, then on the 3DS open **FBI → Remote Install → Scan QR Code** and point the 3DS camera at the phone screen. Choose *Install*.
* **Manually:** download `KvasFox.cia`, copy it onto the SD card (any folder), open **FBI → SD → the file → Install CIA**.
* `KvasFox.3dsx` can be copied to `/3ds/` on the SD card and started from the Homebrew Launcher instead.

A custom-firmware 3DS (Luma3DS + FBI) is required to install CIAs.

### Sound

3DS homebrew needs the console's DSP firmware dump (`/3ds/dspfirm.cdc` on the SD card — create it with the "DSP1" homebrew app). Without it the game works fine but is silent.

## Saves

Saved to the SD card: `/3ds/KvasFox/save1.sav … save3.sav` (+ `config.dat` for the language).

## What is ported / what is not

Ported: all 46 maps with tiles/shadows/passability, events (dialogue, choices, shops, item/gold/party changes, move routes, jumps, balloons, fades, pictures, scrolling credits), followers, all 6 battles incl. boss scripts (turn-based, speed order, enemy AI, states, buffs, EXP/level-ups, drops, escape), items/skills/equipment menus, save/load, music + sound effects.

Not ported (not used by this game or approximated): attack animations (battles use text log + damage numbers), screen tint/shake/flash, weather, parallel-process events, vehicles, water-tile animation. Plugins (camera/WASD) are PC-only and ignored.

> **Honest status:** this port was written without access to a 3DS or a 3DS compiler. The game logic was tested on a PC (all event pages, all battles, save/load, both languages), but the cloud build and the real console have not been tried yet. If the build fails, open the failed run in the Actions tab and send the red error text to whoever is helping you.

## Rebuilding / editing (optional)

* `tools/convert.py <game folder>` converts the original RPG Maker MZ game into `romfs/` and `gfx_src/` (needs Python 3, Pillow, numpy, ffmpeg).
* English translations live in `tools/make_translations.py` (edit, run it, re-run `convert.py`).
* Local build with devkitPro: `make` (3dsx) / `make cia` (needs `makerom` + `bannertool`, see `tools/get_cia_tools.sh`).
* Engine source is in `source/` (portable C core + `platform_3ds.c`); `tests/` has the PC test harness.
