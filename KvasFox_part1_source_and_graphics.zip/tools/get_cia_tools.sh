#!/bin/sh
# Builds/downloads the two helper tools needed for .cia files (makerom and bannertool) into tools/bin/.
# Used by the GitHub workflow; needs git, make, cmake, a C/C++ compiler, curl and internet access.
ROOT=$(pwd)
mkdir -p tools/bin

get_makerom() {
    [ -x tools/bin/makerom ] && return 0
    command -v makerom >/dev/null 2>&1 && { cp "$(command -v makerom)" tools/bin/makerom; return 0; }
    rm -rf /tmp/Project_CTR
    if git clone --depth 1 https://github.com/3DSGuy/Project_CTR.git /tmp/Project_CTR; then
        (cd /tmp/Project_CTR/makerom && { make deps && make -j4; } || make -j4)
        f=$(find /tmp/Project_CTR -type f -name makerom -perm -u+x | head -1)
        [ -n "$f" ] && cp "$f" tools/bin/makerom && return 0
    fi
    echo "building makerom from source failed - trying a prebuilt release"
    url=$(curl -sL https://api.github.com/repos/3DSGuy/Project_CTR/releases | grep browser_download_url | grep -i 'makerom' | grep -i 'ubuntu' | head -1 | cut -d'"' -f4)
    if [ -n "$url" ]; then
        curl -sL "$url" -o /tmp/makerom.zip && (cd /tmp && unzip -o -q makerom.zip) && cp "$(find /tmp -maxdepth 2 -type f -name makerom | head -1)" tools/bin/makerom && return 0
    fi
    return 1
}

get_bannertool() {
    [ -x tools/bin/bannertool ] && return 0
    command -v bannertool >/dev/null 2>&1 && { cp "$(command -v bannertool)" tools/bin/bannertool; return 0; }
    rm -rf /tmp/bannertool
    git clone --depth 1 --recursive https://github.com/carstene1ns/3ds-bannertool.git /tmp/bannertool || return 1
    (cd /tmp/bannertool && cmake -B build -DCMAKE_BUILD_TYPE=Release . && cmake --build build -j4)
    f=$(find /tmp/bannertool -type f -name bannertool -perm -u+x | head -1)
    [ -n "$f" ] && cp "$f" tools/bin/bannertool && return 0
    return 1
}

get_makerom || { echo "ERROR: could not get makerom"; exit 1; }
get_bannertool || { echo "ERROR: could not get bannertool"; exit 1; }
chmod +x tools/bin/*
ls -la tools/bin
