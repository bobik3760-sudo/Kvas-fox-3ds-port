#!/usr/bin/env python3
"""
convert.py  -  RPG Maker MZ  ->  Nintendo 3DS data converter  (Kvas Fox port)

Usage:
    python3 tools/convert.py <path-to-game-folder> [--out .] [--host-gfx DIR]

Input : the extracted RPG Maker MZ game folder (the one containing data/, img/, audio/).
Output: <out>/romfs/db.bin, strings.bin, maps/mNNN.bin, audio/aNNN.ima
        <out>/gfx_src/*.png     (power-of-two PNGs; tex3ds turns them into .t3x in the build)
        <out>/gfx_src/textures.txt

Every binary file is a stream of little-endian int32 values (some sections embed
byte blobs padded to 4 bytes).  The C engine (source/data.c, source/map.c) reads
them in exactly the order they are written here.  Sections end with a sentinel
so any mismatch is detected immediately at load time.
"""
import os, sys, json, re, subprocess, hashlib, struct, shutil, unicodedata, argparse
from array import array
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import rmmz_tiles as T

ap = argparse.ArgumentParser()
ap.add_argument('src')
ap.add_argument('--out', default=os.path.join(HERE, '..'))
ap.add_argument('--host-gfx', default=None, help='also dump raw RGBA files for the host test build')
ap.add_argument('--no-audio', action='store_true')
ARGS = ap.parse_args()
SRC = ARGS.src
OUT = os.path.abspath(ARGS.out)
ROMFS = os.path.join(OUT, 'romfs')
GFX = os.path.join(OUT, 'gfx_src')
for d in (ROMFS, os.path.join(ROMFS, 'maps'), os.path.join(ROMFS, 'audio'), GFX):
    os.makedirs(d, exist_ok=True)

SCALE = 240.0 / 624.0          # "virtual 816x624 screen" -> 400x240 letterbox factor
LETTER_X = int(round((400 - 816 * SCALE) / 2))   # 43


def jload(name):
    with open(os.path.join(SRC, 'data', name), encoding='utf-8') as f:
        return json.load(f)


def find_image(sub, name):
    if not name:
        return None
    p = os.path.join(SRC, 'img', sub, name + '.png')
    if os.path.exists(p):
        return p
    d = os.path.join(SRC, 'img', sub)
    if os.path.isdir(d):
        nn = unicodedata.normalize('NFC', name).lower()
        for f in os.listdir(d):
            if unicodedata.normalize('NFC', f).lower() == nn + '.png':
                return os.path.join(d, f)
    return None


# ---------------------------------------------------------------------------- helpers
class Blob:
    def __init__(s):
        s.a = array('i')

    def i(s, *v):
        s.a.extend(int(x) for x in v)

    def bytes_(s, b):
        s.a.append(len(b))
        b = b + b'\0' * ((-len(b)) % 4)
        s.a.frombytes(b)

    def mark(s, n):
        s.a.append(0x5EC70000 + n)

    def tobytes(s):
        assert s.a.itemsize == 4
        return s.a.tobytes()


def pot(n):
    p = 1
    while p < n:
        p *= 2
    return max(p, 8)


def save_png(name, img, pad_pot=True):
    """Saves a (padded to power-of-two) PNG.  Returns (real_w, real_h)."""
    w, h = img.size
    if pad_pot:
        canvas = Image.new('RGBA', (pot(w), pot(h)), (0, 0, 0, 0))
        canvas.paste(img, (0, 0))
        img = canvas
    img.save(os.path.join(GFX, name + '.png'), optimize=True)
    TEXTURES.append(name)
    if ARGS.host_gfx:
        os.makedirs(ARGS.host_gfx, exist_ok=True)
        with open(os.path.join(ARGS.host_gfx, name + '.rgba'), 'wb') as f:
            f.write(struct.pack('<II', img.size[0], img.size[1]))
            f.write(img.tobytes())
    return w, h


TEXTURES = []

# ---------------------------------------------------------------------------- strings
EN = {}
tp = os.path.join(HERE, 'translations_en.json')
if os.path.exists(tp):
    EN = json.load(open(tp, encoding='utf-8'))
CYR = re.compile('[А-Яа-яЁё]')


class Strings:
    def __init__(s):
        s.items = []
        s.idx = {}
        s.missing = []

    def id(s, ru, need=True):
        if ru is None:
            return -1
        if ru in s.idx:
            return s.idx[ru]
        en = EN.get(ru)
        if en is None:
            en = ru
            if need and CYR.search(ru):
                s.missing.append(ru)
        s.items.append((ru, en))
        s.idx[ru] = len(s.items) - 1
        return s.idx[ru]

    def write(s, path):
        ru_blob, en_blob = bytearray(), bytearray()
        offr, offe = [], []
        # one shared blob: ru strings then en strings
        blob = bytearray()
        for ru, _ in s.items:
            offr.append(len(blob)); blob += ru.encode('utf-8') + b'\0'
        for _, en in s.items:
            offe.append(len(blob)); blob += en.encode('utf-8') + b'\0'
        with open(path, 'wb') as f:
            f.write(struct.pack('<I', len(s.items)))
            f.write(struct.pack('<%dI' % len(offr), *offr))
            f.write(struct.pack('<%dI' % len(offe), *offe))
            f.write(blob)


S = Strings()

# ---------------------------------------------------------------------------- assets
class Assets:
    def __init__(s):
        s.chars, s.char_info = {}, []
        s.faces, s.face_info = {}, []
        s.pics, s.pic_info = {}, []
        s.enemies, s.enemy_info = {}, []
        s.audio, s.audio_list = {}, []     # (kind,name)->id ; [(kind,name,path)]

    # -- character sheets -------------------------------------------------------
    def char(s, name):
        if not name:
            return -1
        if name in s.chars:
            return s.chars[name]
        p = find_image('characters', name)
        if not p:
            print('  ! missing character sheet', name); return -1
        im = Image.open(p).convert('RGBA')
        W, H = im.size
        big = bool(re.match(r'^!*\$', name))
        obj = '!' in (re.match(r'^[!$]+', name).group(0) if re.match(r'^[!$]+', name) else '')
        cw, ch = (W // 3, H // 4) if big else (W // 12, H // 8)
        half = T.downscale_half(im) if (W % 2 == 0 and H % 2 == 0) else T.resize_pm(im, (W // 2, H // 2))
        cid = len(s.char_info)
        rw, rh = save_png('c%03d' % cid, half)
        s.char_info.append((rw, rh, cw // 2, ch // 2, (1 if big else 0) | (2 if obj else 0)))
        s.chars[name] = cid
        return cid

    def face(s, name):
        if not name:
            return -1
        if name in s.faces:
            return s.faces[name]
        p = find_image('faces', name)
        if not p:
            print('  ! missing face', name); return -1
        im = Image.open(p).convert('RGBA')
        half = T.downscale_half(im)
        fid = len(s.face_info)
        rw, rh = save_png('f%02d' % fid, half)
        s.face_info.append((rw, rh))
        s.faces[name] = fid
        return fid

    def pic(s, name):
        if not name:
            return -1
        if name in s.pics:
            return s.pics[name]
        p = find_image('pictures', name)
        if not p:
            print('  ! missing picture', name); return -1
        im = Image.open(p).convert('RGBA')
        sz = (max(1, int(round(im.width * SCALE))), max(1, int(round(im.height * SCALE))))
        rs = T.resize_pm(im, sz)
        pid = len(s.pic_info)
        rw, rh = save_png('p%02d' % pid, rs)
        s.pic_info.append((rw, rh))
        s.pics[name] = pid
        return pid

    def enemy(s, name):
        if not name:
            return -1
        if name in s.enemies:
            return s.enemies[name]
        p = find_image('enemies', name)
        if not p:
            print('  ! missing enemy image', name); return -1
        im = Image.open(p).convert('RGBA')
        sz = (max(1, int(round(im.width * SCALE))), max(1, int(round(im.height * SCALE))))
        rs = T.resize_pm(im, sz)
        eid = len(s.enemy_info)
        rw, rh = save_png('e%02d' % eid, rs)
        s.enemy_info.append((rw, rh))
        s.enemies[name] = eid
        return eid

    # -- audio ------------------------------------------------------------------
    def snd(s, kind, name):
        """kind: bgm/bgs/me/se.  Returns audio id or -1."""
        if not name:
            return -1
        key = (kind, name)
        if key in s.audio:
            return s.audio[key]
        path = None
        for ext in ('.ogg', '.m4a', '.wav', '.mp3'):
            cand = os.path.join(SRC, 'audio', kind, name + ext)
            if os.path.exists(cand):
                path = cand; break
        if not path:
            print('  ! missing audio', kind, name)
            s.audio[key] = -1
            return -1
        aid = len(s.audio_list)
        s.audio_list.append((kind, name, path))
        s.audio[key] = aid
        return aid


A = Assets()


def convert_audio():
    kinds = {'bgm': 0, 'bgs': 1, 'me': 2, 'se': 3}
    entries = []
    total = 0
    for aid, (kind, name, path) in enumerate(A.audio_list):
        out = os.path.join(ROMFS, 'audio', 'a%03d.ima' % aid)
        if not ARGS.no_audio:
            tmp = '/tmp/_kvas_%d.wav' % aid
            r = subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', path, '-vn', '-ac', '1', '-ar', '22050',
                                '-c:a', 'adpcm_ima_wav', '-block_size', '1024', tmp], capture_output=True)
            if r.returncode != 0:
                print('  ! ffmpeg failed for', name, r.stderr.decode()[:200]); continue
            wav = open(tmp, 'rb').read(); os.remove(tmp)
            pos = 12
            rate = ba = spb = total_samples = 0; data = b''
            while pos + 8 <= len(wav):
                cid = wav[pos:pos + 4]; sz = struct.unpack('<I', wav[pos + 4:pos + 8])[0]
                body = wav[pos + 8:pos + 8 + sz]
                if cid == b'fmt ':
                    tag, ch, rate, _, ba, bits = struct.unpack('<HHIIHH', body[:16])
                    assert tag == 0x11 and ch == 1 and bits == 4, (tag, ch, bits)
                    spb = struct.unpack('<H', body[18:20])[0]
                elif cid == b'fact':
                    total_samples = struct.unpack('<I', body[:4])[0]
                elif cid == b'data':
                    data = body
                pos += 8 + sz + (sz & 1)
            if not total_samples:
                total_samples = (len(data) // ba) * spb
            with open(out, 'wb') as f:
                f.write(b'KIMA' + struct.pack('<IIIII', rate, ba, spb, total_samples, len(data)) + data)
            total += len(data)
        entries.append((kinds[kind], aid))
    print('audio: %d files, %.1f MB' % (len(A.audio_list), total / 1e6))


# ---------------------------------------------------------------------------- formula compiler
PCODE = {'mhp': 0, 'mmp': 1, 'atk': 2, 'def': 3, 'mat': 4, 'mdf': 5, 'agi': 6, 'luk': 7, 'hp': 8, 'mp': 9, 'level': 10}
OP_CONST, OP_A, OP_B, OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_NEG = range(8)


def compile_formula(f):
    toks = re.findall(r'\d+\.?\d*|[ab]\.[a-z]+|[-+*/()]', f.replace(' ', ''))
    if ''.join(toks) != f.replace(' ', ''):
        print('  ! cannot parse formula', repr(f)); return [OP_CONST, 0]
    pos = [0]
    out = []

    def peek():
        return toks[pos[0]] if pos[0] < len(toks) else None

    def nxt():
        t = toks[pos[0]]; pos[0] += 1; return t

    def primary():
        t = nxt()
        if t == '(':
            expr(); assert nxt() == ')'
        elif t[0] in 'ab' and t[1] == '.':
            out.extend([OP_A if t[0] == 'a' else OP_B, PCODE[t[2:]]])
        else:
            out.extend([OP_CONST, int(round(float(t) * 1000))])

    def unary():
        if peek() == '-':
            nxt(); unary(); out.extend([OP_NEG, 0])
        else:
            primary()

    def term():
        unary()
        while peek() in ('*', '/'):
            o = nxt(); unary(); out.extend([OP_MUL if o == '*' else OP_DIV, 0])

    def expr():
        term()
        while peek() in ('+', '-'):
            o = nxt(); term(); out.extend([OP_ADD if o == '+' else OP_SUB, 0])
    try:
        expr()
        assert pos[0] == len(toks)
    except Exception:
        print('  ! cannot parse formula', repr(f)); return [OP_CONST, 0]
    return out


# ---------------------------------------------------------------------------- event command compiler
SC_CH = {'A': 0, 'B': 1, 'C': 2, 'D': 3}


def route_ints(route):
    """list of {code,parameters} -> flat [code,a,b,c]*n (terminator dropped)."""
    out = []
    for m in route['list']:
        c, p = m['code'], m.get('parameters', [])
        if c == 0:
            continue
        a = b = d = 0
        if c == 14: a, b = p[0], p[1]
        elif c in (15, 27, 28, 29, 30, 42, 43): a = p[0]
        elif c == 41:
            a, b = A.char(p[0]), p[1]
        elif c == 44:
            a = A.snd('se', p[0]['name']); b = p[0]['volume']; d = p[0]['pitch']
        elif c == 45:
            c = 0   # script: unsupported -> no-op
        out.extend([c, a, b, d])
    return out


def audio_param(p):
    return A.snd  # placeholder to keep linter calm


def compile_cmds(lst):
    out = []

    def emit(code, indent, *params):
        out.extend([code, indent, len(params)] + [int(x) for x in params])
    i = 0
    n = len(lst)
    while i < n:
        c = lst[i]; code = c['code']; p = c['parameters']; ind = c['indent']
        if code == 101:
            lines = []
            j = i + 1
            while j < n and lst[j]['code'] == 401:
                lines.append(lst[j]['parameters'][0]); j += 1
            text = ' '.join(l.strip() for l in lines if l.strip())
            name = p[4] if len(p) > 4 and p[4] else None
            emit(101, ind, A.face(p[0]), p[1], p[2], p[3], S.id(name) if name else -1, S.id(text))
            i = j; continue
        if code == 105:
            emit(105, ind, p[0], 1 if p[1] else 0)
        elif code == 405:
            emit(405, ind, S.id(p[0]))
        elif code == 102:
            ch = p[0]
            cancel = p[1] if p[1] < len(ch) else -2
            emit(102, ind, cancel, p[2], p[3], p[4] if len(p) > 4 else 0, len(ch), *[S.id(x) for x in ch])
        elif code == 402:
            emit(402, ind, p[0])
        elif code in (403, 404, 411, 412, 112, 413, 113, 115, 221, 222, 214, 352, 353, 354, 601, 602, 603, 604, 0):
            emit(code, ind)
        elif code == 111:
            t = p[0]
            if t == 0: emit(111, ind, 0, p[1], p[2])
            elif t == 1: emit(111, ind, 1, p[1], p[2], p[3], p[4])
            elif t == 2: emit(111, ind, 2, SC_CH.get(p[1], 0), p[2])
            elif t == 4: emit(111, ind, 4, p[1], p[2])
            elif t == 7: emit(111, ind, 7, p[1], p[2])
            elif t in (8,): emit(111, ind, 8, p[1])
            elif t in (9, 10): emit(111, ind, t, p[1], p[2] if len(p) > 2 else 0)
            else: emit(111, ind, 99)
        elif code in (118, 119):
            emit(code, ind, S.id(p[0], False))
        elif code == 117:
            emit(117, ind, p[0])
        elif code == 121:
            emit(121, ind, p[0], p[1], p[2])
        elif code == 122:
            emit(122, ind, p[0], p[1], p[2], p[3], *(list(p[4:7]) + [0, 0, 0])[:3] if p[3] != 4 else (0, 0, 0))
        elif code == 123:
            emit(123, ind, SC_CH.get(p[0], 0), p[1])
        elif code == 125:
            emit(125, ind, p[0], p[1], p[2])
        elif code in (126, 127, 128):
            emit(code, ind, p[0], p[1], p[2], p[3])
        elif code == 129:
            emit(129, ind, p[0], p[1], 1 if p[2] else 0)
        elif code == 201:
            emit(201, ind, p[0], p[1], p[2], p[3], p[4], p[5])
        elif code == 203:
            emit(203, ind, p[0], p[1], p[2], p[3], p[4])
        elif code == 205:
            r = route_ints(p[1])
            emit(205, ind, p[0], 1 if p[1]['repeat'] else 0, 1 if p[1]['skippable'] else 0,
                 1 if p[1]['wait'] else 0, len(r) // 4, *r)
        elif code == 213:
            emit(213, ind, p[0], p[1], 1 if p[2] else 0)
        elif code == 211:
            emit(211, ind, p[0])
        elif code == 230:
            emit(230, ind, p[0])
        elif code == 231:
            emit(231, ind, p[0], A.pic(p[1]), p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9])
        elif code == 235:
            emit(235, ind, p[0])
        elif code in (241, 245, 249, 250):
            kind = {241: 'bgm', 245: 'bgs', 249: 'me', 250: 'se'}[code]
            f = p[0]
            emit(code, ind, A.snd(kind, f['name']), f['volume'], f['pitch'])
        elif code in (242, 246):
            emit(code, ind, p[0])
        elif code == 242:
            emit(242, ind, p[0])
        elif code == 301:
            emit(301, ind, p[0], p[1], 1 if p[2] else 0, 1 if p[3] else 0)
        elif code == 302:
            goods = [(p[0], p[1], p[2], p[3])]
            purchase_only = 1 if (len(p) > 4 and p[4]) else 0
            j = i + 1
            while j < n and lst[j]['code'] == 605:
                q = lst[j]['parameters']; goods.append((q[0], q[1], q[2], q[3])); j += 1
            flat = []
            for gt, gi, pt, pr in goods:
                flat += [gt, gi, pr if pt == 1 else -1]
            emit(302, ind, purchase_only, len(goods), *flat)
            i = j; continue
        elif code == 311:
            emit(311, ind, p[0], p[1], p[2], p[3], p[4], 1 if p[5] else 0)
        elif code == 314:
            emit(314, ind, p[0], p[1])
        elif code == 333:
            emit(333, ind, p[0], p[1], p[2])
        elif code == 335:
            emit(335, ind, p[0])
        # anything else (comments, scripts, plugin commands, 505/401 leftovers ...) is dropped
        i += 1
    return out


# ---------------------------------------------------------------------------- maps
TILESETS = {}
TSDATA = jload('Tilesets.json')


def get_tileset(tid):
    if tid not in TILESETS:
        TILESETS[tid] = T.Tileset(TSDATA[tid], os.path.join(SRC, 'img'), lambda d, n: find_image('tilesets', n))
    return TILESETS[tid]


PAGE_SIZES = [(256, 256), (512, 256), (512, 512), (1024, 512), (1024, 1024)]


def convert_map(mid, infos):
    m = jload('Map%03d.json' % mid)
    w, h = m['width'], m['height']
    data = m['data']
    ts = get_tileset(m['tilesetId'])

    def get(x, y, z):
        if 0 <= x < w and 0 <= y < h:
            return data[(z * h + y) * w + x] or 0
        return 0

    op_cache = {}
    hash_idx = {}
    tiles = []         # list of 24x24 RGBA images

    def tile_index(ops):
        if not ops:
            return 0
        if ops in op_cache:
            return op_cache[ops]
        img = T.downscale_half(ts.render_ops(ops))
        if T.is_empty(img):
            op_cache[ops] = 0; return 0
        hsh = hashlib.md5(img.tobytes()).digest()
        if hsh not in hash_idx:
            tiles.append(img); hash_idx[hsh] = len(tiles)
        op_cache[ops] = hash_idx[hsh]
        return op_cache[ops]

    lower = np.zeros(w * h, dtype='<u2'); upper = np.zeros(w * h, dtype='<u2'); passv = np.zeros(w * h, dtype='u1')
    for y in range(h):
        for x in range(w):
            lo, up = ts.cell_ops(get, x, y)
            lower[y * w + x] = tile_index(lo)
            upper[y * w + x] = tile_index(up)
            layered = [get(x, y, z) for z in (3, 2, 1, 0)]
            pv = 0
            for bi, bit in enumerate((1, 2, 4, 8)):
                if ts.passable_bit(layered, bit):
                    pv |= 1 << bi
            fl = [ts.flag(t) for t in layered]
            if any(f & 0x80 for f in fl): pv |= 0x10
            if any(f & 0x20 for f in fl): pv |= 0x20
            if any(f & 0x40 for f in fl): pv |= 0x40
            passv[y * w + x] = pv

    # ---- atlas pages
    n = len(tiles)
    pages = []
    remaining = n
    if n <= 1764:
        for (pw, ph) in PAGE_SIZES:
            if (pw // 24) * (ph // 24) >= max(n, 1):
                pages.append((pw, ph)); break
    else:
        while remaining > 0:
            pages.append((1024, 1024)); remaining -= 1764
    k = 0
    for pi, (pw, ph) in enumerate(pages):
        cols = pw // 24; cap = cols * (ph // 24)
        atlas = Image.new('RGBA', (pw, ph), (0, 0, 0, 0))
        for slot in range(cap):
            if k >= n: break
            atlas.paste(tiles[k], ((slot % cols) * 24, (slot // cols) * 24)); k += 1
        save_png('t%03d_%d' % (mid, pi), atlas, pad_pot=False)

    b = Blob()
    b.i(0x4D415031, w, h)
    bgm = A.snd('bgm', m['bgm']['name']) if m.get('autoplayBgm') else -1
    bgs = A.snd('bgs', m['bgs']['name']) if m.get('autoplayBgs') else -1
    dn = S.id(m['displayName']) if m.get('displayName') else -1
    overworld = 1 if TSDATA[m['tilesetId']]['mode'] == 0 else 0
    b.i(bgm, m['bgm']['volume'] if bgm >= 0 else 0, bgs, dn, 1 if m['disableDashing'] else 0, overworld)
    b.i(len(pages))
    for (pw, ph) in pages:
        b.i(pw, ph, pw // 24, (pw // 24) * (ph // 24))
    b.bytes_(lower.tobytes()); b.bytes_(upper.tobytes()); b.bytes_(passv.tobytes())
    b.mark(1)
    evs = [e for e in m['events'] if e]
    b.i(len(evs))
    for e in evs:
        b.i(e['id'], e['x'], e['y'], len(e['pages']))
        for pg in e['pages']:
            c = pg['conditions']
            cf = (1 if c['switch1Valid'] else 0) | (2 if c['switch2Valid'] else 0) | (4 if c['variableValid'] else 0) | \
                 (8 if c['selfSwitchValid'] else 0) | (16 if c['itemValid'] else 0) | (32 if c['actorValid'] else 0)
            b.i(cf, c['switch1Id'], c['switch2Id'], c['variableId'], c['variableValue'],
                SC_CH.get(c['selfSwitchCh'], 0), c['itemId'], c['actorId'])
            im = pg['image']
            if im['tileId'] > 0:
                print('  ! tile-graphic event ignored on map', mid)
            sheet = A.char(im['characterName']) if im['characterName'] else -1
            b.i(1 if sheet >= 0 else 0, sheet, im['characterIndex'], im['direction'], im['pattern'])
            r = route_ints(pg['moveRoute'])
            b.i(pg['moveType'], pg['moveSpeed'], pg['moveFrequency'], 1 if pg['moveRoute']['repeat'] else 0,
                1 if pg['moveRoute']['skippable'] else 0, len(r) // 4, *r)
            opt = (1 if pg['walkAnime'] else 0) | (2 if pg['stepAnime'] else 0) | (4 if pg['directionFix'] else 0) | (8 if pg['through'] else 0)
            b.i(opt, pg['priorityType'], pg['trigger'])
            cmds = compile_cmds(pg['list'])
            b.i(len(cmds), *cmds)
    b.mark(2)
    with open(os.path.join(ROMFS, 'maps', 'm%03d.bin' % mid), 'wb') as f:
        f.write(b.tobytes())
    return n, len(pages)


# ---------------------------------------------------------------------------- database
def traits_ints(tr):
    out = [len(tr)]
    for t in tr:
        out += [t['code'], t['dataId'], int(round(t['value'] * 10000))]
    return out


def effects_ints(ef):
    out = [len(ef)]
    for e in ef:
        out += [e['code'], e['dataId'], int(round(e['value1'] * 10000)), int(round(e['value2'] * 10000))]
    return out


def damage_ints(d):
    f = compile_formula(d['formula'])
    return [d['type'], d['elementId'], d['variance'], 1 if d['critical'] else 0, len(f) // 2] + f


def write_db(patched_common):
    sysj = jload('System.json')
    b = Blob()
    b.i(0x4B564442, 1)
    # ---- system
    s = sysj
    b.i(s['startMapId'], s['startX'], s['startY'], len(s['partyMembers']), *s['partyMembers'])
    b.i(S.id(s['currencyUnit']))
    snd = [A.snd('se', x['name']) for x in s['sounds']]
    b.i(len(snd), *snd)
    b.i(A.snd('bgm', s['titleBgm']['name']), A.snd('me', s['victoryMe']['name']),
        A.snd('me', s['defeatMe']['name']), A.snd('me', s['gameoverMe']['name']))
    b.i(1 if s['optFollowers'] else 0)
    b.mark(10)
    # ---- actors
    ac = jload('Actors.json'); b.i(len(ac))
    for a in ac:
        if not a: b.i(0); continue
        b.i(1, S.id(a['name']), a['classId'], a['initialLevel'], a['maxLevel'], A.char(a['characterName']),
            a['characterIndex'], A.face(a['faceName']), a['faceIndex'], *a['equips'][:5], *traits_ints(a['traits']))
    b.mark(11)
    # ---- classes
    cl = jload('Classes.json'); b.i(len(cl))
    for c in cl:
        if not c: b.i(0); continue
        b.i(1, S.id(c['name']), *c['expParams'])
        for pi in range(8):
            row = list(c['params'][pi]) + [c['params'][pi][-1]] * 100
            b.i(*row[:100])
        b.i(len(c['learnings']))
        for l in c['learnings']: b.i(l['level'], l['skillId'])
        b.i(*traits_ints(c['traits']))
    b.mark(12)
    # ---- skills
    sk = jload('Skills.json'); b.i(len(sk))
    for x in sk:
        if not x: b.i(0); continue
        b.i(1, S.id(x['name'], x['id'] in NEED_SKILLS), x['stypeId'], x['scope'], x['occasion'], x['hitType'],
            x['mpCost'], x['tpCost'], x['successRate'], x['repeats'], x['animationId'], x['speed'],
            *damage_ints(x['damage']), *effects_ints(x['effects']))
    b.mark(13)
    # ---- items
    it = jload('Items.json'); b.i(len(it))
    for x in it:
        if not x: b.i(0); continue
        b.i(1, S.id(x['name']), S.id(x['description'], False), x['itypeId'], x['price'], 1 if x['consumable'] else 0,
            x['scope'], x['occasion'], x['hitType'], x['successRate'], x['repeats'], x['speed'],
            *damage_ints(x['damage']), *effects_ints(x['effects']))
    b.mark(14)
    # ---- weapons / armors
    for fn in ('Weapons.json', 'Armors.json'):
        d = jload(fn); b.i(len(d))
        for x in d:
            if not x: b.i(0); continue
            kind = x['wtypeId'] if fn.startswith('W') else x['atypeId']
            b.i(1, S.id(x['name'], x['id'] in NEED_EQUIP[fn]), x['etypeId'], kind, x['price'], *x['params'][:8], *traits_ints(x['traits']))
    b.mark(15)
    # ---- enemies
    en = jload('Enemies.json'); b.i(len(en))
    for x in en:
        if not x: b.i(0); continue
        b.i(1, S.id(x['name']), A.enemy(x['battlerName']), *x['params'][:8], x['exp'], x['gold'])
        dr = x['dropItems'][:3]; dr += [{'kind': 0, 'dataId': 1, 'denominator': 1}] * (3 - len(dr))
        for d in dr: b.i(d['kind'], d['dataId'], d['denominator'])
        b.i(len(x['actions']))
        for a in x['actions']: b.i(a['skillId'], a['rating'], a['conditionType'], a['conditionParam1'], a['conditionParam2'])
        b.i(*traits_ints(x['traits']))
    b.mark(16)
    # ---- states
    st = jload('States.json'); b.i(len(st))
    for x in st:
        if not x: b.i(0); continue
        b.i(1, S.id(x['name'], x['id'] <= 13), x['restriction'], x['priority'], x['autoRemovalTiming'], x['minTurns'], x['maxTurns'],
            1 if x['removeByDamage'] else 0, x['chanceByDamage'], *traits_ints(x['traits']))
    b.mark(17)
    # ---- troops
    tr = jload('Troops.json'); b.i(len(tr))
    for t in tr:
        if not t: b.i(0); continue
        b.i(1, S.id(t['name'], False), len(t['members']))
        for mm in t['members']: b.i(mm['enemyId'], mm['x'], mm['y'], 1 if mm['hidden'] else 0)
        b.i(len(t['pages']))
        for pg in t['pages']:
            c = pg['conditions']
            b.i(pg['span'], 1 if c['turnEnding'] else 0, 1 if c['turnValid'] else 0, c['turnA'], c['turnB'],
                1 if c['enemyValid'] else 0, c['enemyIndex'], c['enemyHp'], 1 if c['actorValid'] else 0, c['actorId'], c['actorHp'],
                1 if c['switchValid'] else 0, c['switchId'])
            cm = compile_cmds(pg['list']); b.i(len(cm), *cm)
    b.mark(18)
    # ---- common events
    b.i(len(patched_common))
    for c in patched_common:
        if not c: b.i(0); continue
        b.i(1, c['trigger'], c['switchId'])
        cm = compile_cmds(c['list']); b.i(len(cm), *cm)
    b.mark(19)
    # ---- asset tables (written last: filled while compiling everything above)
    b.i(len(A.char_info))
    for t in A.char_info: b.i(*t)
    b.i(len(A.face_info))
    for t in A.face_info: b.i(*t)
    b.i(len(A.pic_info))
    for t in A.pic_info: b.i(*t)
    b.i(len(A.enemy_info))
    for t in A.enemy_info: b.i(*t)
    kinds = {'bgm': 0, 'bgs': 1, 'me': 2, 'se': 3}
    b.i(len(A.audio_list))
    for (k, n_, p_) in A.audio_list: b.i(kinds[k])
    b.mark(20)
    with open(os.path.join(ROMFS, 'db.bin'), 'wb') as f:
        f.write(b.tobytes())


NEED_SKILLS = set()
NEED_EQUIP = {'Weapons.json': set(), 'Armors.json': set()}


def collect_needed():
    """Which database entries can actually show up in-game (to limit missing-translation noise)."""
    cl = jload('Classes.json'); en = jload('Enemies.json'); ac = jload('Actors.json')
    for c in cl:
        if c:
            for l in c['learnings']: NEED_SKILLS.add(l['skillId'])
    for e in en:
        if e:
            for a in e['actions']: NEED_SKILLS.add(a['skillId'])
    NEED_SKILLS.update({1, 2})
    for a in ac:
        if a:
            for t in a['traits']:
                if t['code'] == 43: NEED_SKILLS.add(t['dataId'])
            for i, q in enumerate(a['equips']):
                if q:
                    NEED_EQUIP['Weapons.json' if i == 0 else 'Armors.json'].add(q)
    # shop goods
    for f in os.listdir(os.path.join(SRC, 'data')):
        if re.match(r'Map\d+\.json', f):
            d = jload(f)
            for e in d['events']:
                if not e: continue
                for pg in e['pages']:
                    for c in pg['list']:
                        if c['code'] in (302, 605):
                            p = c['parameters']
                            if p[0] == 1: NEED_EQUIP['Weapons.json'].add(p[1])
                            elif p[0] == 2: NEED_EQUIP['Armors.json'].add(p[1])
                        if c['code'] in (127, 128):
                            NEED_EQUIP['Weapons.json' if c['code'] == 127 else 'Armors.json'].add(c['parameters'][0])


# ---------------------------------------------------------------------------- misc images
def make_misc_images():
    # title screen
    t = find_image('titles1', jload('System.json')['title1Name'])
    im = Image.open(t).convert('RGBA')
    sz = (int(round(im.width * SCALE)), int(round(im.height * SCALE)))
    save_png('title', T.resize_pm(im, sz))
    # balloon sheet (8 cols x 15 rows of 48 px -> 24 px)
    bl = Image.open(find_image('system', 'Balloon')).convert('RGBA')
    save_png('balloon', T.downscale_half(bl))
    # auto battleback for overworld maps: Grassland (bb1 + bb2), cropped to 400x240
    b1 = Image.open(find_image('battlebacks1', 'Grassland')).convert('RGBA')
    b2 = Image.open(find_image('battlebacks2', 'Grassland')).convert('RGBA')
    c = Image.new('RGBA', b1.size, (0, 0, 0, 255)); c.alpha_composite(b1); c.alpha_composite(b2)
    k = 400.0 / c.width
    c = c.resize((400, int(round(c.height * k))), Image.LANCZOS)
    c = c.crop((0, c.height - 240, 400, c.height))
    save_png('bb_field', c)


# ---------------------------------------------------------------------------- main
def main():
    collect_needed()
    infos = jload('MapInfos.json')
    # patch: after the credits, return to the title screen instead of idling on a black screen
    END_FIX = {43: 2, 45: 2, 46: 2}
    stats = []
    for inf in infos:
        if not inf:
            continue
        mid = inf['id']
        mp = os.path.join(SRC, 'data', 'Map%03d.json' % mid)
        if not os.path.exists(mp):
            continue
        if mid in END_FIX:
            d = json.load(open(mp, encoding='utf-8'))
            for e in d['events']:
                if e and e['id'] == END_FIX[mid]:
                    for pg in e['pages']:
                        if pg['list'] and pg['list'][-1]['code'] == 0:
                            pg['list'].insert(len(pg['list']) - 1, {'code': 354, 'indent': 0, 'parameters': []})
            json.dump(d, open('/tmp/_Map%03d.json' % mid, 'w', encoding='utf-8'))
            # load patched copy through jload by temporarily swapping
            orig = jload
            globals()['jload'] = lambda name, _o=orig, _m=mid: json.load(open('/tmp/_Map%03d.json' % _m, encoding='utf-8')) if name == 'Map%03d.json' % _m else _o(name)
        n, pages = convert_map(mid, infos)
        if mid in END_FIX:
            globals()['jload'] = orig
        stats.append((mid, n, pages))
        print('map %03d: %4d unique tiles, %d page(s)' % (mid, n, pages))
    common = jload('CommonEvents.json')
    make_misc_images()
    write_db(common)
    convert_audio()
    S.write(os.path.join(ROMFS, 'strings.bin'))
    with open(os.path.join(GFX, 'textures.txt'), 'w') as f:
        f.write('\n'.join(sorted(set(TEXTURES))) + '\n')
    print('textures:', len(set(TEXTURES)), ' strings:', len(S.items))
    if S.missing:
        print('\nMISSING ENGLISH TRANSLATIONS (%d):' % len(set(S.missing)))
        for m in sorted(set(S.missing)): print('  ', json.dumps(m, ensure_ascii=False))
    json.dump(sorted(set(S.missing)), open('/tmp/missing_tr.json', 'w'), ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
