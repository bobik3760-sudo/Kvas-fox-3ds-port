"""
rmmz_tiles.py - RPG Maker MZ tilemap logic ported to Python.

Ported from js/rmmz_core.js (Tilemap) so that every map cell can be pre-rendered
("baked") into at most two 24x24 images: a lower image (drawn below characters)
and an upper image (drawn above characters).  Passability is pre-computed too,
so the 3DS runtime needs no tileset logic at all.
"""
import os
import numpy as np
from PIL import Image

TILE = 48           # source tile size
OUT = 24            # output tile size (50 %)

TILE_ID_B, TILE_ID_C, TILE_ID_D, TILE_ID_E = 0, 256, 512, 768
TILE_ID_A5, TILE_ID_A1, TILE_ID_A2, TILE_ID_A3, TILE_ID_A4 = 1536, 2048, 2816, 4352, 5888
TILE_ID_MAX = 8192

FLOOR_AUTOTILE_TABLE = [
    [[2, 4], [1, 4], [2, 3], [1, 3]], [[2, 0], [1, 4], [2, 3], [1, 3]],
    [[2, 4], [3, 0], [2, 3], [1, 3]], [[2, 0], [3, 0], [2, 3], [1, 3]],
    [[2, 4], [1, 4], [2, 3], [3, 1]], [[2, 0], [1, 4], [2, 3], [3, 1]],
    [[2, 4], [3, 0], [2, 3], [3, 1]], [[2, 0], [3, 0], [2, 3], [3, 1]],
    [[2, 4], [1, 4], [2, 1], [1, 3]], [[2, 0], [1, 4], [2, 1], [1, 3]],
    [[2, 4], [3, 0], [2, 1], [1, 3]], [[2, 0], [3, 0], [2, 1], [1, 3]],
    [[2, 4], [1, 4], [2, 1], [3, 1]], [[2, 0], [1, 4], [2, 1], [3, 1]],
    [[2, 4], [3, 0], [2, 1], [3, 1]], [[2, 0], [3, 0], [2, 1], [3, 1]],
    [[0, 4], [1, 4], [0, 3], [1, 3]], [[0, 4], [3, 0], [0, 3], [1, 3]],
    [[0, 4], [1, 4], [0, 3], [3, 1]], [[0, 4], [3, 0], [0, 3], [3, 1]],
    [[2, 2], [1, 2], [2, 3], [1, 3]], [[2, 2], [1, 2], [2, 3], [3, 1]],
    [[2, 2], [1, 2], [2, 1], [1, 3]], [[2, 2], [1, 2], [2, 1], [3, 1]],
    [[2, 4], [3, 4], [2, 3], [3, 3]], [[2, 4], [3, 4], [2, 1], [3, 3]],
    [[2, 0], [3, 4], [2, 3], [3, 3]], [[2, 0], [3, 4], [2, 1], [3, 3]],
    [[2, 4], [1, 4], [2, 5], [1, 5]], [[2, 0], [1, 4], [2, 5], [1, 5]],
    [[2, 4], [3, 0], [2, 5], [1, 5]], [[2, 0], [3, 0], [2, 5], [1, 5]],
    [[0, 4], [3, 4], [0, 3], [3, 3]], [[2, 2], [1, 2], [2, 5], [1, 5]],
    [[0, 2], [1, 2], [0, 3], [1, 3]], [[0, 2], [1, 2], [0, 3], [3, 1]],
    [[2, 2], [3, 2], [2, 3], [3, 3]], [[2, 2], [3, 2], [2, 1], [3, 3]],
    [[2, 4], [3, 4], [2, 5], [3, 5]], [[2, 0], [3, 4], [2, 5], [3, 5]],
    [[0, 4], [1, 4], [0, 5], [1, 5]], [[0, 4], [3, 0], [0, 5], [1, 5]],
    [[0, 2], [3, 2], [0, 3], [3, 3]], [[0, 2], [1, 2], [0, 5], [1, 5]],
    [[0, 4], [3, 4], [0, 5], [3, 5]], [[2, 2], [3, 2], [2, 5], [3, 5]],
    [[0, 2], [3, 2], [0, 5], [3, 5]], [[0, 0], [1, 0], [0, 1], [1, 1]],
]
WALL_AUTOTILE_TABLE = [
    [[2, 2], [1, 2], [2, 1], [1, 1]], [[0, 2], [1, 2], [0, 1], [1, 1]],
    [[2, 0], [1, 0], [2, 1], [1, 1]], [[0, 0], [1, 0], [0, 1], [1, 1]],
    [[2, 2], [3, 2], [2, 1], [3, 1]], [[0, 2], [3, 2], [0, 1], [3, 1]],
    [[2, 0], [3, 0], [2, 1], [3, 1]], [[0, 0], [3, 0], [0, 1], [3, 1]],
    [[2, 2], [1, 2], [2, 3], [1, 3]], [[0, 2], [1, 2], [0, 3], [1, 3]],
    [[2, 0], [1, 0], [2, 3], [1, 3]], [[0, 0], [1, 0], [0, 3], [1, 3]],
    [[2, 2], [3, 2], [2, 3], [3, 3]], [[0, 2], [3, 2], [0, 3], [3, 3]],
    [[2, 0], [3, 0], [2, 3], [3, 3]], [[0, 0], [3, 0], [0, 3], [3, 3]],
]
WATERFALL_AUTOTILE_TABLE = [
    [[2, 0], [1, 0], [2, 1], [1, 1]], [[0, 0], [1, 0], [0, 1], [1, 1]],
    [[2, 0], [3, 0], [2, 1], [3, 1]], [[0, 0], [3, 0], [0, 1], [3, 1]],
]


def is_visible(t): return 0 < t < TILE_ID_MAX
def is_autotile(t): return t >= TILE_ID_A1
def kind_of(t): return (t - TILE_ID_A1) // 48
def shape_of(t): return (t - TILE_ID_A1) % 48
def is_a1(t): return TILE_ID_A1 <= t < TILE_ID_A2
def is_a2(t): return TILE_ID_A2 <= t < TILE_ID_A3
def is_a3(t): return TILE_ID_A3 <= t < TILE_ID_A4
def is_a4(t): return TILE_ID_A4 <= t < TILE_ID_MAX
def is_a5(t): return TILE_ID_A5 <= t < TILE_ID_A1
def is_shadowing(t): return is_a3(t) or is_a4(t)


class Tileset:
    """Loads the 9 tileset sheets (A1 A2 A3 A4 A5 B C D E) and flags."""

    def __init__(self, tsdef, img_dir, find_image):
        self.flags = tsdef['flags']
        self.sheets = []
        self.name = tsdef['name']
        for n in tsdef['tilesetNames']:
            p = find_image(img_dir, n) if n else None
            self.sheets.append(Image.open(p).convert('RGBA') if p else None)

    def flag(self, t):
        return self.flags[t] if 0 <= t < len(self.flags) else 0

    def higher(self, t): return bool(self.flag(t) & 0x10)
    def table_tile(self, t): return is_a2(t) and bool(self.flag(t) & 0x80)

    # ------------------------------------------------------------------ passability
    def passable_bit(self, tiles_top_first, bit):
        for t in tiles_top_first:
            f = self.flag(t)
            if f & 0x10:
                continue
            if (f & bit) == 0:
                return True
            if (f & bit) == bit:
                return False
        return False

    # ------------------------------------------------------------------ drawing helpers
    def _blit(self, canvas, setno, sx, sy, dx, dy, w, h):
        if setno == -1:     # shadow
            sh = Image.new('RGBA', (w, h), (0, 0, 0, 128))
            canvas.alpha_composite(sh, (dx, dy))
            return
        sheet = self.sheets[setno] if 0 <= setno < len(self.sheets) else None
        if sheet is None:
            return
        # crop() pads out-of-range with transparent which matches PIXI behaviour closely enough
        piece = sheet.crop((sx, sy, sx + w, sy + h))
        canvas.alpha_composite(piece, (dx, dy))

    def draw_tile(self, canvas, t):
        if not is_visible(t):
            return
        if is_autotile(t):
            self._draw_autotile(canvas, t)
        else:
            self._draw_normal(canvas, t)

    def _draw_normal(self, canvas, t):
        setno = 4 if is_a5(t) else 5 + t // 256
        w = h = TILE
        sx = ((t // 128) % 2 * 8 + (t % 8)) * w
        sy = ((t % 256) // 8 % 16) * h
        self._blit(canvas, setno, sx, sy, 0, 0, w, h)

    def _draw_autotile(self, canvas, t):
        kind, shape = kind_of(t), shape_of(t)
        tx, ty = kind % 8, kind // 8
        setno = bx = by = 0
        table = FLOOR_AUTOTILE_TABLE
        is_table = False
        anim = 0  # frame 0 of water animation
        if is_a1(t):
            wsi = [0, 1, 2, 1][anim % 4]
            setno = 0
            if kind == 0:   bx, by = wsi * 2, 0
            elif kind == 1: bx, by = wsi * 2, 3
            elif kind == 2: bx, by = 6, 0
            elif kind == 3: bx, by = 6, 3
            else:
                bx = (tx // 4) * 8
                by = ty * 6 + (tx // 2 % 2) * 3
                if kind % 2 == 0:
                    bx += wsi * 2
                else:
                    bx += 6
                    table = WATERFALL_AUTOTILE_TABLE
                    by += anim % 3
        elif is_a2(t):
            setno, bx, by = 1, tx * 2, (ty - 2) * 3
            is_table = self.table_tile(t)
        elif is_a3(t):
            setno, bx, by = 2, tx * 2, (ty - 6) * 2
            table = WALL_AUTOTILE_TABLE
        elif is_a4(t):
            setno = 3
            bx = tx * 2
            by = int(np.floor((ty - 10) * 2.5 + (0.5 if ty % 2 == 1 else 0)))
            if ty % 2 == 1:
                table = WALL_AUTOTILE_TABLE
        tb = table[shape]
        w1 = h1 = TILE // 2
        for i in range(4):
            qsx, qsy = tb[i]
            sx1 = (bx * 2 + qsx) * w1
            sy1 = (by * 2 + qsy) * h1
            dx1 = (i % 2) * w1
            dy1 = (i // 2) * h1
            if is_table and (qsy == 1 or qsy == 5):
                qsx2 = (4 - qsx) % 4 if qsy == 1 else qsx
                qsy2 = 3
                sx2 = (bx * 2 + qsx2) * w1
                sy2 = (by * 2 + qsy2) * h1
                self._blit(canvas, setno, sx2, sy2, dx1, dy1, w1, h1)
                self._blit(canvas, setno, sx1, sy1, dx1, dy1 + h1 // 2, w1, h1 // 2)
            else:
                self._blit(canvas, setno, sx1, sy1, dx1, dy1, w1, h1)

    def draw_table_edge(self, canvas, t):
        if not is_a2(t):
            return
        kind, shape = kind_of(t), shape_of(t)
        tx, ty = kind % 8, kind // 8
        bx, by = tx * 2, (ty - 2) * 3
        tb = FLOOR_AUTOTILE_TABLE[shape]
        w1 = h1 = TILE // 2
        for i in range(2):
            qsx, qsy = tb[2 + i]
            sx1 = (bx * 2 + qsx) * w1
            sy1 = (by * 2 + qsy) * h1 + h1 // 2
            dx1 = (i % 2) * w1
            dy1 = (i // 2) * h1
            self._blit(canvas, 1, sx1, sy1, dx1, dy1, w1, h1 // 2)

    def draw_shadow(self, canvas, bits):
        w1 = h1 = TILE // 2
        for i in range(4):
            if bits & (1 << i):
                self._blit(canvas, -1, 0, 0, (i % 2) * w1, (i // 2) * h1, w1, h1)

    # ------------------------------------------------------------------ cell baking
    def cell_ops(self, get, mx, my):
        """Returns (lower_ops, upper_ops) lists as in Tilemap._addSpot."""
        t0, t1, t2, t3 = (get(mx, my, z) for z in range(4))
        sh = get(mx, my, 4)
        up1 = get(mx, my - 1, 1)
        lower, upper = [], []

        def spot(t):
            if self.higher(t):
                upper.append(('t', t))
            else:
                lower.append(('t', t))
        spot(t0)
        spot(t1)
        if sh & 0x0f:
            lower.append(('s', sh & 0x0f))
        if self.table_tile(up1) and not self.table_tile(t1):
            if not is_shadowing(t0):
                lower.append(('e', up1))
        spot(t2)
        spot(t3)
        lower = [o for o in lower if o[0] != 't' or is_visible(o[1])]
        upper = [o for o in upper if o[0] != 't' or is_visible(o[1])]
        return tuple(lower), tuple(upper)

    def render_ops(self, ops):
        canvas = Image.new('RGBA', (TILE, TILE), (0, 0, 0, 0))
        for kind, v in ops:
            if kind == 't':
                tmp = Image.new('RGBA', (TILE, TILE), (0, 0, 0, 0))
                self.draw_tile(tmp, v)
                canvas.alpha_composite(tmp)
            elif kind == 's':
                self.draw_shadow(canvas, v)
            elif kind == 'e':
                tmp = Image.new('RGBA', (TILE, TILE), (0, 0, 0, 0))
                self.draw_table_edge(tmp, v)
                canvas.alpha_composite(tmp)
        return canvas


def downscale_half(img):
    """Premultiplied-alpha 2x2 box filter, 48 -> 24 (or any even size)."""
    a = np.asarray(img.convert('RGBA'), dtype=np.float32)
    h, w = a.shape[:2]
    alpha = a[..., 3:4] / 255.0
    pm = a[..., :3] * alpha
    pm = pm.reshape(h // 2, 2, w // 2, 2, 3).mean((1, 3))
    al = alpha.reshape(h // 2, 2, w // 2, 2, 1).mean((1, 3))
    rgb = np.where(al > 1e-6, pm / np.maximum(al, 1e-6), 0)
    out = np.concatenate([rgb, al * 255.0], -1)
    return Image.fromarray(np.clip(out + 0.5, 0, 255).astype(np.uint8), 'RGBA')


def resize_pm(img, size):
    """High quality resize with proper alpha handling (via premultiplied RGBa)."""
    return img.convert('RGBa').resize(size, Image.LANCZOS).convert('RGBA')


def is_empty(img):
    return not np.asarray(img)[..., 3].any()
