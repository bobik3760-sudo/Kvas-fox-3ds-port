#!/bin/sh
# Converts every gfx_src/*.png to romfs/gfx/*.t3x (3DS GPU texture format) with tex3ds.
set -e
mkdir -p romfs/gfx
n=0
for f in gfx_src/*.png; do
    name=$(basename "$f" .png)
    out="romfs/gfx/$name.t3x"
    if [ ! -f "$out" ] || [ "$f" -nt "$out" ]; then
        tex3ds -f rgba -z auto -o "$out" "$f"
        n=$((n+1))
    fi
done
echo "textures: converted $n file(s), $(ls romfs/gfx | wc -l) total"
