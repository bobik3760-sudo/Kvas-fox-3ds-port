/* audio.c - BGM/ME streaming and SE playback on top of the platform PCM output.
 * Audio files are "KIMA" containers (see tools/convert.py) holding mono IMA-ADPCM blocks. */
#include "game.h"
#include <stdio.h>
#include <stdlib.h>

static const int16_t STEP[89] = {
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107,
    118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963,
    1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894,
    6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767 };
static const int8_t IDXADJ[8] = { -1, -1, -1, -1, 2, 4, 6, 8 };

/* decodes one IMA-ADPCM WAV block (mono). returns number of samples written */
int ima_decode_block(const uint8_t *blk, int blockAlign, int16_t *out)
{
    int pred = (int16_t)(blk[0] | (blk[1] << 8));
    int idx = clampi(blk[2], 0, 88);
    int n = 0;
    out[n++] = (int16_t)pred;
    for (int i = 4; i < blockAlign; i++) {
        for (int h = 0; h < 2; h++) {
            int nib = h == 0 ? (blk[i] & 15) : (blk[i] >> 4);
            int step = STEP[idx];
            int diff = ((2 * (nib & 7) + 1) * step) >> 3;    /* same rounding as ffmpeg's adpcm_ima_wav */
            if (nib & 8) diff = -diff;
            pred = clampi(pred + diff, -32768, 32767);
            idx = clampi(idx + IDXADJ[nib & 7], 0, 88);
            out[n++] = (int16_t)pred;
        }
    }
    return n;
}

typedef struct {
    FILE *f; int rate, blockAlign, spb; uint32_t total, dataBytes, readBytes;
    uint8_t *blk; int loop, done;
} Stream;

static bool stream_open(Stream *s, int id, int loop)
{
    memset(s, 0, sizeof *s);
    char path[64]; snprintf(path, sizeof path, "audio/a%03d.ima", id);
    s->f = plat_open_rom(path);
    if (!s->f) return false;
    uint8_t hd[24];
    if (fread(hd, 1, 24, s->f) != 24 || memcmp(hd, "KIMA", 4)) { fclose(s->f); s->f = NULL; return false; }
    uint32_t v[5]; memcpy(v, hd + 4, 20);
    s->rate = (int)v[0]; s->blockAlign = (int)v[1]; s->spb = (int)v[2]; s->total = v[3]; s->dataBytes = v[4];
    if (s->blockAlign < 8 || s->blockAlign > 8192) { fclose(s->f); s->f = NULL; return false; }
    s->blk = malloc(s->blockAlign);
    s->loop = loop;
    return true;
}
static void stream_close(Stream *s) { if (s->f) fclose(s->f); free(s->blk); memset(s, 0, sizeof *s); }

/* decodes the next block into out (capacity >= 8192*2); returns samples or 0 at the end */
static int stream_next(Stream *s, int16_t *out)
{
    if (!s->f || s->done) return 0;
    if (s->readBytes + s->blockAlign > s->dataBytes) {
        if (!s->loop) { s->done = 1; return 0; }
        fseek(s->f, 24, SEEK_SET); s->readBytes = 0;
    }
    if (fread(s->blk, 1, s->blockAlign, s->f) != (size_t)s->blockAlign) {
        if (!s->loop) { s->done = 1; return 0; }
        fseek(s->f, 24, SEEK_SET); s->readBytes = 0; return 0;
    }
    s->readBytes += s->blockAlign;
    return ima_decode_block(s->blk, s->blockAlign, out);
}

/* ---- BGM / ME state */
static Stream s_bgm;
static int s_bgm_id = -1, s_bgm_vol = 100, s_saved_id = -1, s_saved_vol = 100;
static int s_fade_left, s_fade_total;
static int s_me_active;
static int16_t s_pcm[8200];

void audio_init(void) { plat_audio_init(); }

static void start_stream(int id, int vol, int loop)
{
    plat_bgm_stop();
    stream_close(&s_bgm);
    if (id < 0 || id >= db.naudio) { s_bgm_id = -1; return; }
    if (!stream_open(&s_bgm, id, loop)) { s_bgm_id = -1; return; }
    s_bgm_id = id; s_bgm_vol = vol;
    plat_bgm_volume(vol / 100.0f);
    plat_bgm_start(s_bgm.rate);
}

void audio_bgm(int id, int vol)
{
    if (s_me_active) { s_saved_id = id; s_saved_vol = vol; return; }
    s_fade_left = 0;
    if (id == s_bgm_id && id >= 0) { s_bgm_vol = vol; plat_bgm_volume(vol / 100.0f); return; }
    start_stream(id, vol, 1);
}
void audio_bgm_stop(void) { s_me_active = 0; s_fade_left = 0; start_stream(-1, 0, 0); }
void audio_bgm_fade(int frames) { if (s_bgm_id < 0) return; s_fade_total = s_fade_left = frames < 1 ? 1 : frames; }
int audio_cur_bgm(void) { return s_me_active ? s_saved_id : s_bgm_id; }
void audio_bgm_save(void) { s_saved_id = audio_cur_bgm(); s_saved_vol = s_bgm_vol; }
void audio_bgm_resume(void)
{
    s_me_active = 0;
    if (s_saved_id >= 0) start_stream(s_saved_id, s_saved_vol, 1); else start_stream(-1, 0, 0);
}
void audio_me(int id, int vol)
{
    if (id < 0) return;
    if (!s_me_active) { s_saved_id = s_bgm_id; s_saved_vol = s_bgm_vol; }
    s_me_active = 1;
    start_stream(id, vol, 0);
}

void audio_update(void)
{
    if (s_fade_left > 0) {
        s_fade_left--;
        plat_bgm_volume((s_bgm_vol / 100.0f) * s_fade_left / (float)s_fade_total);
        if (s_fade_left == 0) { s_saved_id = -1; start_stream(-1, 0, 0); }
    }
    if (!s_bgm.f) return;
    while (plat_bgm_free_buffers() > 0) {
        int n = stream_next(&s_bgm, s_pcm);
        if (n <= 0) break;
        plat_bgm_queue(s_pcm, n);
    }
    if (s_me_active && s_bgm.done && !plat_bgm_busy()) {
        s_me_active = 0;
        if (s_saved_id >= 0) start_stream(s_saved_id, s_saved_vol, 1); else start_stream(-1, 0, 0);
    }
}

/* ---- SE: decoded once, cached */
typedef struct { int id; int16_t *pcm; int n, rate; } SeCache;
static SeCache s_se[48];
static int s_nse;

static SeCache *se_load(int id)
{
    for (int i = 0; i < s_nse; i++) if (s_se[i].id == id) return &s_se[i];
    if (s_nse >= 48) return NULL;
    Stream st;
    if (!stream_open(&st, id, 0)) return NULL;
    int cap = (int)st.total + st.spb + 16;
    if (cap > 22050 * 4) cap = 22050 * 4;               /* at most ~4 s */
    int16_t *buf = malloc((size_t)cap * 2 + 16384);
    int n = 0, k;
    while (n + st.spb < cap && (k = stream_next(&st, s_pcm)) > 0) { memcpy(buf + n, s_pcm, (size_t)k * 2); n += k; }
    SeCache *c = &s_se[s_nse++];
    c->id = id; c->pcm = buf; c->n = n; c->rate = st.rate;
    stream_close(&st);
    return c;
}

void audio_se(int id, int vol, int pitch)
{
    if (id < 0 || id >= db.naudio) return;
    SeCache *c = se_load(id);
    if (!c || c->n <= 0) return;
    plat_se_play(c->pcm, c->n, c->rate, vol / 100.0f, pitch / 100.0f);
}
void audio_sys(int sysId)
{
    if (sysId < 0 || sysId >= db.nsounds) return;
    audio_se(db.sounds[sysId], 90, 100);
}
