#ifndef STRINGS_UI_H
#define STRINGS_UI_H
/* X(enum, English, Russian) - every on-screen string that is not part of the game's own script */
#define UI_STRINGS(X) \
 X(S_NEWGAME, "New Game", "Новая игра") \
 X(S_CONTINUE, "Continue", "Продолжить") \
 X(S_LANGUAGE, "Language: English", "Язык: Русский") \
 X(S_EXIT, "Exit", "Выход") \
 X(S_FIGHT, "Fight", "Бой") \
 X(S_ESCAPE, "Escape", "Бежать") \
 X(S_ATTACK, "Attack", "Атака") \
 X(S_SKILLS, "Skills", "Навыки") \
 X(S_GUARD, "Guard", "Защита") \
 X(S_ITEMS, "Items", "Предметы") \
 X(S_BACK, "Back", "Назад") \
 X(S_CHOOSE_TARGET, "Choose a target", "Выберите цель") \
 X(S_NOTHING, "Nothing here.", "Здесь пусто.") \
 X(S_B_APPEARED, "%s appeared!", "Появляется: %s!") \
 X(S_B_ATTACKS, "%s attacks!", "%s атакует!") \
 X(S_B_GUARDS, "%s guards.", "%s защищается.") \
 X(S_B_USES, "%s uses %s!", "%s использует: %s!") \
 X(S_B_DAMAGE, "%s takes %d damage!", "%s получает урон: %d!") \
 X(S_B_HEAL, "%s recovers %d HP!", "%s восстанавливает %d HP!") \
 X(S_B_MPDMG, "%s loses %d MP!", "%s теряет %d MP!") \
 X(S_B_MPHEAL, "%s recovers %d MP!", "%s восстанавливает %d MP!") \
 X(S_B_MISS, "%s missed!", "%s промахивается!") \
 X(S_B_EVADE, "%s evaded the attack!", "%s уклоняется!") \
 X(S_B_CRIT, "Critical hit!", "Критический удар!") \
 X(S_B_DEFEATED, "%s was defeated!", "%s повержен!") \
 X(S_B_STATE_ADD, "%s: %s!", "%s: %s!") \
 X(S_B_STATE_OFF, "%s is no longer: %s.", "%s больше не: %s.") \
 X(S_B_NOEFFECT, "It had no effect on %s.", "На %s это не подействовало.") \
 X(S_B_ESCAPE_OK, "The party escaped!", "Отряд сбежал!") \
 X(S_B_ESCAPE_FAIL, "Couldn't escape!", "Не удалось сбежать!") \
 X(S_B_VICTORY, "Victory!", "Победа!") \
 X(S_B_DEFEAT, "The party was defeated...", "Отряд повержен...") \
 X(S_B_EXP, "Gained %d EXP!", "Получено опыта: %d!") \
 X(S_B_GOLD, "Found %d %s!", "Найдено: %d %s!") \
 X(S_B_DROP, "Found %s!", "Найдено: %s!") \
 X(S_B_LEVELUP, "%s reached level %d!", "%s достигает уровня %d!") \
 X(S_B_LEARN, "%s learned %s!", "%s изучает: %s!") \
 X(S_CONTINUE_HINT, "Press A or tap to continue", "Нажмите A или коснитесь экрана") \
 X(S_LV, "Lv", "Ур") \
 X(S_TURN, "Turn %d", "Ход %d") \
 X(S_MENU_ITEMS, "Items", "Предметы") \
 X(S_MENU_SKILLS, "Skills", "Навыки") \
 X(S_MENU_EQUIP, "Equip", "Снаряжение") \
 X(S_MENU_STATUS, "Status", "Статус") \
 X(S_MENU_SAVE, "Save", "Сохранить") \
 X(S_MENU_LOAD, "Load", "Загрузить") \
 X(S_MENU_LANG, "Русский", "English") \
 X(S_MENU_TITLE, "Title", "В меню") \
 X(S_MENU_CLOSE, "Close", "Закрыть") \
 X(S_GOLD, "Gold", "Золото") \
 X(S_WHO, "Who?", "Кому?") \
 X(S_USE, "Use", "Использовать") \
 X(S_EMPTY_SLOT, "- empty -", "- пусто -") \
 X(S_SLOT, "Slot %d", "Слот %d") \
 X(S_SAVED, "Game saved.", "Игра сохранена.") \
 X(S_SAVE_FAILED, "Could not save!", "Не удалось сохранить!") \
 X(S_LOADED, "Game loaded.", "Игра загружена.") \
 X(S_NO_SAVE, "No saved games found.", "Сохранений нет.") \
 X(S_SAVE_HERE, "Choose a slot to save", "Выберите слот для сохранения") \
 X(S_LOAD_HERE, "Choose a slot to load", "Выберите слот для загрузки") \
 X(S_SURE_TITLE, "Return to the title screen?", "Вернуться на титульный экран?") \
 X(S_YES, "Yes", "Да") \
 X(S_NO, "No", "Нет") \
 X(S_BUY, "Buy", "Купить") \
 X(S_SELL, "Sell", "Продать") \
 X(S_LEAVE, "Leave", "Выйти") \
 X(S_OWNED, "Owned: %d", "В наличии: %d") \
 X(S_NOT_ENOUGH, "Not enough money!", "Не хватает денег!") \
 X(S_EQUIPPED, "Equipped", "Надето") \
 X(S_REMOVE, "(remove)", "(снять)") \
 X(S_SLOT_WEAPON, "Weapon", "Оружие") \
 X(S_SLOT_SHIELD, "Shield", "Щит") \
 X(S_SLOT_HEAD, "Head", "Голова") \
 X(S_SLOT_BODY, "Body", "Тело") \
 X(S_SLOT_ACC, "Accessory", "Аксессуар") \
 X(S_P_MHP, "Max HP", "Макс. HP") \
 X(S_P_MMP, "Max MP", "Макс. MP") \
 X(S_P_ATK, "Attack", "Атака") \
 X(S_P_DEF, "Defense", "Защита") \
 X(S_P_MAT, "Magic Atk", "Маг. атака") \
 X(S_P_MDF, "Magic Def", "Маг. защита") \
 X(S_P_AGI, "Agility", "Ловкость") \
 X(S_P_LUK, "Luck", "Удача") \
 X(S_EXP, "EXP", "Опыт") \
 X(S_NEXT, "Next", "След.") \
 X(S_GAMEOVER, "GAME OVER", "КОНЕЦ ИГРЫ") \
 X(S_GO_HINT, "Press A or tap to return to the title", "Нажмите A или коснитесь экрана") \
 X(S_TITLE_HINT, "Press A or tap New Game", "Нажмите A или выберите пункт на нижнем экране") \
 X(S_LANG_SWITCHED, "Language switched", "Язык изменён") \
 X(S_PLAYTIME, "Time %d:%02d", "Время %d:%02d") \
 X(S_CONFIRM, "Overwrite this slot?", "Перезаписать этот слот?") \
 X(S_TAP_NEXT, "A / tap: next", "A / касание: далее") \
 X(S_NO_ITEMS_USABLE, "Can't use that now.", "Сейчас это использовать нельзя.") \
 X(S_HUD_HINT, "D-Pad/Circle Pad: move  A: talk  B: cancel  Y: run", "Крестовина: ходьба  A: говорить  B: отмена  Y: бег") \
 X(S_UNKNOWN_MAP, "", "")
enum {
#define X_ENUM(e, en, ru) e,
UI_STRINGS(X_ENUM)
#undef X_ENUM
S_COUNT };
#endif
