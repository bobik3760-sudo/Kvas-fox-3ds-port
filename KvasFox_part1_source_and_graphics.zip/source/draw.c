/* draw.c - top-screen rendering of the map scene and overlays. */
#include "game.h"
#include <math.h>
#include <stdio.h>

#define VSCALE (240.0f / 624.0f)
#define VLETTER 43.0f
#define MSG_W 392
#define MSG_H 76
#define MSG_TEXT_SCALE 0.5f

static PTex *s_balloon;

/* ----------------------------------------------------------------------------- tiles */
static void draw_tile_layer(const uint16_t *layer, int x0, int y0, int x1, int y1)
{
    for (int y = y0; y <= y1; y++) {
        if (y < 0 || y >= M.h) continue;
        for (int x = x0; x <= x1; x++) {
            if (x < 0 || x >= M.w) continue;
            int v = layer[y * M.w + x];
            if (!v) continue;
            int n = v - 1, base = 0;
            for (int p = 0; p < M.natlas; p++) {
                if (n < base + M.atlas[p].cap) {
                    int slot = n - base;
                    int sx = (slot % M.atlas[p].cols) * TILE, sy = (slot / M.atlas[p].cols) * TILE;
                    float dx = floorf((x - g_disp_x) * TILE), dy = floorf((y - g_disp_y) * TILE);
                    if (M.atlas[p].tex) plat_blit(M.atlas[p].tex, sx, sy, TILE, TILE, dx, dy, 1.0f, false, 255);
                    break;
                }
                base += M.atlas[p].cap;
            }
        }
    }
}

/* ----------------------------------------------------------------------------- characters */
static int char_z(const Char *c) { return c->priority * 2 + 1; }

static void draw_char(const Char *c)
{
    if (c->sheet < 0 || c->sheet >= db.nchars) return;
    PTex *t = map_sheet_tex(c->sheet);
    if (!t) return;
    const CharSheetInfo *ci = &db.chars[c->sheet];
    int big = ci->flags & 1;
    int bx = big ? 0 : (c->index % 4) * 3, by = big ? 0 : (c->index / 4) * 4;
    int row = (c->dir - 2) / 2; if (row < 0) row = 0; if (row > 3) row = 3;
    int pat = c->pattern < 3 ? c->pattern : 1;
    int sx = (bx + pat) * ci->cw, sy = (by + row) * ci->ch;
    int dx = char_screen_x(c) - ci->cw / 2, dy = char_screen_y(c) - ci->ch;
    plat_blit(t, sx, sy, ci->cw, ci->ch, (float)dx, (float)dy, 1.0f, false, c->opacity);
}

static void draw_balloon(const Char *c)
{
    if (!c->balloon || c->balloonCount <= 0) return;
    if (!s_balloon) s_balloon = plat_tex_load("balloon");
    if (!s_balloon) return;
    int elapsed = 76 - c->balloonCount; if (elapsed < 0) elapsed = 0;
    int frame = elapsed / 8; if (frame > 7) frame = 7;
    int ch = (c->sheet >= 0 && c->sheet < db.nchars) ? db.chars[c->sheet].ch : TILE;
    plat_blit(s_balloon, frame * 24, (c->balloon - 1) * 24, 24, 24, (float)(char_screen_x(c) - 12), (float)(char_screen_y(c) - ch - 22), 1.0f, false, 255);
}

typedef struct { const Char *c; int z, y; } Drawable;

static void draw_world(void)
{
    int x0 = (int)floorf(g_disp_x) - 1, y0 = (int)floorf(g_disp_y) - 1;
    int x1 = (int)ceilf(g_disp_x + SCR_W / (float)TILE) + 1, y1 = (int)ceilf(g_disp_y + SCR_H / (float)TILE) + 1;
    draw_tile_layer(M.lower, x0, y0, x1, y1);

    Drawable d[MAX_EV + MAX_PARTY + 1]; int n = 0;
    for (int i = 0; i < g_nevs; i++) {
        const Char *c = &evs[i];
        if (c->erased || c->pageIdx < 0 || c->transparent || c->sheet < 0) continue;
        d[n].c = c; d[n].z = char_z(c); d[n].y = char_screen_y(c); n++;
    }
    if (db.followers && g.nparty > 1)
        for (int i = g.nparty - 2; i >= 0; i--) {
            if (i >= MAX_PARTY - 1) continue;
            const Char *c = &followers[i];
            if (c->sheet < 0) continue;
            d[n].c = c; d[n].z = 3; d[n].y = char_screen_y(c) - (i + 1) * 0; n++;
        }
    if (!player.transparent && player.sheet >= 0) { d[n].c = &player; d[n].z = 3; d[n].y = char_screen_y(&player); n++; }
    for (int i = 1; i < n; i++) {         /* insertion sort by (z, y) */
        Drawable k = d[i]; int j = i - 1;
        while (j >= 0 && (d[j].z > k.z || (d[j].z == k.z && d[j].y > k.y))) { d[j + 1] = d[j]; j--; }
        d[j + 1] = k;
    }
    int i = 0;
    for (; i < n && d[i].z < 4; i++) draw_char(d[i].c);
    draw_tile_layer(M.upper, x0, y0, x1, y1);
    for (; i < n; i++) draw_char(d[i].c);
    for (int k = 0; k < n; k++) draw_balloon(d[k].c);
}

/* ----------------------------------------------------------------------------- message window */
static void draw_message_window(void)
{
    if (!msg.active || msg.textStr < 0 || msg.pageLines <= 0) return;
    float x = (SCR_W - MSG_W) / 2.0f;
    float y = msg.pos == 0 ? 4 : (msg.pos == 1 ? (SCR_H - MSG_H) / 2.0f : SCR_H - MSG_H - 4);
    if (msg.bg == 0) ui_draw_window(x, y, MSG_W, MSG_H);
    else if (msg.bg == 1) plat_rect(x, y, MSG_W, MSG_H, RGBA(0, 0, 0, 150));
    float tx0 = x + 10;
    if (msg.face >= 0) {
        PTex *ft = face_tex(msg.face);
        if (ft) plat_blit(ft, (msg.faceIdx % 4) * 72, (msg.faceIdx / 4) * 72, 72, 72, x + 6, y + 2, 1.0f, false, 255);
        tx0 = x + 82;
    }
    if (msg.nameStr >= 0) {
        const char *nm = tx(msg.nameStr);
        float w = plat_text_w(nm, 0.5f) + 16;
        ui_draw_window(x + 8, y - 17, w, 19);
        plat_text(nm, x + 16, y - 16, 0.5f, RGBA(255, 235, 150, 255));
    }
    int remaining = msg.shown;
    for (int i = 0; i < msg.pageLines && remaining > 0; i++) {
        const char *ln = msg.lines[msg.pageStart + i];
        int len = (int)strlen(ln);
        char buf[200];
        if (remaining >= len + 1) { snprintf(buf, sizeof buf, "%s", ln); }
        else { snprintf(buf, sizeof buf, "%s", ln); utf8_trim_to(buf, remaining); }
        float ty = y + 8 + i * 16;
        if (msg.bg == 2) plat_text(buf, tx0 + 1, ty + 1, MSG_TEXT_SCALE, RGBA(0, 0, 0, 255));
        plat_text(buf, tx0, ty, MSG_TEXT_SCALE, RGBA(255, 255, 255, 255));
        remaining -= len + 1;
    }
    int total = 0; for (int i = 0; i < msg.pageLines; i++) total += (int)strlen(msg.lines[msg.pageStart + i]) + 1;
    int pages = (msg.nlines + 3) / 4;
    if (msg.shown >= total && !msg.hasChoices && ((g_frame / 20) & 1))
        plat_text(msg.page + 1 < pages ? "v" : "o", x + MSG_W - 18, y + MSG_H - 18, 0.5f, RGBA(255, 255, 255, 255));
}

void draw_messages(void) { draw_message_window(); }

/* ----------------------------------------------------------------------------- pictures, scroll text, fade */
static void draw_pics(void)
{
    for (int i = 1; i < MAX_PIC; i++) {
        const Pic *p = &pics[i];
        if (!p->used || !p->tex) continue;
        const ImgInfo *im = &db.pics[p->pic];
        float s = (p->sx / 100.0f);
        float w = im->w * s, h = im->h * s;
        float dx = VLETTER + p->x * VSCALE, dy = p->y * VSCALE;
        if (p->origin == 1) { dx -= w / 2; dy -= h / 2; }
        plat_blit(p->tex, 0, 0, im->w, im->h, dx, dy, s, false, p->opacity);
    }
}

static void draw_scroll(void)
{
    if (!scrolltext.active) return;
    plat_rect(0, 0, SCR_W, SCR_H, RGBA(0, 0, 0, 190));
    for (int i = 0; i < scrolltext.nlines; i++) {
        float y = scrolltext.y + i * 14;
        if (y < -14 || y > SCR_H) continue;
        plat_text(tx(scrolltext.str[i]), 20, y, 0.5f, RGBA(255, 255, 255, 255));
    }
}

static void draw_fade(void)
{
    if (g_fade <= 0) return;
    uint32_t c = g_fade_white ? RGBA(255, 255, 255, g_fade) : RGBA(0, 0, 0, g_fade);
    plat_rect(0, 0, SCR_W, SCR_H, c);
}

void draw_pics_and_fade(void) { draw_pics(); draw_scroll(); draw_fade(); }

/* ----------------------------------------------------------------------------- scene */
void draw_map_scene(void)
{
    plat_target(0);
    plat_rect(0, 0, SCR_W, SCR_H, RGBA(0, 0, 0, 255));
    if (M.raw) draw_world();
    draw_pics();
    ui_draw_menu_top();
    draw_message_window();
    draw_scroll();
    draw_fade();
    plat_target(1);
    if (msg.active && msg.hasChoices) ui_choice_draw();
    else ui_draw_map_bottom();
}
