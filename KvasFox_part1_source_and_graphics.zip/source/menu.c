/* menu.c - bottom-screen HUD while exploring, the sub-menus and the shop.
 * The top screen keeps showing the game; ui_draw_menu_top() adds info panels on it. */
#include "game.h"
#include <stdarg.h>
#include <stdio.h>
#include <math.h>

enum { MS_HUD, MS_ITEMS, MS_ITEM_TGT, MS_SK_ACTOR, MS_SK_LIST, MS_SK_TGT, MS_EQ_ACTOR, MS_EQ_SLOT, MS_EQ_ITEM, MS_STATUS,
       MS_SAVE, MS_LOAD, MS_TITLE };

static int ms, selActor, selSlot, selId, pcur, s_from_event;
static UiList L;
static int s_ids[LIST_MAX];
static char s_toast[96]; static int s_toast_t;
static int s_confirm_slot = -1;

bool ui_menu_open(void) { return ms != MS_HUD; }
bool ui_save_active(void) { return ms == MS_SAVE && s_from_event; }

static void toast(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void toast(const char *fmt, ...)
{
    va_list ap; va_start(ap, fmt); vsnprintf(s_toast, sizeof s_toast, fmt, ap); va_end(ap);
    s_toast_t = 150;
}

static bool can_open(void)
{
    return !g_interp.running && !msg_busy() && !player_transfer_pending() && g_fade == g_fade_target && g_fade == 0 &&
           !player.forcing && !char_is_moving(&player) && !scrolltext.active && !ui_shop_active() && !g.menuDisabled;
}

static void new_list(void) { ui_list_init(&L, 10, 34, 300, 196, 26); ui_list_clear(&L); }

/* ----------------------------------------------------------------------------- list builders */
static bool item_menu_usable(int id)
{
    const ItemDef *it = &db.items[id];
    return (it->occasion == 0 || it->occasion == 2) && it->scope > 0;
}

static void build_items(void)
{
    new_list();
    for (int i = 1; i < db.nitems && i < MAX_DB && L.n < LIST_MAX; i++) {
        if (!db.items[i].exists || g.items[i] <= 0) continue;
        char cnt[20]; snprintf(cnt, sizeof cnt, "x%d", g.items[i]);
        s_ids[L.n] = i;
        ui_list_add(&L, tx(db.items[i].name), cnt, item_menu_usable(i));
    }
}

static void build_skills(Battler *a)
{
    new_list();
    for (int s = 1; s < db.nskills && s < MAX_DB && L.n < LIST_MAX; s++) {
        if (!db.skills[s].exists || !actor_skill_known(a, s)) continue;
        const SkillDef *sk = &db.skills[s];
        if (sk->occasion != 0 && sk->occasion != 2) continue;
        if (sk->scope == 0) continue;
        char cost[20] = ""; if (sk->mpCost) snprintf(cost, sizeof cost, "MP %d", (int)floorf(sk->mpCost * b_sparam(a, 4)));
        s_ids[L.n] = s;
        ui_list_add(&L, tx(sk->name), cost, skill_can_pay(a, s));
    }
}

static const char *slot_label(int s)
{
    switch (s) { case 0: return ui_s(S_SLOT_WEAPON); case 1: return ui_s(S_SLOT_SHIELD); case 2: return ui_s(S_SLOT_HEAD);
                 case 3: return ui_s(S_SLOT_BODY); default: return ui_s(S_SLOT_ACC); }
}
static const char *equip_name(int slot, int id)
{
    if (!id) return "-";
    if (slot == 0) return id < db.nweapons ? tx(db.weapons[id].name) : "?";
    return id < db.narmors ? tx(db.armors[id].name) : "?";
}

static void build_slots(Battler *a)
{
    new_list();
    for (int s = 0; s < 5; s++) ui_list_add(&L, slot_label(s), equip_name(s, a->equips[s]), true);
    L.rowH = 30; L.h = 180;
}

static bool has_any_trait(const Battler *b, int code)
{
    for (int i = 0; i < 40; i++) if (b_trait_has(b, code, i)) return true;
    return false;
}
static bool can_equip(const Battler *a, int slot, int id)
{
    if (slot == 0) {
        if (id >= db.nweapons || !db.weapons[id].exists) return false;
        return !has_any_trait(a, 51) || b_trait_has(a, 51, db.weapons[id].kind);
    }
    if (id >= db.narmors || !db.armors[id].exists || db.armors[id].etype != slot + 1) return false;
    return !has_any_trait(a, 52) || b_trait_has(a, 52, db.armors[id].kind);
}

static void build_equip_items(Battler *a, int slot)
{
    new_list();
    ui_list_add(&L, ui_s(S_REMOVE), "", true); s_ids[0] = 0;
    int max = slot == 0 ? db.nweapons : db.narmors;
    for (int i = 1; i < max && i < MAX_DB && L.n < LIST_MAX; i++) {
        int cnt = slot == 0 ? g.weapons[i] : g.armors[i];
        if (cnt <= 0 || !can_equip(a, slot, i)) continue;
        char c[20]; snprintf(c, sizeof c, "x%d", cnt);
        s_ids[L.n] = i;
        ui_list_add(&L, equip_name(slot, i), c, true);
    }
}

/* ----------------------------------------------------------------------------- applying items / skills */
static void use_action(BAction a, Battler *user, int targetIdx)
{
    int scope = action_scope(&a);
    Battler *tg[MAX_PARTY]; int n = 0;
    if (scope == 8 || scope == 10) {
        for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b && (scope == 10) == (b_dead(b) != 0)) tg[n++] = b; }
    } else if (scope == 11) tg[n++] = user;
    else { Battler *b = party_member(targetIdx); if (b) tg[n++] = b; }
    bool any = false; char info[96] = "";
    for (int i = 0; i < n; i++) {
        ActResult r; action_apply(user, &a, tg[i], &r, false);
        if (r.used && r.hit) {
            any = true;
            if (r.hpDmg < 0) snprintf(info, sizeof info, "%s: HP +%d", b_name(tg[i]), -r.hpDmg);
            else if (r.mpDmg < 0) snprintf(info, sizeof info, "%s: MP +%d", b_name(tg[i]), -r.mpDmg);
            else snprintf(info, sizeof info, "%s", b_name(tg[i]));
        }
    }
    if (!any) { audio_sys(SND_BUZZER); toast("%s", ui_s(S_NO_ITEMS_USABLE)); return; }
    if (a.kind == 4) { if (db.items[a.id].consumable) item_gain(0, a.id, -1); audio_sys(SND_USE_ITEM); }
    else { skill_pay(user, a.id); audio_sys(SND_RECOVERY); }
    toast("%s", info);
}

/* ----------------------------------------------------------------------------- shop */
static int shop_on, shop_mode;   /* 0 buy 1 sell */
static UiList SL;
static int sl_kind[LIST_MAX], sl_id[LIST_MAX], sl_price[LIST_MAX];

static int base_price(int kind, int id)
{
    if (kind == 0) return id < db.nitems ? db.items[id].price : 0;
    if (kind == 1) return id < db.nweapons ? db.weapons[id].price : 0;
    return id < db.narmors ? db.armors[id].price : 0;
}
static const char *kind_name(int kind, int id)
{
    if (kind == 0) return id < db.nitems ? tx(db.items[id].name) : "?";
    if (kind == 1) return id < db.nweapons ? tx(db.weapons[id].name) : "?";
    return id < db.narmors ? tx(db.armors[id].name) : "?";
}

static void shop_build(void)
{
    int keepCur = SL.cursor, keepScroll = SL.scroll;
    ui_list_init(&SL, 10, 62, 300, 170, 26);
    ui_list_clear(&SL);
    if (shop_mode == 0) {
        for (int i = 0; i < g_shop.n; i++) {
            int price = g_shop.price[i] >= 0 ? g_shop.price[i] : base_price(g_shop.kind[i], g_shop.id[i]);
            char p[20]; snprintf(p, sizeof p, "%d", price);
            sl_kind[SL.n] = g_shop.kind[i]; sl_id[SL.n] = g_shop.id[i]; sl_price[SL.n] = price;
            ui_list_add(&SL, kind_name(g_shop.kind[i], g_shop.id[i]), p, g.gold >= price && item_count(g_shop.kind[i], g_shop.id[i]) < 99);
        }
    } else {
        for (int kind = 0; kind < 3; kind++) {
            int max = kind == 0 ? db.nitems : (kind == 1 ? db.nweapons : db.narmors);
            for (int i = 1; i < max && i < MAX_DB && SL.n < LIST_MAX; i++) {
                if (item_count(kind, i) <= 0) continue;
                if (kind == 0 && db.items[i].itype != 1) continue;
                int price = base_price(kind, i) / 2;
                char p[24]; snprintf(p, sizeof p, "x%d  %d", item_count(kind, i), price);
                sl_kind[SL.n] = kind; sl_id[SL.n] = i; sl_price[SL.n] = price;
                ui_list_add(&SL, kind_name(kind, i), p, price > 0);
            }
        }
    }
    SL.cursor = SL.n ? clampi(keepCur, 0, SL.n - 1) : 0; SL.scroll = keepScroll;
}

void ui_shop_begin(void) { shop_on = 1; shop_mode = 0; memset(&SL, 0, sizeof SL); shop_build(); audio_sys(SND_SHOP); }
bool ui_shop_active(void) { return shop_on; }

static void shop_update(void)
{
    if (ui_tap(10, 4, 70, 26) || (g_in.down & K_L)) { if (shop_mode != 0) { shop_mode = 0; memset(&SL, 0, sizeof SL); shop_build(); audio_sys(SND_CURSOR); } }
    if ((ui_tap(84, 4, 70, 26) || (g_in.down & K_R)) && !g_shop.purchaseOnly) { if (shop_mode != 1) { shop_mode = 1; memset(&SL, 0, sizeof SL); shop_build(); audio_sys(SND_CURSOR); } }
    if (ui_tap(240, 4, 70, 26) || (g_in.down & K_B)) { shop_on = 0; audio_sys(SND_CANCEL); return; }
    int r = ui_list_update(&SL);
    if (r < 0 || r >= SL.n) return;
    int kind = sl_kind[r], id = sl_id[r], price = sl_price[r];
    if (shop_mode == 0) {
        if (g.gold >= price && item_count(kind, id) < 99) { g.gold -= price; item_gain(kind, id, 1); audio_sys(SND_SHOP); }
        else { audio_sys(SND_BUZZER); toast("%s", ui_s(S_NOT_ENOUGH)); }
    } else {
        item_gain(kind, id, -1); g.gold = clampi(g.gold + price, 0, 99999999); audio_sys(SND_SHOP);
    }
    shop_build();
}

static void shop_draw(void)
{
    plat_rect(0, 0, BSCR_W, BSCR_H, RGBA(18, 18, 34, 255));
    ui_button(10, 4, 70, 26, ui_s(S_BUY), true, NULL);
    ui_button(84, 4, 70, 26, ui_s(S_SELL), !g_shop.purchaseOnly, NULL);
    ui_button(240, 4, 70, 26, ui_s(S_LEAVE), true, NULL);
    plat_rect(shop_mode ? 84 : 10, 30, 70, 3, RGBA(255, 230, 90, 255));
    char t[80]; snprintf(t, sizeof t, "%s: %d %s", ui_s(S_GOLD), g.gold, tx(db.currency));
    plat_text(t, 12, 38, 0.5f, RGBA(255, 235, 150, 255));
    if (SL.n && SL.cursor < SL.n) {
        snprintf(t, sizeof t, ui_s(S_OWNED), item_count(sl_kind[SL.cursor], sl_id[SL.cursor]));
        plat_text(t, 200, 38, 0.45f, RGBA(200, 210, 255, 255));
    }
    ui_list_draw(&SL);
    if (s_toast_t > 0) ui_text_centered(s_toast, 160, 222, 0.5f, RGBA(255, 160, 160, 255));
}

/* ----------------------------------------------------------------------------- state changes */
static void enter(int state)
{
    ms = state; pcur = 0; s_confirm_slot = -1;
    Battler *a = party_member(selActor);
    switch (state) {
        case MS_ITEMS: build_items(); break;
        case MS_SK_LIST: if (a) build_skills(a); break;
        case MS_EQ_SLOT: if (a) build_slots(a); break;
        case MS_SAVE: ui_build_slot_list(&L, true); L.y = 40; L.h = 150; L.rowH = 40; break;
        case MS_LOAD: ui_build_slot_list(&L, false); L.y = 40; L.h = 150; L.rowH = 40; break;
        default: break;
    }
}

/* choose a party member: returns 1 = picked (in *out), -1 = cancelled, 0 = nothing */
static int pick_party(int *out)
{
    int n = g.nparty;
    if (n <= 0) return -1;
    if (g_in.down & K_UP) { pcur = (pcur + n - 1) % n; audio_sys(SND_CURSOR); }
    if (g_in.down & K_DOWN) { pcur = (pcur + 1) % n; audio_sys(SND_CURSOR); }
    for (int i = 0; i < n; i++) if (ui_tap(6, 38 + i * 40, 308, 36)) { pcur = i; *out = i; audio_sys(SND_OK); return 1; }
    if (g_in.down & K_A) { *out = pcur; audio_sys(SND_OK); return 1; }
    if ((g_in.down & K_B) || ui_tap(250, 4, 66, 22)) { audio_sys(SND_CANCEL); return -1; }
    return 0;
}

static void draw_pick_party(const char *title)
{
    plat_text(title, 8, 8, 0.55f, RGBA(255, 235, 150, 255));
    ui_button(250, 4, 66, 22, ui_s(S_BACK), true, NULL);
    for (int i = 0; i < g.nparty; i++) {
        Battler *b = party_member(i); if (!b) continue;
        float y = 38 + i * 40;
        if (i == pcur) plat_rect(3, y - 3, 314, 40, RGBA(110, 100, 30, 220));
        ui_status_row(6, y, 308, b, true);
    }
}

void ui_update_map(void)
{
    if (s_toast_t > 0) s_toast_t--;
    if (shop_on) { shop_update(); return; }
    if (ms == MS_HUD) {
        if (!can_open()) return;
        int pick = -1;
        const int bx0 = 6, bw = 74, gap = 5;
        for (int i = 0; i < 8; i++) if (ui_tap(bx0 + (i % 4) * (bw + gap), 168 + (i / 4) * 36, bw, 32)) pick = i;
        if (g_in.down & K_X) pick = 0;
        if (g_in.down & K_L) pick = 1;
        if (g_in.down & K_R) pick = 3;
        if (g_in.down & K_START) pick = 4;
        if (pick < 0) return;
        audio_sys(SND_OK);
        switch (pick) {
            case 0: enter(MS_ITEMS); break;
            case 1: selActor = 0; enter(MS_SK_ACTOR); break;
            case 2: selActor = 0; enter(MS_EQ_ACTOR); break;
            case 3: selActor = 0; enter(MS_STATUS); break;
            case 4: if (g.saveDisabled) { audio_sys(SND_BUZZER); toast("%s", ui_s(S_NO_ITEMS_USABLE)); } else enter(MS_SAVE); break;
            case 5: enter(MS_LOAD); break;
            case 6: ui_toggle_lang(); toast("%s", ui_s(S_LANG_SWITCHED)); break;
            case 7: enter(MS_TITLE); break;
        }
        return;
    }
    if ((g_in.down & K_SELECT)) { ui_toggle_lang(); if (ms == MS_SAVE && s_from_event) enter(MS_SAVE); else ms = MS_HUD; return; }
    Battler *a = party_member(selActor);
    int r, who;
    switch (ms) {
        case MS_ITEMS:
            r = ui_list_update(&L);
            if (r == -1 || ui_tap(250, 4, 66, 22)) { audio_sys(SND_CANCEL); ms = MS_HUD; }
            else if (r >= 0) {
                selId = s_ids[r]; int sc = db.items[selId].scope;
                if (sc == 7 || sc == 9) { ms = MS_ITEM_TGT; pcur = 0; }
                else { use_action((BAction){ 4, selId, 0 }, party_member(0), 0); build_items(); }
            }
            break;
        case MS_ITEM_TGT:
            r = pick_party(&who);
            if (r == -1) { ms = MS_ITEMS; build_items(); }
            else if (r == 1) { use_action((BAction){ 4, selId, who }, party_member(0), who); ms = MS_ITEMS; build_items(); }
            break;
        case MS_SK_ACTOR:
            r = pick_party(&who);
            if (r == -1) ms = MS_HUD; else if (r == 1) { selActor = who; enter(MS_SK_LIST); }
            break;
        case MS_SK_LIST:
            r = ui_list_update(&L);
            if (r == -1 || ui_tap(250, 4, 66, 22)) { audio_sys(SND_CANCEL); ms = MS_SK_ACTOR; pcur = selActor; }
            else if (r >= 0 && a) {
                selId = s_ids[r]; int sc = db.skills[selId].scope;
                if (sc == 7 || sc == 9) { ms = MS_SK_TGT; pcur = 0; }
                else { use_action((BAction){ 3, selId, 0 }, a, 0); build_skills(a); }
            }
            break;
        case MS_SK_TGT:
            r = pick_party(&who);
            if (r == -1) { ms = MS_SK_LIST; if (a) build_skills(a); }
            else if (r == 1 && a) { use_action((BAction){ 3, selId, who }, a, who); ms = MS_SK_LIST; build_skills(a); }
            break;
        case MS_EQ_ACTOR:
            r = pick_party(&who);
            if (r == -1) ms = MS_HUD; else if (r == 1) { selActor = who; enter(MS_EQ_SLOT); }
            break;
        case MS_EQ_SLOT:
            r = ui_list_update(&L);
            if (r == -1 || ui_tap(250, 4, 66, 22)) { audio_sys(SND_CANCEL); ms = MS_EQ_ACTOR; pcur = selActor; }
            else if (r >= 0 && a) { selSlot = r; build_equip_items(a, selSlot); ms = MS_EQ_ITEM; }
            break;
        case MS_EQ_ITEM:
            r = ui_list_update(&L);
            if (r == -1 || ui_tap(250, 4, 66, 22)) { audio_sys(SND_CANCEL); enter(MS_EQ_SLOT); }
            else if (r >= 0 && a) { actor_change_equip(a, selSlot, s_ids[r]); audio_sys(SND_EQUIP); enter(MS_EQ_SLOT); }
            break;
        case MS_STATUS:
            r = pick_party(&who);
            if (r == -1) ms = MS_HUD; else if (r == 1) selActor = who;
            if (r == 0) selActor = pcur;
            break;
        case MS_SAVE: {
            if (s_confirm_slot >= 0) {
                if (ui_tap(30, 120, 120, 44) || (g_in.down & K_A)) {
                    if (save_write(s_confirm_slot)) { audio_sys(SND_SAVE); toast("%s", ui_s(S_SAVED)); } else { audio_sys(SND_BUZZER); toast("%s", ui_s(S_SAVE_FAILED)); }
                    s_confirm_slot = -1; if (s_from_event) { ms = MS_HUD; s_from_event = 0; } else enter(MS_SAVE);
                } else if (ui_tap(170, 120, 120, 44) || (g_in.down & K_B)) { audio_sys(SND_CANCEL); s_confirm_slot = -1; }
                break;
            }
            r = ui_list_update(&L);
            if (r == -1 || ui_tap(220, 200, 90, 30)) { audio_sys(SND_CANCEL); ms = MS_HUD; s_from_event = 0; }
            else if (r >= 0) {
                if (save_info(r, NULL, 0)) s_confirm_slot = r;
                else {
                    if (save_write(r)) { audio_sys(SND_SAVE); toast("%s", ui_s(S_SAVED)); } else { audio_sys(SND_BUZZER); toast("%s", ui_s(S_SAVE_FAILED)); }
                    if (s_from_event) { ms = MS_HUD; s_from_event = 0; } else enter(MS_SAVE);
                }
            }
            break;
        }
        case MS_LOAD:
            r = ui_list_update(&L);
            if (r == -1 || ui_tap(220, 200, 90, 30)) { audio_sys(SND_CANCEL); ms = MS_HUD; }
            else if (r >= 0) { audio_sys(SND_LOAD); ms = MS_HUD; game_begin_load(r); }
            break;
        case MS_TITLE:
            if (ui_tap(30, 120, 120, 44) || (g_in.down & K_A)) { ms = MS_HUD; audio_bgm_stop(); g_scene_request = SC_TITLE; }
            else if (ui_tap(170, 120, 120, 44) || (g_in.down & K_B)) { audio_sys(SND_CANCEL); ms = MS_HUD; }
            break;
        default: ms = MS_HUD; break;
    }
}

void ui_save_begin(void) { s_from_event = 1; enter(MS_SAVE); }

/* ----------------------------------------------------------------------------- drawing */
static void draw_hud(void)
{
    plat_rect(0, 0, BSCR_W, BSCR_H, RGBA(18, 18, 34, 255));
    char t[96];
    const char *mn = M.displayName >= 0 ? tx(M.displayName) : "";
    plat_text(mn, 8, 3, 0.5f, RGBA(255, 255, 255, 255));
    snprintf(t, sizeof t, "%d %s", g.gold, tx(db.currency));
    plat_text(t, 312 - plat_text_w(t, 0.5f), 3, 0.5f, RGBA(255, 235, 150, 255));
    for (int i = 0; i < g.nparty && i < 4; i++) { Battler *b = party_member(i); if (b) ui_status_row(4, 22 + i * 36, 312, b, true); }
    bool en = can_open();
    const char *lab[8] = { ui_s(S_MENU_ITEMS), ui_s(S_MENU_SKILLS), ui_s(S_MENU_EQUIP), ui_s(S_MENU_STATUS),
                           ui_s(S_MENU_SAVE), ui_s(S_MENU_LOAD), ui_s(S_MENU_LANG), ui_s(S_MENU_TITLE) };
    const int bx0 = 6, bw = 74, gap = 5;
    for (int i = 0; i < 8; i++) ui_button(bx0 + (i % 4) * (bw + gap), 168 + (i / 4) * 36, bw, 32, lab[i], en || i == 6, NULL);
    if (s_toast_t > 0) ui_text_centered(s_toast, 160, 150, 0.5f, RGBA(255, 240, 160, 255));
}

static void draw_confirm(const char *q)
{
    ui_draw_window(20, 70, 280, 110);
    ui_text_centered(q, 160, 82, 0.5f, RGBA(255, 255, 255, 255));
    ui_button(30, 120, 120, 44, ui_s(S_YES), true, NULL);
    ui_button(170, 120, 120, 44, ui_s(S_NO), true, NULL);
}

void ui_draw_map_bottom(void)
{
    if (shop_on) { shop_draw(); return; }
    if (ms == MS_HUD) { draw_hud(); return; }
    plat_rect(0, 0, BSCR_W, BSCR_H, RGBA(18, 18, 34, 255));
    const char *title = "";
    switch (ms) {
        case MS_ITEMS: title = ui_s(S_MENU_ITEMS); break;
        case MS_ITEM_TGT: case MS_SK_TGT: title = ui_s(S_WHO); break;
        case MS_SK_ACTOR: case MS_EQ_ACTOR: case MS_STATUS: title = ui_s(S_WHO); break;
        case MS_SK_LIST: title = ui_s(S_MENU_SKILLS); break;
        case MS_EQ_SLOT: case MS_EQ_ITEM: title = ui_s(S_MENU_EQUIP); break;
        case MS_SAVE: title = ui_s(S_SAVE_HERE); break;
        case MS_LOAD: title = ui_s(S_LOAD_HERE); break;
        default: break;
    }
    switch (ms) {
        case MS_ITEMS: case MS_SK_LIST: case MS_EQ_SLOT: case MS_EQ_ITEM:
            plat_text(title, 8, 6, 0.55f, RGBA(255, 235, 150, 255));
            ui_button(250, 4, 66, 22, ui_s(S_BACK), true, NULL);
            if (L.n == 0) plat_text(ui_s(S_NOTHING), 20, 60, 0.5f, RGBA(200, 200, 200, 255));
            ui_list_draw(&L);
            break;
        case MS_ITEM_TGT: case MS_SK_TGT: case MS_SK_ACTOR: case MS_EQ_ACTOR: case MS_STATUS:
            draw_pick_party(title);
            break;
        case MS_SAVE: case MS_LOAD:
            ui_text_centered(title, 160, 12, 0.55f, RGBA(255, 235, 150, 255));
            ui_list_draw(&L);
            ui_button(220, 200, 90, 30, ui_s(S_BACK), true, NULL);
            if (s_confirm_slot >= 0) draw_confirm(ui_s(S_CONFIRM));
            break;
        case MS_TITLE: draw_confirm(ui_s(S_SURE_TITLE)); break;
        default: break;
    }
    if (s_toast_t > 0) ui_text_centered(s_toast, 160, 224, 0.5f, RGBA(255, 240, 160, 255));
}

/* ----------------------------------------------------------------------------- top-screen info panels */
static void draw_actor_panel(const Battler *b)
{
    ui_draw_window(6, 6, 388, 228);
    const ActorDef *a = &db.actors[b->id];
    PTex *ft = face_tex(a->faceId);
    if (ft) plat_blit(ft, (a->faceIdx % 4) * 72, (a->faceIdx / 4) * 72, 72, 72, 14, 14, 1.0f, false, 255);
    char t[128];
    plat_text(b_name(b), 94, 12, 0.6f, RGBA(255, 255, 255, 255));
    snprintf(t, sizeof t, "%s  %s %d", tx(db.classes[a->classId].name), ui_s(S_LV), b->level);
    plat_text(t, 94, 32, 0.5f, RGBA(220, 225, 255, 255));
    int next = b->level < a->maxLevel ? actor_exp_for_level(a->classId, b->level + 1) - b->exp : 0;
    snprintf(t, sizeof t, "%s %d   %s %d", ui_s(S_EXP), b->exp, ui_s(S_NEXT), next);
    plat_text(t, 94, 50, 0.45f, RGBA(200, 205, 235, 255));
    snprintf(t, sizeof t, "HP %d/%d    MP %d/%d", b->hp, b_param(b, 0), b->mp, b_param(b, 1));
    plat_text(t, 94, 66, 0.5f, RGBA(255, 255, 255, 255));
    const int ps[6] = { S_P_ATK, S_P_DEF, S_P_MAT, S_P_MDF, S_P_AGI, S_P_LUK };
    for (int i = 0; i < 6; i++) {
        snprintf(t, sizeof t, "%s", ui_s(ps[i]));
        plat_text(t, 16 + (i % 2) * 100, 100 + (i / 2) * 18, 0.45f, RGBA(190, 200, 255, 255));
        snprintf(t, sizeof t, "%d", b_param(b, i + 2));
        plat_text(t, 90 + (i % 2) * 100 - plat_text_w(t, 0.45f) + 10, 100 + (i / 2) * 18, 0.45f, RGBA(255, 255, 255, 255));
    }
    for (int s = 0; s < 5; s++) {
        plat_text(slot_label(s), 214, 100 + s * 18, 0.45f, RGBA(190, 200, 255, 255));
        plat_text(equip_name(s, b->equips[s]), 290, 100 + s * 18, 0.45f, RGBA(255, 255, 255, 255));
    }
}

void ui_draw_menu_top(void)
{
    if (ms == MS_HUD) return;
    Battler *a = party_member(selActor);
    if ((ms == MS_STATUS || ms == MS_EQ_SLOT || ms == MS_EQ_ITEM || ms == MS_SK_LIST) && a) { draw_actor_panel(a); return; }
    if (ms == MS_ITEMS && L.n > 0 && L.cursor < L.n) {
        ui_draw_window(6, 170, 388, 64);
        const char *d = tx(db.items[s_ids[L.cursor]].desc);
        char buf[300]; snprintf(buf, sizeof buf, "%s", d);
        plat_text(tx(db.items[s_ids[L.cursor]].name), 14, 174, 0.55f, RGBA(255, 235, 150, 255));
        plat_text(buf, 14, 196, 0.45f, RGBA(255, 255, 255, 255));
    }
}
