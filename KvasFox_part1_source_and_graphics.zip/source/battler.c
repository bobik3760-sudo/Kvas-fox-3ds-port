/* battler.c - actors/enemies, traits, states, damage formulas, party and inventory.
 * Ported from rmmz_objects.js (Game_BattlerBase, Game_Battler, Game_Actor, Game_Action). */
#include "game.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

GameState g;

/* ----------------------------------------------------------------------------- util */
static uint32_t s_rng = 12345;
void rng_seed(uint32_t s) { s_rng = s ? s : 1; }
static uint32_t rng_next(void) { s_rng ^= s_rng << 13; s_rng ^= s_rng >> 17; s_rng ^= s_rng << 5; return s_rng; }
int rnd(int n) { return n <= 0 ? 0 : (int)(rng_next() % (uint32_t)n); }
float rndf(void) { return (rng_next() & 0xFFFFFF) / 16777216.0f; }
int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
void utf8_trim_to(char *s, int nbytes)
{
    int len = (int)strlen(s);
    if (nbytes >= len) return;
    while (nbytes > 0 && ((unsigned char)s[nbytes] & 0xC0) == 0x80) nbytes--;
    s[nbytes] = 0;
}

/* ----------------------------------------------------------------------------- traits */
#define MAXT 160
static int gather(const Battler *b, const Trait **out)
{
    int n = 0;
#define ADD(tr) do { for (int i_ = 0; i_ < (tr).n && n < MAXT; i_++) out[n++] = &(tr).v[i_]; } while (0)
    if (b->isActor) {
        if (b->id > 0 && b->id < db.nactors && db.actors[b->id].exists) {
            const ActorDef *a = &db.actors[b->id];
            ADD(a->tr);
            if (a->classId > 0 && a->classId < db.nclasses) ADD(db.classes[a->classId].tr);
        }
        for (int s = 0; s < 5; s++) {
            int id = b->equips[s];
            if (!id) continue;
            if (s == 0) { if (id < db.nweapons) ADD(db.weapons[id].tr); }
            else if (id < db.narmors) ADD(db.armors[id].tr);
        }
    } else if (b->id > 0 && b->id < db.nenemies) {
        ADD(db.enemies[b->id].tr);
    }
    for (int s = 1; s < db.nstates && s < MAX_STATES; s++)
        if (b->state[s] && db.states[s].exists) ADD(db.states[s].tr);
#undef ADD
    return n;
}

int b_trait_sum(const Battler *b, int code, int id)
{
    const Trait *t[MAXT]; int n = gather(b, t), sum = 0;
    for (int i = 0; i < n; i++) if (t[i]->code == code && t[i]->id == id) sum += t[i]->val;
    return sum;
}
float b_trait_pi(const Battler *b, int code, int id)
{
    const Trait *t[MAXT]; int n = gather(b, t); float r = 1.0f;
    for (int i = 0; i < n; i++) if (t[i]->code == code && t[i]->id == id) r *= t[i]->val / 10000.0f;
    return r;
}
bool b_trait_has(const Battler *b, int code, int id)
{
    const Trait *t[MAXT]; int n = gather(b, t);
    for (int i = 0; i < n; i++) if (t[i]->code == code && t[i]->id == id) return true;
    return false;
}

/* ----------------------------------------------------------------------------- params */
static int equip_param(const Battler *b, int p)
{
    int v = 0;
    for (int s = 0; s < 5; s++) {
        int id = b->equips[s];
        if (!id) continue;
        if (s == 0) { if (id < db.nweapons) v += db.weapons[id].params[p]; }
        else if (id < db.narmors) v += db.armors[id].params[p];
    }
    return v;
}

int b_param(const Battler *b, int p)
{
    double base;
    if (b->isActor) {
        int cid = db.actors[b->id].classId;
        base = db.classes[cid].params[p][clampi(b->level, 1, 99)] + equip_param(b, p);
    } else {
        base = db.enemies[b->id].params[p];
    }
    base += b->plus[p];
    if (base < 0) base = 0;
    double v = base * b_trait_pi(b, 21, p) * (b->buff[p] * 0.25 + 1.0);
    double lo = (p == 1) ? 0 : 1, hi = (p == 0) ? 999999 : 9999;
    if (v < lo) v = lo;
    if (v > hi) v = hi;
    return (int)floor(v + 0.5);
}
float b_xparam(const Battler *b, int id) { return b_trait_sum(b, 22, id) / 10000.0f; }
float b_sparam(const Battler *b, int id) { return b_trait_pi(b, 23, id); }

bool b_has_state(const Battler *b, int id) { return id > 0 && id < MAX_STATES && b->state[id]; }
bool b_dead(const Battler *b) { return b->state[1] != 0; }
bool b_alive(const Battler *b) { return b->valid && !b->state[1]; }
bool b_can_move(const Battler *b)
{
    if (!b_alive(b)) return false;
    for (int s = 1; s < db.nstates && s < MAX_STATES; s++)
        if (b->state[s] && db.states[s].restriction >= 4) return false;
    return true;
}

const char *b_name(const Battler *b)
{
    if (b->isActor) return tx(db.actors[b->id].name);
    return tx(db.enemies[b->id].name);
}

/* ----------------------------------------------------------------------------- states */
static void reset_state_counts(Battler *b, int id)
{
    const StateDef *s = &db.states[id];
    int var = 1 + (s->maxTurns - s->minTurns > 0 ? s->maxTurns - s->minTurns : 0);
    b->stateTurns[id] = s->minTurns + rnd(var);
}

static void die(Battler *b)
{
    b->hp = 0;
    memset(b->state, 0, sizeof b->state);
    memset(b->stateTurns, 0, sizeof b->stateTurns);
    memset(b->buff, 0, sizeof b->buff);
    memset(b->buffTurns, 0, sizeof b->buffTurns);
    b->state[1] = 1;
}

void b_add_state(Battler *b, int id)
{
    if (id <= 0 || id >= db.nstates || id >= MAX_STATES || !db.states[id].exists) return;
    if (!b_alive(b)) return;
    if (b_trait_has(b, 14, id)) return;
    if (!b->state[id]) {
        if (id == 1) { die(b); return; }
        b->state[id] = 1;
    }
    reset_state_counts(b, id);
}
void b_remove_state(Battler *b, int id)
{
    if (id <= 0 || id >= MAX_STATES || !b->state[id]) return;
    b->state[id] = 0; b->stateTurns[id] = 0;
    if (id == 1 && b->hp == 0) b->hp = 1;           /* revive */
}

void b_set_hp(Battler *b, int hp)
{
    int mhp = b_param(b, 0);
    b->hp = clampi(hp, 0, mhp);
    if (b->hp == 0 && b_alive(b)) die(b);
    else if (b->hp > 0 && b->state[1]) b_remove_state(b, 1);
}
void b_gain_hp(Battler *b, int v) { b_set_hp(b, b->hp + v); }
void b_gain_mp(Battler *b, int v) { b->mp = clampi(b->mp + v, 0, b_param(b, 1)); }
void b_recover_all(Battler *b)
{
    memset(b->state, 0, sizeof b->state);
    memset(b->stateTurns, 0, sizeof b->stateTurns);
    b->hp = b_param(b, 0); b->mp = b_param(b, 1);
}

/* ----------------------------------------------------------------------------- actors */
int actor_exp_for_level(int classId, int level)
{
    const ClassDef *c = &db.classes[classId];
    double basis = c->expParams[0], extra = c->expParams[1], a = c->expParams[2], bb = c->expParams[3];
    if (level <= 1) return 0;
    double v = basis * pow(level - 1, 0.9 + a / 250.0) * level * (level + 1) / (6 + pow(level, 2) / 50.0 / bb) + (level - 1) * extra;
    return (int)floor(v + 0.5);
}
int actor_max_level(const Battler *b) { return db.actors[b->id].maxLevel; }

static void learn_for_level(Battler *b, int level, bool upTo)
{
    const ClassDef *c = &db.classes[db.actors[b->id].classId];
    for (int i = 0; i < c->nlearn; i++)
        if (upTo ? c->learn[i].level <= level : c->learn[i].level == level)
            if (c->learn[i].skill > 0 && c->learn[i].skill < MAX_DB) b->learned[c->learn[i].skill] = 1;
}

void actor_level_up(Battler *b)
{
    b->level++;
    learn_for_level(b, b->level, false);
}

void actor_gain_exp(Battler *b, int exp, int *levelsGained)
{
    int cid = db.actors[b->id].classId;
    int gain = (int)floor(exp * b_sparam(b, 9) + 0.5);
    b->exp += gain;
    int n = 0;
    while (b->level < actor_max_level(b) && b->exp >= actor_exp_for_level(cid, b->level + 1)) { actor_level_up(b); n++; }
    if (levelsGained) *levelsGained = n;
    b_set_hp(b, b->hp); b_gain_mp(b, 0);
}

bool actor_skill_known(const Battler *b, int skillId)
{
    if (skillId <= 0 || skillId >= MAX_DB) return false;
    return b->learned[skillId] || b_trait_has(b, 43, skillId);
}

bool actor_has_skill_type(const Battler *b, int stype)
{
    if (stype == 0) return true;
    return b_trait_has(b, 41, stype) || b_trait_has(b, 41, stype);
}

int actor_equip_type(int slot) { return slot + 1; }

void battler_init_actor(Battler *b, int actorId)
{
    memset(b, 0, sizeof *b);
    const ActorDef *a = &db.actors[actorId];
    b->isActor = 1; b->id = actorId; b->valid = 1;
    b->level = a->initLevel;
    b->exp = actor_exp_for_level(a->classId, b->level);
    for (int i = 0; i < 5; i++) b->equips[i] = a->equips[i];
    learn_for_level(b, b->level, true);
    b->hp = b_param(b, 0); b->mp = b_param(b, 1);
}
void battler_init_enemy(Battler *b, int enemyId)
{
    memset(b, 0, sizeof *b);
    b->isActor = 0; b->id = enemyId; b->valid = 1;
    b->hp = b_param(b, 0); b->mp = b_param(b, 1);
}

void actor_change_equip(Battler *b, int slot, int item)
{
    int old = b->equips[slot];
    if (old) item_gain(slot == 0 ? 1 : 2, old, 1);
    if (item) item_gain(slot == 0 ? 1 : 2, item, -1);
    b->equips[slot] = item;
    b_set_hp(b, b->hp);
    b_gain_mp(b, 0);
}

/* ----------------------------------------------------------------------------- party / items */
Battler *actor_get(int actorId)
{
    if (actorId <= 0 || actorId >= ACTOR_MAX || actorId >= db.nactors || !db.actors[actorId].exists) return NULL;
    if (!g.actors[actorId].valid) battler_init_actor(&g.actors[actorId], actorId);
    return &g.actors[actorId];
}
Battler *party_member(int i) { return (i >= 0 && i < g.nparty) ? actor_get(g.party[i]) : NULL; }
int party_count(void) { return g.nparty; }
bool party_has(int id) { for (int i = 0; i < g.nparty; i++) if (g.party[i] == id) return true; return false; }
void party_add(int id)
{
    if (!actor_get(id) || party_has(id) || g.nparty >= MAX_PARTY) return;
    g.party[g.nparty++] = id;
    g_needs_refresh = 1;
    game_refresh_followers();
}
void party_remove(int id)
{
    for (int i = 0; i < g.nparty; i++) if (g.party[i] == id) {
        for (int k = i; k < g.nparty - 1; k++) g.party[k] = g.party[k + 1];
        g.nparty--; g_needs_refresh = 1; game_refresh_followers(); return;
    }
}

int item_count(int kind, int id)
{
    if (id <= 0 || id >= MAX_DB) return 0;
    return kind == 0 ? g.items[id] : (kind == 1 ? g.weapons[id] : g.armors[id]);
}
void item_gain(int kind, int id, int n)
{
    if (id <= 0 || id >= MAX_DB) return;
    int *p = kind == 0 ? &g.items[id] : (kind == 1 ? &g.weapons[id] : &g.armors[id]);
    *p = clampi(*p + n, 0, 99);
    g_needs_refresh = 1;
}

void game_new(void)
{
    memset(&g, 0, sizeof g);
    for (int i = 0; i < db.nparty && i < MAX_PARTY; i++) {
        Battler *b = actor_get(db.party[i]);
        if (b) g.party[g.nparty++] = db.party[i];
    }
    g.mapId = db.startMap; g.px = db.startX; g.py = db.startY; g.pdir = 2;
}

/* ----------------------------------------------------------------------------- formulas */
double eval_formula_d(const Damage *d, const Battler *a, const Battler *b)
{
    double st[32]; int sp = 0;
    for (int i = 0; i < d->n; i++) {
        int op = d->rpn[i * 2], arg = d->rpn[i * 2 + 1];
        if (op == 0) { if (sp < 32) st[sp++] = arg / 1000.0; }
        else if (op == 1 || op == 2) {
            const Battler *x = op == 1 ? a : b; double v = 0;
            if (arg <= 7) v = b_param(x, arg);
            else if (arg == 8) v = x->hp; else if (arg == 9) v = x->mp; else if (arg == 10) v = x->level;
            if (sp < 32) st[sp++] = v;
        } else if (op == 7) { if (sp > 0) st[sp - 1] = -st[sp - 1]; }
        else if (sp >= 2) {
            double r = st[--sp], l = st[sp - 1];
            st[sp - 1] = op == 3 ? l + r : op == 4 ? l - r : op == 5 ? l * r : (r != 0 ? l / r : 0);
        }
    }
    return sp > 0 ? st[0] : 0;
}

/* ----------------------------------------------------------------------------- actions */
typedef struct {
    int scope, hitType, successRate, repeats, speed, mpCost, isItem, isAttack, nfx;
    const Damage *dmg; const Effect *fx;
} Info;

static bool info_of(const BAction *a, Info *in)
{
    memset(in, 0, sizeof *in);
    if (a->kind == 4) {
        if (a->id <= 0 || a->id >= db.nitems) return false;
        const ItemDef *it = &db.items[a->id];
        in->scope = it->scope; in->hitType = it->hitType; in->successRate = it->successRate; in->repeats = it->repeats;
        in->speed = it->speed; in->isItem = 1; in->dmg = &it->dmg; in->fx = it->fx; in->nfx = it->nfx;
        return true;
    }
    int sid = a->kind == 1 ? 1 : (a->kind == 2 ? 2 : a->id);
    if (sid <= 0 || sid >= db.nskills) return false;
    const SkillDef *s = &db.skills[sid];
    in->scope = s->scope; in->hitType = s->hitType; in->successRate = s->successRate; in->repeats = s->repeats;
    in->speed = s->speed; in->mpCost = s->mpCost; in->isAttack = (sid == 1); in->dmg = &s->dmg; in->fx = s->fx; in->nfx = s->nfx;
    return true;
}

bool action_is_item(const BAction *a) { return a->kind == 4; }
const Damage *action_damage(const BAction *a) { Info i; return info_of(a, &i) ? i.dmg : NULL; }
int action_scope(const BAction *a) { Info i; return info_of(a, &i) ? i.scope : 0; }
int action_hit_type(const BAction *a) { Info i; return info_of(a, &i) ? i.hitType : 0; }

bool skill_can_pay(const Battler *b, int skillId)
{
    if (skillId <= 0 || skillId >= db.nskills) return false;
    int cost = (int)floor(db.skills[skillId].mpCost * b_sparam(b, 4));
    return b->mp >= cost;
}
void skill_pay(Battler *b, int skillId)
{
    int cost = (int)floor(db.skills[skillId].mpCost * b_sparam(b, 4));
    b->mp = clampi(b->mp - cost, 0, b_param(b, 1));
}

/* would the effects change anything on this target? (used for menu item/skill use) */
bool action_usable_on(const BAction *a, const Battler *t)
{
    Info in; if (!info_of(a, &in)) return false;
    bool forDead = in.scope == 9 || in.scope == 10;
    if (forDead != (b_dead(t) != 0)) return false;
    if (in.dmg->type == 3 && t->hp < b_param(t, 0)) return true;
    if (in.dmg->type == 4 && t->mp < b_param(t, 1)) return true;
    for (int i = 0; i < in.nfx; i++) {
        const Effect *e = &in.fx[i];
        switch (e->code) {
            case 11: if (t->hp < b_param(t, 0)) return true; break;
            case 12: if (t->mp < b_param(t, 1)) return true; break;
            case 21: if (e->id > 0 && !b_has_state(t, e->id)) return true; break;
            case 22: if (b_has_state(t, e->id)) return true; break;
            case 31: case 32: case 42: case 43: return true;
            default: break;
        }
    }
    return false;
}

bool item_can_use(int itemId, const Battler *t)
{
    BAction a = { 4, itemId, 0 };
    return action_usable_on(&a, t);
}

static void apply_effect(Battler *subj, const Info *in, Battler *t, const Effect *e, ActResult *r)
{
    switch (e->code) {
        case 11: {   /* recover HP */
            double v = (b_param(t, 0) * (e->v1 / 10000.0) + e->v2 / 10000.0) * b_sparam(t, 2);
            if (in->isItem) v *= b_sparam(subj, 3);
            int iv = (int)floor(v);
            if (iv != 0) { r->hpDmg -= iv; b_gain_hp(t, iv); r->hit = 1; }
            break;
        }
        case 12: {
            double v = (b_param(t, 1) * (e->v1 / 10000.0) + e->v2 / 10000.0) * b_sparam(t, 2);
            if (in->isItem) v *= b_sparam(subj, 3);
            int iv = (int)floor(v);
            if (iv != 0) { r->mpDmg -= iv; b_gain_mp(t, iv); }
            break;
        }
        case 21: {   /* add state */
            if (e->id <= 0) break;
            double chance = e->v1 / 10000.0;
            if (in->hitType != 0) chance *= b_trait_pi(t, 13, e->id);
            double luk = 1.0 + (b_param(subj, 7) - b_param(t, 7)) * 0.001; if (luk < 0) luk = 0;
            chance *= luk;
            if (rndf() < chance && b_alive(t) && !b_has_state(t, e->id)) {
                b_add_state(t, e->id);
                if (b_has_state(t, e->id) && r->nadded < 4) r->added[r->nadded++] = e->id;
            }
            break;
        }
        case 22:
            if (rndf() < e->v1 / 10000.0 && b_has_state(t, e->id)) {
                b_remove_state(t, e->id);
                if (r->nremoved < 4) r->removed[r->nremoved++] = e->id;
            }
            break;
        case 31: case 32: {
            int p = e->id; if (p < 0 || p > 7 || !b_alive(t)) break;
            int turns = (int)(e->v1 / 10000.0);
            if (e->code == 31 && t->buff[p] < 2) t->buff[p]++;
            if (e->code == 32 && t->buff[p] > -2) t->buff[p]--;
            if (t->buff[p] != 0 && t->buffTurns[p] < turns) t->buffTurns[p] = turns;
            break;
        }
        case 42:
            if (e->id >= 0 && e->id < 8) t->plus[e->id] += (int)(e->v1 / 10000.0);
            break;
        case 43:
            if (t->isActor && e->id > 0 && e->id < MAX_DB) t->learned[e->id] = 1;
            break;
        default: break;
    }
}

void action_apply(Battler *subj, const BAction *a, Battler *t, ActResult *res, bool inBattle)
{
    ActResult r; memset(&r, 0, sizeof r);
    Info in;
    if (!info_of(a, &in)) { *res = r; return; }
    bool forDead = in.scope == 9 || in.scope == 10;
    r.used = (forDead == (b_dead(t) != 0));
    if (r.used && !inBattle && !action_usable_on(a, t)) r.used = 0;
    if (r.used) {
        double hitRate = in.successRate * 0.01 * (in.hitType == 1 ? b_xparam(subj, 0) : 1.0);
        r.missed = rndf() >= hitRate;
        double eva = in.hitType == 1 ? b_xparam(t, 1) : (in.hitType == 2 ? b_xparam(t, 4) : 0.0);
        r.evaded = !r.missed && rndf() < eva;
    }
    if (r.used && !r.missed && !r.evaded) {
        r.hit = 1;
        if (in.dmg->type > 0) {
            double cri = in.dmg->critical ? b_xparam(subj, 2) * (1 - b_xparam(t, 3)) : 0.0;
            r.critical = rndf() < cri;
            double base = eval_formula_d(in.dmg, subj, t);
            if (base < 0) base = 0;
            if (in.dmg->type == 3 || in.dmg->type == 4) base = -base;
            double v = base;
            if (in.hitType == 1) v *= b_sparam(t, 6);
            if (in.hitType == 2) v *= b_sparam(t, 7);
            if (base < 0) v *= b_sparam(t, 2);
            if (r.critical) v *= 3;
            double amp = floor((fabs(v) * in.dmg->variance) / 100.0); if (amp < 0) amp = 0;
            int ia = (int)amp, vv = rnd(ia + 1) + rnd(ia + 1) - ia;
            v = v >= 0 ? v + vv : v - vv;
            if (v > 0 && b_trait_has(t, 62, 1) && b_can_move(t)) v = v / (2 * b_sparam(t, 1));
            int val = (int)floor(v + 0.5);
            if (val == 0) r.critical = 0;
            int ty = in.dmg->type;
            if (ty == 1 || ty == 3 || ty == 5) {
                r.hpDmg += val; b_gain_hp(t, -val);
                if (ty == 5) b_gain_hp(subj, val);
            } else {
                r.mpDmg += val; b_gain_mp(t, -val);
                if (ty == 6) b_gain_mp(subj, val);
            }
            if (val > 0 && ty != 3 && ty != 4) {   /* onDamage: states that break on damage */
                for (int s = 1; s < db.nstates && s < MAX_STATES; s++)
                    if (t->state[s] && db.states[s].removeByDamage && rnd(100) < db.states[s].chanceByDamage) b_remove_state(t, s);
            }
        }
        for (int i = 0; i < in.nfx; i++) apply_effect(subj, &in, t, &in.fx[i], &r);
    }
    *res = r;
}
