/* battle.c - turn based battle (front view), ported from BattleManager / Game_Action / Game_Enemy logic. */
#include "game.h"
#include <stdio.h>
#include <stdarg.h>
#include <math.h>
#include <stdlib.h>

#define VSCALE (240.0f / 624.0f)
#define VLETTER 43.0f

enum { BP_NONE, BP_START, BP_INPUT, BP_ACTION, BP_TURNEND, BP_RESULT, BP_WAITKEY, BP_END };
enum { CS_PARTY, CS_ACTOR, CS_SKILL, CS_ITEM, CS_TARGET };

typedef struct {
    int active, phase, troopId;
    Battler en[8]; int nen;
    PTex *enTex[8];
    PTex *bg;
    int turn, canEscape, canLose, result, wait, turnEnding;
    float escapeRatio;
    int inputIdx, cs;
    UiList list;
    int tgtMap[16];
    BAction pending; int pendingScope;
    Battler *order[16]; int norder, oi;
    char log[5][140]; int nlog;
    int ran[16];
    int resultStage;
    int expTotal, goldTotal;
    int pageSeen;
} Battle;

static Battle B;

bool battle_active(void) { return B.active; }
bool battle_finished(void) { return B.active && B.phase == BP_END; }
int battle_result(void) { return B.result; }

/* ----------------------------------------------------------------------------- helpers */
static void blog(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void blog(const char *fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    if (B.nlog >= 5) { for (int i = 1; i < 5; i++) memcpy(B.log[i - 1], B.log[i], sizeof B.log[0]); B.nlog = 4; }
    vsnprintf(B.log[B.nlog++], sizeof B.log[0], fmt, ap);
    va_end(ap);
}

static bool b_in_play(const Battler *b) { return b_alive(b) && !b->hidden; }

static const char *disp_name(const Battler *b, char *buf, int cap)
{
    if (b->isActor) { snprintf(buf, cap, "%s", b_name(b)); return buf; }
    int same = 0, idx = 0;
    for (int i = 0; i < B.nen; i++) if (B.en[i].id == b->id) { if (&B.en[i] == b) idx = same; same++; }
    if (same > 1) snprintf(buf, cap, "%s %c", b_name(b), 'A' + idx); else snprintf(buf, cap, "%s", b_name(b));
    return buf;
}
#define DN(b) disp_name((b), (char[64]){0}, 64)

static int alive_enemies(void) { int n = 0; for (int i = 0; i < B.nen; i++) if (b_in_play(&B.en[i])) n++; return n; }
static int alive_party(void) { int n = 0; for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b && b_alive(b)) n++; } return n; }

static const char *skill_label(int sid) { return tx(db.skills[sid].name); }

/* ----------------------------------------------------------------------------- troop events */
static bool page_met(const TroopPage *p, int idx)
{
    if (!p->turnEnding && !p->turnValid && !p->enemyValid && !p->actorValid && !p->switchValid) return false;
    if (p->turnEnding && !B.turnEnding) return false;
    if (p->turnValid) {
        int n = B.turn, a = p->turnA, b = p->turnB;
        if (b == 0 && n != a) return false;
        if (b > 0 && (n < 1 || n < a || n % b != a % b)) return false;
    }
    if (p->enemyValid) {
        if (p->enemyIndex < 0 || p->enemyIndex >= B.nen) return false;
        const Battler *e = &B.en[p->enemyIndex];
        if (!b_in_play(e) || e->hp * 100 / b_param(e, 0) > p->enemyHp) return false;
    }
    if (p->actorValid) {
        Battler *a = actor_get(p->actorId);
        if (!a || !party_has(p->actorId) || !b_alive(a) || a->hp * 100 / b_param(a, 0) > p->actorHp) return false;
    }
    if (p->switchValid && !sw_get(p->switchId)) return false;
    (void)idx;
    return true;
}

static bool run_events(void)
{
    const TroopDef *t = &db.troops[B.troopId];
    for (int i = 0; i < t->npages && i < 16; i++) {
        const TroopPage *p = &t->pages[i];
        if (p->span == 0 && B.ran[i]) continue;
        if (p->span == 1 && B.ran[i] == B.turn + 1) continue;
        if (!page_met(p, i)) continue;
        B.ran[i] = p->span == 0 ? 1 : B.turn + 1;
        if (p->ncmd > 3) {
            interp_setup(&g_binterp, p->cmd, p->ncmd, 0);
            g_binterp.isBattle = 1;
            return true;
        }
    }
    return false;
}

void battle_cmd_enemy_state(int index, int op, int stateId)
{
    for (int i = 0; i < B.nen; i++) {
        if (index >= 0 && i != index) continue;
        Battler *e = &B.en[i];
        if (op == 0) { if (b_alive(e)) { b_add_state(e, stateId); if (b_dead(e)) e->collapse = 1; } }
        else b_remove_state(e, stateId);
    }
}
void battle_cmd_enemy_appear(int index)
{
    for (int i = 0; i < B.nen; i++) if ((index < 0 || i == index)) B.en[i].hidden = 0;
}

/* ----------------------------------------------------------------------------- setup */
void battle_start(int troopId, bool canEscape, bool canLose)
{
    memset(&B, 0, sizeof B);
    if (troopId <= 0 || troopId >= db.ntroops || !db.troops[troopId].exists) { B.active = 1; B.phase = BP_END; B.result = 0; return; }
    B.active = 1; B.troopId = troopId; B.canEscape = canEscape; B.canLose = canLose; B.result = -1;
    const TroopDef *t = &db.troops[troopId];
    for (int i = 0; i < t->nmem && i < 8; i++) {
        Battler *e = &B.en[B.nen];
        battler_init_enemy(e, t->mem[i].enemy);
        e->x = t->mem[i].x; e->y = t->mem[i].y; e->hidden = t->mem[i].hidden;
        int img = db.enemies[t->mem[i].enemy].img;
        if (img >= 0) { char n[16]; snprintf(n, sizeof n, "e%02d", img); B.enTex[B.nen] = plat_tex_load(n); }
        B.nen++;
    }
    B.bg = M.overworld ? plat_tex_load("bb_field") : NULL;
    audio_bgm_save();
    audio_sys(SND_BATTLE_START);
    for (int i = 0; i < B.nen; i++) if (!B.en[i].hidden) blog(ui_s(S_B_APPEARED), DN(&B.en[i]));
    for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b) { b->act.kind = 0; b->popup = 0; } }
    B.phase = BP_START; B.wait = 40;
    B.escapeRatio = 0;
    for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b) { b->flash = 0; b->hidden = 0; } }
    {   /* escape ratio = 0.5 * party agility / troop agility */
        float pa = 0, ea = 0; int pn = 0, en = 0;
        for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b) { pa += b_param(b, 6); pn++; } }
        for (int i = 0; i < B.nen; i++) if (b_in_play(&B.en[i])) { ea += b_param(&B.en[i], 6); en++; }
        pa /= pn ? pn : 1; ea /= en ? en : 1;
        B.escapeRatio = ea > 0 ? 0.5f * pa / ea : 1.0f;
    }
}

void battle_end_cleanup(void)
{
    for (int i = 0; i < 8; i++) if (B.enTex[i]) plat_tex_free(B.enTex[i]);
    if (B.bg) plat_tex_free(B.bg);
    for (int i = 0; i < g.nparty; i++) {
        Battler *b = party_member(i); if (!b) continue;
        for (int s = 2; s < MAX_STATES; s++) {   /* removeBattleStates: states that end with battle */
            if (b->state[s] && db.states[s].autoRemoval > 0) b->state[s] = 0, b->stateTurns[s] = 0;
        }
        memset(b->buff, 0, sizeof b->buff); memset(b->buffTurns, 0, sizeof b->buffTurns);
        b->act.kind = 0; b->popup = 0;
    }
    B.active = 0;
}

/* ----------------------------------------------------------------------------- targeting */
static int collect_targets(Battler *subj, const BAction *a, Battler **out)
{
    int scope = action_scope(a), n = 0;
    bool isActor = subj->isActor;
    Battler *opp[16], *fri[16], *deadFri[16]; int no = 0, nf = 0, nd = 0;
    if (isActor) {
        for (int i = 0; i < B.nen; i++) if (b_in_play(&B.en[i])) opp[no++] = &B.en[i];
        for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b) { if (b_alive(b)) fri[nf++] = b; else deadFri[nd++] = b; } }
    } else {
        for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b && b_alive(b)) opp[no++] = b; }
        for (int i = 0; i < B.nen; i++) { if (b_in_play(&B.en[i])) fri[nf++] = &B.en[i]; else if (b_dead(&B.en[i]) && !B.en[i].hidden) deadFri[nd++] = &B.en[i]; }
    }
    switch (scope) {
        case 1: {
            if (no == 0) break;
            Battler *t = NULL;
            if (isActor && a->target >= 0 && a->target < B.nen && b_in_play(&B.en[a->target])) t = &B.en[a->target];
            if (!t) {   /* weighted random by target rate */
                float sum = 0; for (int i = 0; i < no; i++) sum += b_sparam(opp[i], 0);
                float r = rndf() * sum; t = opp[no - 1];
                for (int i = 0; i < no; i++) { r -= b_sparam(opp[i], 0); if (r <= 0) { t = opp[i]; break; } }
            }
            out[n++] = t; break;
        }
        case 2: for (int i = 0; i < no; i++) out[n++] = opp[i]; break;
        case 3: case 4: case 5: case 6: if (no) for (int i = 0; i < scope - 2; i++) out[n++] = opp[rnd(no)]; break;
        case 7: {
            if (!nf) break;
            Battler *t = NULL;
            if (isActor && a->target >= 0 && a->target < g.nparty) { Battler *c = party_member(a->target); if (c && b_alive(c)) t = c; }
            if (!t) t = fri[rnd(nf)];
            out[n++] = t; break;
        }
        case 8: for (int i = 0; i < nf; i++) out[n++] = fri[i]; break;
        case 9: {
            if (!nd) break;
            Battler *t = NULL;
            if (isActor && a->target >= 0 && a->target < g.nparty) { Battler *c = party_member(a->target); if (c && b_dead(c)) t = c; }
            if (!t) t = deadFri[rnd(nd)];
            out[n++] = t; break;
        }
        case 10: for (int i = 0; i < nd; i++) out[n++] = deadFri[i]; break;
        case 11: out[n++] = subj; break;
        default: break;
    }
    return n;
}

/* ----------------------------------------------------------------------------- action execution */
static void report(Battler *subj, Battler *t, const ActResult *r)
{
    char nm[64]; disp_name(t, nm, sizeof nm);
    if (!r->used) return;
    if (r->missed) { audio_sys(SND_MISS); blog(ui_s(S_B_MISS), DN(subj)); return; }
    if (r->evaded) { audio_sys(SND_EVASION); blog(ui_s(S_B_EVADE), nm); return; }
    if (r->critical) blog("%s", ui_s(S_B_CRIT));
    if (r->hpDmg > 0) {
        blog(ui_s(S_B_DAMAGE), nm, r->hpDmg);
        audio_sys(t->isActor ? SND_ACTOR_DAMAGE : SND_ENEMY_DAMAGE);
        t->popup = r->hpDmg; t->popupKind = 0; t->popupTimer = 40; t->flash = 18; t->popupCrit = r->critical;
    } else if (r->hpDmg < 0) {
        blog(ui_s(S_B_HEAL), nm, -r->hpDmg);
        audio_sys(SND_RECOVERY);
        t->popup = -r->hpDmg; t->popupKind = 1; t->popupTimer = 40;
    } else if (r->mpDmg == 0 && r->nadded == 0 && r->nremoved == 0 && r->hit) {
        /* nothing happened */
    }
    if (r->mpDmg > 0) blog(ui_s(S_B_MPDMG), nm, r->mpDmg);
    else if (r->mpDmg < 0) blog(ui_s(S_B_MPHEAL), nm, -r->mpDmg);
    for (int i = 0; i < r->nadded; i++) blog(ui_s(S_B_STATE_ADD), nm, tx(db.states[r->added[i]].name));
    for (int i = 0; i < r->nremoved; i++) blog(ui_s(S_B_STATE_OFF), nm, tx(db.states[r->removed[i]].name));
    if (r->hpDmg == 0 && r->mpDmg == 0 && r->nadded == 0 && r->nremoved == 0 && r->hit) blog(ui_s(S_B_NOEFFECT), nm);
    if (b_dead(t)) {
        blog(ui_s(S_B_DEFEATED), nm);
        t->collapse = 1;
        audio_sys(t->isActor ? SND_ACTOR_COLLAPSE : SND_ENEMY_COLLAPSE);
    }
}

static void exec_action(Battler *subj)
{
    BAction a = subj->act;
    char sn[64]; disp_name(subj, sn, sizeof sn);
    if (a.kind == 1) { blog(ui_s(S_B_ATTACKS), sn); if (!subj->isActor) audio_sys(SND_ENEMY_ATTACK); else audio_sys(SND_ENEMY_ATTACK); }
    else if (a.kind == 2) blog(ui_s(S_B_GUARDS), sn);
    else if (a.kind == 3) {
        if (a.id == 1) blog(ui_s(S_B_ATTACKS), sn);
        else blog(ui_s(S_B_USES), sn, skill_label(a.id));
        if (subj->isActor) skill_pay(subj, a.id);
        if (a.id != 1) audio_sys(SND_USE_SKILL);
    } else if (a.kind == 4) {
        blog(ui_s(S_B_USES), sn, tx(db.items[a.id].name));
        if (db.items[a.id].consumable) item_gain(0, a.id, -1);
        audio_sys(SND_USE_ITEM);
    }
    int reps = 1;
    {
      if (a.kind == 3 && a.id > 0 && a.id < db.nskills) reps = db.skills[a.id].repeats > 0 ? db.skills[a.id].repeats : 1;
      if (a.kind == 4 && a.id > 0 && a.id < db.nitems) reps = db.items[a.id].repeats > 0 ? db.items[a.id].repeats : 1; }
    for (int rp = 0; rp < reps; rp++) {
        Battler *tg[16]; int nt = collect_targets(subj, &a, tg);
        for (int i = 0; i < nt; i++) {
            ActResult r; action_apply(subj, &a, tg[i], &r, true);
            report(subj, tg[i], &r);
        }
    }
    /* guard action: skill 2 adds state 2 through its effects */
}

/* ----------------------------------------------------------------------------- enemy AI */
static bool enemy_cond(const Battler *e, const EnemyAction *ea)
{
    switch (ea->ctype) {
        case 0: return true;
        case 1: { int n = B.turn, a = ea->cp1, b = ea->cp2; if (b == 0) return n == a; return n > 0 && n >= a && n % b == a % b; }
        case 2: { float r = (float)e->hp / b_param(e, 0); return r >= ea->cp1 / 100.0f && r <= ea->cp2 / 100.0f; }
        case 3: { int mm = b_param(e, 1); float r = mm > 0 ? (float)e->mp / mm : 0; return r >= ea->cp1 / 100.0f && r <= ea->cp2 / 100.0f; }
        case 4: return b_has_state(e, ea->cp1);
        case 5: { int mx = 0; for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b && b->level > mx) mx = b->level; } return mx >= ea->cp1; }
        case 6: return sw_get(ea->cp1);
        default: return true;
    }
}

static void enemy_make_action(Battler *e)
{
    e->act.kind = 0;
    if (!b_can_move(e) || e->hidden) return;
    const EnemyDef *d = &db.enemies[e->id];
    int valid[16], nv = 0, ratingMax = -100;
    for (int i = 0; i < d->nact && nv < 16; i++) {
        const EnemyAction *ea = &d->act[i];
        if (!enemy_cond(e, ea)) continue;
        if (ea->skill <= 0 || ea->skill >= db.nskills) continue;
        if (!skill_can_pay(e, ea->skill)) continue;
        valid[nv++] = i;
        if (ea->rating > ratingMax) ratingMax = ea->rating;
    }
    if (!nv) return;
    int ratingZero = ratingMax - 3, sum = 0;
    for (int i = 0; i < nv; i++) if (d->act[valid[i]].rating > ratingZero) sum += d->act[valid[i]].rating - ratingZero;
    if (sum <= 0) return;
    int r = rnd(sum);
    for (int i = 0; i < nv; i++) {
        int w = d->act[valid[i]].rating - ratingZero; if (w <= 0) continue;
        r -= w;
        if (r < 0) { e->act.kind = 3; e->act.id = d->act[valid[i]].skill; e->act.target = -1; if (e->act.id == 1) e->act.kind = 1; return; }
    }
}

/* ----------------------------------------------------------------------------- turn flow */
static int action_speed(Battler *b)
{
    int agi = b_param(b, 6);
    int sp = agi + rnd((int)floorf(5 + agi / 4.0f));
    if (b->act.kind == 2) sp += db.skills[2].speed;
    else if (b->act.kind == 3) sp += db.skills[b->act.id].speed;
    else if (b->act.kind == 4) sp += db.items[b->act.id].speed;
    return sp;
}

static void begin_input(void)
{
    B.phase = BP_INPUT; B.cs = CS_PARTY; B.inputIdx = 0;
    for (int i = 0; i < B.nen; i++) enemy_make_action(&B.en[i]);
    for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b) b->act.kind = 0; }
}

static void start_turn_exec(bool partyActs)
{
    B.turn++;
    B.norder = 0;
    for (int i = 0; i < B.nen; i++) if (B.en[i].act.kind) { B.en[i].speed = action_speed(&B.en[i]); B.order[B.norder++] = &B.en[i]; }
    if (partyActs) for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b && b->act.kind) { b->speed = action_speed(b); B.order[B.norder++] = b; } }
    for (int i = 1; i < B.norder; i++) {      /* insertion sort, descending speed */
        Battler *k = B.order[i]; int j = i - 1;
        while (j >= 0 && B.order[j]->speed < k->speed) { B.order[j + 1] = B.order[j]; j--; }
        B.order[j + 1] = k;
    }
    B.oi = 0; B.phase = BP_ACTION; B.wait = 8;
}

static void remove_states_auto(Battler *b, int timing)
{
    for (int s = 2; s < db.nstates && s < MAX_STATES; s++)
        if (b->state[s] && b->stateTurns[s] == 0 && db.states[s].autoRemoval == timing) b_remove_state(b, s);
}

static void turn_end_for(Battler *b)
{
    if (!b_alive(b)) return;
    char nm[64]; disp_name(b, nm, sizeof nm);
    int v = (int)floorf(b_param(b, 0) * b_xparam(b, 7));
    int maxSlip = b->hp - 1; if (maxSlip < 0) maxSlip = 0;
    if (v < -maxSlip) v = -maxSlip;
    if (v != 0) {
        b_gain_hp(b, v);
        if (v < 0) { blog(ui_s(S_B_DAMAGE), nm, -v); b->popup = -v; b->popupKind = 0; b->popupTimer = 40; b->flash = 12; }
        else { blog(ui_s(S_B_HEAL), nm, v); b->popup = v; b->popupKind = 1; b->popupTimer = 40; }
    }
    int mv = (int)floorf(b_param(b, 1) * b_xparam(b, 8)); if (mv) b_gain_mp(b, mv);
    for (int s = 1; s < MAX_STATES; s++) if (b->state[s] && b->stateTurns[s] > 0) b->stateTurns[s]--;
    for (int p = 0; p < 8; p++) if (b->buffTurns[p] > 0) b->buffTurns[p]--;
    remove_states_auto(b, 2);
    for (int p = 0; p < 8; p++) if (b->buff[p] != 0 && b->buffTurns[p] == 0) b->buff[p] = 0;
}

/* returns true if the battle ended (sets phase) */
static bool check_end(void)
{
    if (alive_enemies() == 0) {
        for (int i = 0; i < B.nen; i++) if (b_dead(&B.en[i]) && !B.en[i].hidden) { B.expTotal += db.enemies[B.en[i].id].exp; B.goldTotal += db.enemies[B.en[i].id].gold; }
        B.result = 0; B.phase = BP_RESULT; B.resultStage = 0; B.wait = 30;
        return true;
    }
    if (alive_party() == 0) {
        B.result = 2; B.phase = BP_RESULT; B.resultStage = 0; B.wait = 30;
        return true;
    }
    return false;
}

static void give_rewards(void)
{
    blog("%s", ui_s(S_B_VICTORY));
    audio_me(db.victoryMe, 90);
    if (B.expTotal) blog(ui_s(S_B_EXP), B.expTotal);
    if (B.goldTotal) { g.gold = clampi(g.gold + B.goldTotal, 0, 99999999); blog(ui_s(S_B_GOLD), B.goldTotal, tx(db.currency)); }
    for (int i = 0; i < B.nen; i++) {
        if (!b_dead(&B.en[i]) || B.en[i].hidden) continue;
        const EnemyDef *d = &db.enemies[B.en[i].id];
        for (int k = 0; k < 3; k++) {
            if (d->drop[k].kind <= 0) continue;
            if (rnd(d->drop[k].den > 0 ? d->drop[k].den : 1) == 0) {
                int kind = d->drop[k].kind - 1;
                item_gain(kind, d->drop[k].id, 1);
                const char *nm = kind == 0 ? tx(db.items[d->drop[k].id].name) : (kind == 1 ? tx(db.weapons[d->drop[k].id].name) : tx(db.armors[d->drop[k].id].name));
                blog(ui_s(S_B_DROP), nm);
            }
        }
    }
    for (int i = 0; i < g.nparty; i++) {
        Battler *b = party_member(i); if (!b) continue;
        int before = b->level;
        uint8_t old[MAX_DB]; memcpy(old, b->learned, MAX_DB);
        if (B.expTotal) actor_gain_exp(b, B.expTotal, NULL);
        if (b->level > before) {
            blog(ui_s(S_B_LEVELUP), b_name(b), b->level);
            for (int s = 1; s < MAX_DB && s < db.nskills; s++) if (b->learned[s] && !old[s]) blog(ui_s(S_B_LEARN), b_name(b), tx(db.skills[s].name));
        }
    }
}

void battle_update(void)
{
    if (!B.active) return;
    /* battle event / message overlay */
    if (g_binterp.running || msg_busy()) {
        interp_update(&g_binterp);
        msg_update();
        interp_update_scroll();
        return;
    }
    for (int i = 0; i < B.nen; i++) {
        Battler *e = &B.en[i];
        if (e->collapse > 0 && e->collapse < 40) e->collapse++;
        if (e->flash > 0) e->flash--;
    }
    for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b && b->flash > 0) b->flash--; }
    for (int i = 0; i < B.nen; i++) if (B.en[i].popupTimer > 0) B.en[i].popupTimer--;
    for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b && b->popupTimer > 0) b->popupTimer--; }

    if (B.wait > 0) { B.wait--; return; }
    if (B.phase == BP_END || B.phase == BP_NONE) return;
    if (B.phase != BP_RESULT && B.phase != BP_WAITKEY && run_events()) return;
    if (g_binterp.running) return;

    switch (B.phase) {
        case BP_START: begin_input(); break;
        case BP_INPUT: break;          /* player commands are handled in battle_input() */
        case BP_ACTION: {
            if (check_end()) break;
            if (B.oi >= B.norder) {
                for (int i = 0; i < B.norder; i++) remove_states_auto(B.order[i], 1);
                B.phase = BP_TURNEND; B.wait = 10; break;
            }
            Battler *s = B.order[B.oi++];
            if (!b_in_play(s) || !b_can_move(s) || s->act.kind == 0) break;
            if (s->act.kind == 4 && item_count(0, s->act.id) <= 0 && s->isActor) { B.wait = 2; break; }
            exec_action(s);
            remove_states_auto(s, 1);
            s->act.kind = 0;
            B.wait = 55;
            break;
        }
        case BP_TURNEND: {
            B.turnEnding = 1;
            if (run_events()) { B.turnEnding = 0; B.phase = BP_TURNEND; return; }
            B.turnEnding = 0;
            for (int i = 0; i < B.nen; i++) turn_end_for(&B.en[i]);
            for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b) turn_end_for(b); }
            if (check_end()) break;
            begin_input();
            B.wait = 10;
            break;
        }
        case BP_RESULT: {
            if (B.resultStage == 0) {
                if (B.result == 0) give_rewards();
                else { blog("%s", ui_s(S_B_DEFEAT)); audio_me(db.defeatMe, 90); }
                B.resultStage = 1; B.phase = BP_WAITKEY; B.wait = 20;
            }
            break;
        }
        case BP_WAITKEY:
            if ((g_in.down & (K_A | K_B)) || g_in.touch_down) {
                if (B.result == 2 && B.canLose) {      /* revive party at 1 HP */
                    for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b) { b_remove_state(b, 1); if (b->hp < 1) b->hp = 1; } }
                }
                audio_bgm_resume();
                B.phase = BP_END;
            }
            break;
        default: break;
    }
}

/* ----------------------------------------------------------------------------- player input (bottom screen) */
static Battler *cur_actor(void) { return party_member(B.inputIdx); }

static void next_actor(void)
{
    for (;;) {
        B.inputIdx++;
        if (B.inputIdx >= g.nparty) { B.cs = CS_PARTY; start_turn_exec(true); return; }
        Battler *b = cur_actor();
        if (b && b_alive(b) && b_can_move(b)) { B.cs = CS_ACTOR; return; }
        if (b && b_alive(b) && !b_can_move(b)) { b->act.kind = 0; }
    }
}
static void prev_actor(void)
{
    for (int i = B.inputIdx - 1; i >= 0; i--) {
        Battler *b = party_member(i);
        if (b && b_alive(b) && b_can_move(b)) { B.inputIdx = i; B.cs = CS_ACTOR; return; }
    }
    B.cs = CS_PARTY; B.inputIdx = 0;
}

static void build_target_list(int scope)
{
    ui_list_init(&B.list, 10, 44, 300, 190, 26);
    ui_list_clear(&B.list);
    if (scope == 1) {
        for (int i = 0; i < B.nen; i++) if (b_in_play(&B.en[i])) {
            char nm[64]; disp_name(&B.en[i], nm, sizeof nm);
            char hp[20]; snprintf(hp, sizeof hp, "%d/%d", B.en[i].hp, b_param(&B.en[i], 0));
            B.tgtMap[B.list.n] = i; ui_list_add(&B.list, nm, hp, true);
        }
    } else {
        for (int i = 0; i < g.nparty; i++) {
            Battler *b = party_member(i); if (!b) continue;
            bool want = scope == 9 ? b_dead(b) : b_alive(b);
            char hp[20]; snprintf(hp, sizeof hp, "%d/%d", b->hp, b_param(b, 0));
            B.tgtMap[B.list.n] = i; ui_list_add(&B.list, b_name(b), hp, want);
        }
    }
}

static void choose_target_or_set(Battler *a, int kind, int id, int scope)
{
    a->act.kind = kind; a->act.id = id; a->act.target = -1;
    if (scope == 1 || scope == 7 || scope == 9) {
        B.pending = a->act; B.pendingScope = scope;
        build_target_list(scope);
        B.cs = CS_TARGET;
    } else next_actor();
}

/* skill/item id lists for the list widgets (kept in static arrays to avoid hacks) */
static int s_list_ids[LIST_MAX];

static void build_skill_list2(Battler *a)
{
    ui_list_init(&B.list, 10, 44, 300, 190, 26);
    ui_list_clear(&B.list);
    for (int s = 2; s < db.nskills && s < MAX_DB && B.list.n < LIST_MAX; s++) {
        if (!db.skills[s].exists || !actor_skill_known(a, s)) continue;
        if (db.skills[s].occasion == 2 || db.skills[s].occasion == 3) continue;
        if (db.skills[s].scope == 0) continue;
        char cost[20] = ""; if (db.skills[s].mpCost) snprintf(cost, sizeof cost, "MP %d", (int)floorf(db.skills[s].mpCost * b_sparam(a, 4)));
        s_list_ids[B.list.n] = s;
        ui_list_add(&B.list, skill_label(s), cost, skill_can_pay(a, s));
    }
}
static void build_item_list(void)
{
    ui_list_init(&B.list, 10, 44, 300, 190, 26);
    ui_list_clear(&B.list);
    for (int i = 1; i < db.nitems && i < MAX_DB && B.list.n < LIST_MAX; i++) {
        if (!db.items[i].exists || g.items[i] <= 0) continue;
        if (db.items[i].occasion == 2 || db.items[i].occasion == 3) continue;
        if (db.items[i].itype != 1 || db.items[i].scope == 0) continue;
        char cnt[20]; snprintf(cnt, sizeof cnt, "x%d", g.items[i]);
        s_list_ids[B.list.n] = i;
        ui_list_add(&B.list, tx(db.items[i].name), cnt, true);
    }
}

static void input_update(void)
{
    Battler *a = cur_actor();
    switch (B.cs) {
        case CS_PARTY: {
            if (ui_tap(20, 150, 130, 70) || (g_in.down & K_A)) { audio_sys(SND_OK); B.inputIdx = -1; next_actor(); }
            else if (ui_tap(170, 150, 130, 70) || (g_in.down & K_B)) {
                if (!B.canEscape) { audio_sys(SND_BUZZER); break; }
                audio_sys(SND_ESCAPE);
                if (B.escapeRatio >= 1.0f || rndf() < B.escapeRatio) {
                    blog("%s", ui_s(S_B_ESCAPE_OK)); B.result = 1; audio_bgm_resume(); B.phase = BP_END; B.wait = 30;
                } else {
                    B.escapeRatio += 0.1f; blog("%s", ui_s(S_B_ESCAPE_FAIL));
                    for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b) b->act.kind = 0; }
                    start_turn_exec(false);
                }
            }
            break;
        }
        case CS_ACTOR: {
            if (!a) { next_actor(); break; }
            if (ui_tap(10, 150, 148, 40) || ((g_in.down & K_A))) { audio_sys(SND_OK); choose_target_or_set(a, 1, 1, action_scope(&(BAction){1, 1, 0})); }
            else if (ui_tap(162, 150, 148, 40)) {
                audio_sys(SND_OK); build_skill_list2(a); B.cs = CS_SKILL;
            } else if (ui_tap(10, 194, 148, 40)) {
                audio_sys(SND_OK); a->act.kind = 2; a->act.id = 2; a->act.target = -1; next_actor();
            } else if (ui_tap(162, 194, 148, 40)) {
                audio_sys(SND_OK); build_item_list(); B.cs = CS_ITEM;
            } else if ((g_in.down & K_B) || ui_tap(250, 4, 66, 22)) { audio_sys(SND_CANCEL); prev_actor(); }
            break;
        }
        case CS_SKILL: case CS_ITEM: {
            int r = ui_list_update(&B.list);
            if (r == -1 || ui_tap(250, 4, 66, 22)) { audio_sys(SND_CANCEL); B.cs = CS_ACTOR; }
            else if (r >= 0) {
                int id = s_list_ids[r];
                if (B.cs == CS_SKILL) { audio_sys(SND_OK); choose_target_or_set(a, 3, id, db.skills[id].scope); }
                else { audio_sys(SND_OK); choose_target_or_set(a, 4, id, db.items[id].scope); }
            }
            break;
        }
        case CS_TARGET: {
            int r = ui_list_update(&B.list);
            if (r == -1 || ui_tap(250, 4, 66, 22)) { audio_sys(SND_CANCEL); B.cs = a && a->act.kind == 4 ? CS_ITEM : (a && a->act.kind == 3 ? CS_SKILL : CS_ACTOR); if (B.cs == CS_ACTOR) {} }
            else if (r >= 0) { a->act.target = B.tgtMap[r]; audio_sys(SND_OK); next_actor(); }
            break;
        }
    }
}

/* called every frame by the main loop while in battle */
void battle_input(void)
{
    if (!B.active || B.phase != BP_INPUT) return;
    if (g_binterp.running || msg_busy() || B.wait > 0) return;
    input_update();
}

/* ----------------------------------------------------------------------------- drawing */
static void draw_log(void)
{
    if (B.nlog == 0) return;
    float h = 6 + B.nlog * 15;
    plat_rect(6, 4, 388, h, RGBA(0, 0, 0, 170));
    for (int i = 0; i < B.nlog; i++) plat_text(B.log[i], 12, 6 + i * 15, 0.5f, RGBA(255, 255, 255, 255));
}

void battle_draw_top(void)
{
    plat_rect(0, 0, SCR_W, SCR_H, RGBA(0, 0, 0, 255));
    if (B.bg) plat_blit(B.bg, 0, 0, 400, 240, 0, 0, 1.0f, false, 255);
    for (int i = 0; i < B.nen; i++) {
        Battler *e = &B.en[i];
        if (e->hidden) continue;
        const ImgInfo *im = &db.enemyimgs[db.enemies[e->id].img];
        if (!B.enTex[i]) continue;
        float x = VLETTER + e->x * VSCALE - im->w / 2.0f, y = e->y * VSCALE - im->h;
        int alpha = 255;
        if (e->collapse) { alpha = 255 - e->collapse * 255 / 30; if (alpha < 0) alpha = 0; }
        if (e->flash > 0 && (e->flash / 3) % 2 == 0) alpha = alpha / 3;
        if (alpha > 0) plat_blit(B.enTex[i], 0, 0, im->w, im->h, x, y, 1.0f, false, alpha);
        if (e->popupTimer > 0) {
            char t[16]; snprintf(t, sizeof t, "%d", e->popup);
            uint32_t col = e->popupKind ? RGBA(120, 255, 140, 255) : (e->popupCrit ? RGBA(255, 120, 60, 255) : RGBA(255, 255, 255, 255));
            float py = y + im->h / 2.0f - (40 - e->popupTimer) * 0.6f;
            plat_text(t, x + im->w / 2.0f - plat_text_w(t, 0.8f) / 2, py, 0.8f, RGBA(0, 0, 0, 255));
            plat_text(t, x + im->w / 2.0f - plat_text_w(t, 0.8f) / 2 - 1, py - 1, 0.8f, col);
        }
        if (B.phase == BP_INPUT && B.cs == CS_TARGET && B.pendingScope == 1) {
            int sel = B.list.cursor < B.list.n ? B.tgtMap[B.list.cursor] : -1;
            if (sel == i) ui_text_centered("v", x + im->w / 2.0f, y - 14, 0.7f, RGBA(255, 240, 80, 255));
        }
    }
    draw_log();
    draw_messages();
}

void battle_draw_bottom(void)
{
    plat_rect(0, 0, BSCR_W, BSCR_H, RGBA(24, 24, 40, 255));
    bool listMode = (B.phase == BP_INPUT) && (B.cs == CS_SKILL || B.cs == CS_ITEM || B.cs == CS_TARGET);
    Battler *a = (B.phase == BP_INPUT) ? cur_actor() : NULL;
    if (listMode && a) {
        char hdr[96]; snprintf(hdr, sizeof hdr, "%s  HP %d/%d  MP %d/%d", b_name(a), a->hp, b_param(a, 0), a->mp, b_param(a, 1));
        plat_text(hdr, 8, 6, 0.5f, RGBA(255, 255, 255, 255));
        ui_button(250, 4, 66, 22, ui_s(S_BACK), true, NULL);
        const char *title = B.cs == CS_SKILL ? ui_s(S_SKILLS) : (B.cs == CS_ITEM ? ui_s(S_ITEMS) : ui_s(S_CHOOSE_TARGET));
        plat_text(title, 10, 26, 0.5f, RGBA(255, 230, 120, 255));
        if (B.list.n == 0) plat_text(ui_s(S_NOTHING), 20, 60, 0.5f, RGBA(200, 200, 200, 255));
        ui_list_draw(&B.list);
        return;
    }
    /* party rows */
    for (int i = 0; i < g.nparty; i++) {
        Battler *b = party_member(i); if (!b) continue;
        float y = 4 + i * 36;
        bool act = (B.phase == BP_INPUT && i == B.inputIdx && B.cs != CS_PARTY);
        plat_rect(4, y, 312, 33, act ? RGBA(70, 70, 20, 230) : RGBA(0, 0, 0, 120));
        char t[96]; snprintf(t, sizeof t, "%s  %s%d", b_name(b), ui_s(S_LV), b->level);
        plat_text(t, 10, y + 1, 0.5f, b_dead(b) ? RGBA(255, 90, 90, 255) : RGBA(255, 255, 255, 255));
        snprintf(t, sizeof t, "HP %d/%d", b->hp, b_param(b, 0));
        plat_text(t, 10, y + 16, 0.45f, RGBA(255, 255, 255, 255));
        ui_draw_bar(110, y + 20, 90, 7, b->hp, b_param(b, 0), RGBA(220, 70, 70, 255), RGBA(255, 150, 120, 255));
        snprintf(t, sizeof t, "MP %d/%d", b->mp, b_param(b, 1));
        plat_text(t, 206, y + 16, 0.45f, RGBA(255, 255, 255, 255));
        ui_draw_bar(206, y + 30, 100, 3, b->mp, b_param(b, 1), RGBA(60, 90, 230, 255), RGBA(120, 160, 255, 255));
        if (b->popupTimer > 0) {
            snprintf(t, sizeof t, "%s%d", b->popupKind ? "+" : "-", b->popup);
            plat_text(t, 250, y + 1 - (40 - b->popupTimer) * 0.2f, 0.6f, b->popupKind ? RGBA(120, 255, 140, 255) : RGBA(255, 120, 100, 255));
        }
    }
    if (B.phase == BP_INPUT && B.wait == 0 && !g_binterp.running && !msg_busy()) {
        if (B.cs == CS_PARTY) {
            ui_button(20, 150, 130, 70, ui_s(S_FIGHT), true, NULL);
            ui_button(170, 150, 130, 70, ui_s(S_ESCAPE), B.canEscape, NULL);
        } else if (B.cs == CS_ACTOR) {
            ui_button(10, 150, 148, 40, ui_s(S_ATTACK), true, NULL);
            ui_button(162, 150, 148, 40, ui_s(S_SKILLS), true, NULL);
            ui_button(10, 194, 148, 40, ui_s(S_GUARD), true, NULL);
            ui_button(162, 194, 148, 40, ui_s(S_ITEMS), true, NULL);
            ui_button(250, 4, 66, 22, ui_s(S_BACK), true, NULL);
        }
    } else if (B.phase == BP_WAITKEY) {
        ui_text_centered(ui_s(S_CONTINUE_HINT), 160, 190, 0.55f, RGBA(255, 240, 160, 255));
    } else if (B.phase == BP_ACTION || B.phase == BP_TURNEND) {
        char t[32]; snprintf(t, sizeof t, ui_s(S_TURN), B.turn);
        ui_text_centered(t, 160, 190, 0.55f, RGBA(200, 200, 220, 255));
    }
}

void battle_draw(void)
{
    plat_target(0); battle_draw_top();
    draw_pics_and_fade();
    plat_target(1);
    if (msg.active && msg.hasChoices) ui_choice_draw();
    else battle_draw_bottom();
}
