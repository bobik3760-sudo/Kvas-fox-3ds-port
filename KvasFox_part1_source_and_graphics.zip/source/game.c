/* game.c - top level: scene management, per-frame update order, new game / load. */
#include "game.h"
#include <stdio.h>

PInput g_in;
uint32_t g_frame;
int g_scene = SC_TITLE;
static int s_battle_escape_flag, s_battle_lose_flag;

bool game_init(void)
{
    if (!data_init()) return false;
    config_load();
    audio_init();
    ui_init();
    rng_seed(0x1234567u);
    player_start_new();
    game_set_scene(SC_TITLE);
    return true;
}

void game_set_scene(int sc)
{
    g_scene = sc;
    g_scene_request = -1;
    if (sc == SC_TITLE) {
        pics_clear();
        msg.active = 0; scrolltext.active = 0;
        g_interp.running = 0; g_binterp.running = 0;
        g_fade = 0; g_fade_target = 0;
        g_battle_request = 0;
        audio_bgm_stop();
        map_free_deferred();
    } else if (sc == SC_GAMEOVER) {
        pics_clear(); msg.active = 0; scrolltext.active = 0;
        g_interp.running = 0;
        g_fade = 0; g_fade_target = 0;
        audio_me(db.gameoverMe, 90);
    }
}

static void enter_map_fresh(int mapId, int x, int y, int dir)
{
    pics_clear();
    msg.active = 0; scrolltext.active = 0;
    g_interp.running = 0; g_binterp.running = 0;
    map_free_deferred();
    map_unload();
    audio_bgm_stop();                    /* title music ends when a game starts or is loaded */
    player_start_new();
    player_reserve_transfer(mapId, x, y, dir, 2);
    player_perform_transfer();
    g_fade = 255; g_fade_target = 0; g_fade_white = 0;
    g_scene = SC_MAP;
}

void game_begin_new(void)
{
    game_new();
    enter_map_fresh(db.startMap, db.startX, db.startY, 2);
}

bool game_begin_load(int slot)
{
    if (!save_read(slot)) return false;
    enter_map_fresh(g.mapId, g.px, g.py, g.pdir);
    ui_apply_loaded_events();
    map_refresh_events();
    return true;
}

/* ----------------------------------------------------------------------------- map scene */
static void update_interpreter(void)
{
    for (int guard = 0; guard < 64; guard++) {
        interp_update(&g_interp);
        if (g_interp.running) return;
        if (!map_setup_starting_event()) return;
    }
}

static void handle_transfer(void)
{
    if (!player_transfer_pending()) return;
    int ft = player_transfer_fade();
    if (ft == 2 || g_fade >= 255) {
        player_perform_transfer();
        if (ft != 2) g_fade_target = 0;
    }
}

static void world_update(bool active)
{
    update_interpreter();
    msg_update();
    interp_update_scroll();
    player_update(active);
    map_update_events();
    map_update_scroll();
    g.playtime++;
}

static void scene_map(void)
{
    if (g_scene_request == SC_TITLE) { game_set_scene(SC_TITLE); return; }
    if (g_scene_request == SC_GAMEOVER) { game_set_scene(SC_GAMEOVER); return; }
    if (g_battle_request) {
        int t = g_battle_request; g_battle_request = 0;
        s_battle_escape_flag = g_battle_can_escape; s_battle_lose_flag = g_battle_can_lose;
        battle_start(t, g_battle_can_escape, g_battle_can_lose);
        g_scene = SC_BATTLE;
        return;
    }
    if ((g_in.down & K_SELECT) && !ui_menu_open() && !ui_shop_active()) { ui_toggle_lang(); }
    fade_update();
    handle_transfer();
    ui_update_map();
    bool paused = ui_menu_open() || ui_shop_active();
    if (!paused) world_update(true);
    else { msg_update(); }
    map_free_deferred();
}

/* ----------------------------------------------------------------------------- battle scene */
static void scene_battle(void)
{
    if ((g_in.down & K_SELECT)) ui_toggle_lang();
    fade_update();
    battle_input();
    battle_update();
    if (battle_finished()) {
        int r = battle_result();
        battle_end_cleanup();
        g_scene = SC_MAP;
        if (r == 2 && !s_battle_lose_flag) { g_battle_result = 2; g_scene_request = SC_GAMEOVER; }
        else g_battle_result = r;
    }
}

void game_frame(const PInput *in)
{
    g_in = *in;
    g_frame++;
    audio_update();
    switch (g_scene) {
        case SC_TITLE: ui_title_update(); ui_title_draw(); break;
        case SC_MAP: scene_map(); if (g_scene == SC_MAP) draw_map_scene(); break;
        case SC_BATTLE: scene_battle(); if (g_scene == SC_BATTLE) battle_draw(); break;
        case SC_GAMEOVER: ui_gameover_update(); ui_gameover_draw(); break;
    }
    if (g_scene_request == SC_TITLE && g_scene != SC_MAP) game_set_scene(SC_TITLE);
}
