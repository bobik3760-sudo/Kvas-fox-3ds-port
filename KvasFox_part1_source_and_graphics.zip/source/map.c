/* map.c - map loading, characters, event pages, movement, move routes, player, followers, camera.
 * Behaviour ported from rmmz_objects.js (Game_CharacterBase / Game_Character / Game_Event / Game_Player). */
#include "game.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

MapData M;
Char evs[MAX_EV];
int g_nevs;
Char player, followers[MAX_PARTY - 1];
int g_needs_refresh;
float g_disp_x, g_disp_y;

static PTex *s_sheets[MAX_SHEETS];
static PTex *s_faces[8];

#define VIEW_TW (SCR_W / (float)TILE)
#define VIEW_TH (SCR_H / (float)TILE)

static int rev(int d) { return 10 - d; }
int map_xwd(int x, int d) { return x + (d == 6) - (d == 4); }
int map_ywd(int y, int d) { return y + (d == 2) - (d == 8); }

PTex *map_sheet_tex(int sheet)
{
    if (sheet < 0 || sheet >= db.nchars || sheet >= MAX_SHEETS) return NULL;
    if (!s_sheets[sheet]) { char n[16]; snprintf(n, sizeof n, "c%03d", sheet); s_sheets[sheet] = plat_tex_load(n); }
    return s_sheets[sheet];
}
PTex *face_tex(int face)
{
    if (face < 0 || face >= db.nfaces || face >= 8) return NULL;
    if (!s_faces[face]) { char n[16]; snprintf(n, sizeof n, "f%02d", face); s_faces[face] = plat_tex_load(n); }
    return s_faces[face];
}

/* ----------------------------------------------------------------------------- map load */
typedef struct { const int32_t *p, *end; } R;
static int32_t rd(R *r)
{
    if (r->p >= r->end) { fprintf(stderr, "map: read past end\n"); exit(1); }
    return *r->p++;
}
static const void *rd_blob(R *r)
{
    int n = rd(r); const void *p = r->p; r->p += (n + 3) / 4; return p;
}

static uint8_t *s_deferred[8]; static int s_ndef;
static void defer_free(uint8_t *p)
{
    if (!p) return;
    if (!g_interp.running || s_ndef >= 8) { free(p); return; }
    s_deferred[s_ndef++] = p;          /* a running event may still read its command list from this buffer */
}
void map_free_deferred(void)
{
    if (g_interp.running) return;
    for (int i = 0; i < s_ndef; i++) free(s_deferred[i]);
    s_ndef = 0;
}

void map_unload(void)
{
    for (int i = 0; i < M.natlas; i++) if (M.atlas[i].tex) plat_tex_free(M.atlas[i].tex);
    if (M.evs) { for (int i = 0; i < M.nev; i++) free(M.evs[i].pages); free(M.evs); }
    defer_free(M.raw);
    memset(&M, 0, sizeof M);
    memset(evs, 0, sizeof evs);
    g_nevs = 0;
}

bool map_load(int id)
{
    map_unload();
    char path[32]; snprintf(path, sizeof path, "maps/m%03d.bin", id);
    size_t sz; uint8_t *buf = plat_read_file(path, &sz);
    if (!buf) { fprintf(stderr, "cannot load %s\n", path); return false; }
    M.raw = buf;
    R r = { (const int32_t *)buf, (const int32_t *)(buf + sz) };
    if (rd(&r) != 0x4D415031) { fprintf(stderr, "bad map magic\n"); return false; }
    M.id = id; M.w = rd(&r); M.h = rd(&r);
    M.bgm = rd(&r); M.bgmVol = rd(&r); M.bgs = rd(&r); M.displayName = rd(&r); M.noDash = rd(&r); M.overworld = rd(&r);
    M.natlas = rd(&r);
    if (M.natlas > 8) { fprintf(stderr, "too many atlas pages\n"); return false; }
    for (int i = 0; i < M.natlas; i++) {
        M.atlas[i].w = rd(&r); M.atlas[i].h = rd(&r); M.atlas[i].cols = rd(&r); M.atlas[i].cap = rd(&r);
        char n[24]; snprintf(n, sizeof n, "t%03d_%d", id, i);
        M.atlas[i].tex = plat_tex_load(n);
    }
    M.lower = rd_blob(&r); M.upper = rd_blob(&r); M.pass = rd_blob(&r);
    if (rd(&r) != 0x5EC70001) { fprintf(stderr, "map %d desync 1\n", id); return false; }
    M.nev = rd(&r);
    M.evs = calloc(M.nev ? M.nev : 1, sizeof(EvDef));
    for (int i = 0; i < M.nev; i++) {
        EvDef *e = &M.evs[i];
        e->id = rd(&r); e->x = rd(&r); e->y = rd(&r); e->npages = rd(&r);
        e->pages = calloc(e->npages ? e->npages : 1, sizeof(EvPage));
        for (int k = 0; k < e->npages; k++) {
            EvPage *p = &e->pages[k];
            p->cf = rd(&r); p->sw1 = rd(&r); p->sw2 = rd(&r); p->varId = rd(&r); p->varVal = rd(&r);
            p->selfCh = rd(&r); p->itemId = rd(&r); p->actorId = rd(&r);
            p->imgKind = rd(&r); p->sheet = rd(&r); p->idx = rd(&r); p->dir = rd(&r); p->pat = rd(&r);
            p->moveType = rd(&r); p->speed = rd(&r); p->freq = rd(&r); p->rep = rd(&r); p->skip = rd(&r);
            p->nroute = rd(&r); p->route = r.p;
            for (int q = 0; q < p->nroute * 4; q++) rd(&r);
            p->opt = rd(&r); p->prio = rd(&r); p->trig = rd(&r);
            p->ncmd = rd(&r); p->cmd = r.p;
            for (int q = 0; q < p->ncmd; q++) rd(&r);
        }
    }
    if (rd(&r) != 0x5EC70002) { fprintf(stderr, "map %d desync 2\n", id); return false; }

    /* runtime events */
    g_nevs = 0;
    for (int i = 0; i < M.nev && g_nevs < MAX_EV; i++) {
        Char *c = &evs[g_nevs++];
        char_init(c);
        c->kind = CK_EVENT; c->used = 1; c->id = M.evs[i].id; c->def = &M.evs[i];
        c->x = M.evs[i].x; c->y = M.evs[i].y; c->rx = (float)c->x; c->ry = (float)c->y;
        c->pageIdx = -2;     /* force a refresh */
    }
    g_needs_refresh = 1;
    return true;
}

bool map_valid(int x, int y) { return x >= 0 && y >= 0 && x < M.w && y < M.h; }
bool map_passable(int x, int y, int d)
{
    if (!map_valid(x, y)) return false;
    int idx = d == 2 ? 0 : d == 4 ? 1 : d == 6 ? 2 : 3;
    return (M.pass[y * M.w + x] >> idx) & 1;
}
bool map_counter(int x, int y) { return map_valid(x, y) && (M.pass[y * M.w + x] & 0x10); }

Char *map_event(int eventId)
{
    for (int i = 0; i < g_nevs; i++) if (evs[i].id == eventId) return &evs[i];
    return NULL;
}
Char *map_char(int id)
{
    if (id < 0) return &player;
    return map_event(id);
}

/* ----------------------------------------------------------------------------- characters */
void char_init(Char *c)
{
    memset(c, 0, sizeof *c);
    c->dir = 2; c->pattern = 1; c->sheet = -1; c->moveSpeed = 4; c->moveFreq = 3;
    c->priority = 1; c->trigger = -1; c->opacity = 255; c->walkAnime = 1; c->pageIdx = -1; c->success = 1;
}
bool char_is_moving(const Char *c) { return fabsf(c->rx - c->x) > 1e-5f || fabsf(c->ry - c->y) > 1e-5f; }
static bool jumping(const Char *c) { return c->jumpCount > 0; }
bool char_is_stopping(const Char *c) { return !char_is_moving(c) && !jumping(c); }
float char_real_speed(const Char *c) { return (float)(c->moveSpeed + (c->dashing ? 1 : 0)); }
static float dist_per_frame(const Char *c) { return powf(2.0f, char_real_speed(c)) / 256.0f; }

void char_set_dir(Char *c, int d) { if (!c->dirFix && d) c->dir = d; }
void char_locate(Char *c, int x, int y)
{
    c->x = x; c->y = y; c->rx = (float)x; c->ry = (float)y; c->stopCount = 0; c->jumpCount = 0;
}

static bool is_normal_priority(const Char *c) { return c->priority == 1; }

static bool followers_visible(void) { return db.followers && g.nparty > 1; }
static bool collided_with_followers(int x, int y)
{
    if (!followers_visible()) return false;
    for (int i = 0; i < g.nparty - 1 && i < MAX_PARTY - 1; i++) if (followers[i].x == x && followers[i].y == y) return true;
    return false;
}

static bool collided_with_events(const Char *self, int x, int y)
{
    for (int i = 0; i < g_nevs; i++) {
        const Char *e = &evs[i];
        if (e == self || e->erased || e->pageIdx < 0 || e->through) continue;
        if (e->x == x && e->y == y && is_normal_priority(e)) return true;
    }
    return false;
}

bool char_can_pass(Char *c, int x, int y, int d)
{
    int x2 = map_xwd(x, d), y2 = map_ywd(y, d);
    if (!map_valid(x2, y2)) return false;
    if (c->through) return true;
    if (!map_passable(x, y, d) || !map_passable(x2, y2, rev(d))) return false;
    if (collided_with_events(c, x2, y2)) return false;
    if (c->kind == CK_EVENT) {
        if (is_normal_priority(c) && ((player.x == x2 && player.y == y2 && !player.through) || collided_with_followers(x2, y2)))
            return false;
    }
    return true;
}

static void check_touch(Char *c, int x, int y);
static void check_touch_front(Char *c, int d)
{
    check_touch(c, map_xwd(c->x, d), map_ywd(c->y, d));
}

static void follower_chase_all(void);

void char_move_straight(Char *c, int d)
{
    if (c->kind == CK_PLAYER && char_can_pass(c, c->x, c->y, d)) follower_chase_all();
    c->success = char_can_pass(c, c->x, c->y, d);
    if (c->success) {
        char_set_dir(c, d);
        c->x = map_xwd(c->x, d); c->y = map_ywd(c->y, d);
        c->rx = (float)map_xwd(c->x, rev(d)); c->ry = (float)map_ywd(c->y, rev(d));
        c->stopCount = 0;
        if (c->kind == CK_PLAYER) g.steps++;
    } else {
        char_set_dir(c, d);
        check_touch_front(c, d);
    }
}

void char_move_diag(Char *c, int h, int v)
{
    bool ok = char_can_pass(c, c->x, c->y, v) && char_can_pass(c, c->x, map_ywd(c->y, v), h);
    if (!ok) ok = char_can_pass(c, c->x, c->y, h) && char_can_pass(c, map_xwd(c->x, h), c->y, v);
    c->success = ok;
    if (ok) {
        int ox = c->x, oy = c->y;
        c->x = map_xwd(c->x, h); c->y = map_ywd(c->y, v);
        c->rx = (float)ox; c->ry = (float)oy; c->stopCount = 0;
    }
    if (c->dir == rev(h)) char_set_dir(c, h);
    if (c->dir == rev(v)) char_set_dir(c, v);
}

void char_jump(Char *c, int dx, int dy)
{
    if (abs(dx) > abs(dy)) { if (dx) char_set_dir(c, dx < 0 ? 4 : 6); }
    else if (dy) char_set_dir(c, dy < 0 ? 8 : 2);
    c->x += dx; c->y += dy;
    int dist = (int)floorf(sqrtf((float)(dx * dx + dy * dy)) + 0.5f);
    c->jumpPeak = 10 + dist - c->moveSpeed;
    if (c->jumpPeak < 1) c->jumpPeak = 1;
    c->jumpCount = c->jumpPeak * 2;
    c->stopCount = 0;
}

void char_turn_toward(Char *c, const Char *o)
{
    int sx = c->x - o->x, sy = c->y - o->y;
    if (abs(sx) > abs(sy)) char_set_dir(c, sx > 0 ? 4 : 6);
    else if (sy != 0) char_set_dir(c, sy > 0 ? 8 : 2);
}
static void turn_away(Char *c, const Char *o)
{
    int sx = c->x - o->x, sy = c->y - o->y;
    if (abs(sx) > abs(sy)) char_set_dir(c, sx > 0 ? 6 : 4);
    else if (sy != 0) char_set_dir(c, sy > 0 ? 2 : 8);
}
static void move_toward(Char *c, const Char *o)
{
    int sx = c->x - o->x, sy = c->y - o->y;
    if (abs(sx) > abs(sy)) {
        char_move_straight(c, sx > 0 ? 4 : 6);
        if (!c->success && sy != 0) char_move_straight(c, sy > 0 ? 8 : 2);
    } else if (sy != 0) {
        char_move_straight(c, sy > 0 ? 8 : 2);
        if (!c->success && sx != 0) char_move_straight(c, sx > 0 ? 4 : 6);
    }
}
static void move_away(Char *c, const Char *o)
{
    int sx = c->x - o->x, sy = c->y - o->y;
    if (abs(sx) > abs(sy)) {
        char_move_straight(c, sx > 0 ? 6 : 4);
        if (!c->success && sy != 0) char_move_straight(c, sy > 0 ? 2 : 8);
    } else if (sy != 0) {
        char_move_straight(c, sy > 0 ? 2 : 8);
        if (!c->success && sx != 0) char_move_straight(c, sx > 0 ? 6 : 4);
    }
}
static void move_random(Char *c)
{
    int d = 2 + rnd(4) * 2;
    if (char_can_pass(c, c->x, c->y, d)) char_move_straight(c, d);
}

/* ----------------------------------------------------------------------------- move routes */
static void route_end(Char *c)
{
    if (c->routeRepeat) { c->routeIdx = -1; }
    else if (c->forcing) {
        c->forcing = 0;
        c->route = c->oroute; c->nroute = c->noroute; c->routeIdx = c->oRouteIdx;
        c->routeRepeat = c->oRepeat; c->routeSkippable = c->oSkip; c->hasOrig = 0;
        c->success = 0;
    }
}

void char_force_route(Char *c, const int32_t *route, int n, int repeat, int skippable)
{
    if (!c->hasOrig) {
        c->oroute = c->route; c->noroute = c->nroute; c->oRouteIdx = c->routeIdx;
        c->oRepeat = c->routeRepeat; c->oSkip = c->routeSkippable; c->hasOrig = 1;
    }
    c->route = route; c->nroute = n; c->routeIdx = 0; c->routeRepeat = repeat; c->routeSkippable = skippable;
    c->forcing = 1; c->waitCount = 0;
}
bool char_route_done(const Char *c) { return !c->forcing; }

static void process_route_cmd(Char *c, const int32_t *cmd)
{
    int code = cmd[0], a = cmd[1], b = cmd[2];
    switch (code) {
        case 1: char_move_straight(c, 2); break;
        case 2: char_move_straight(c, 4); break;
        case 3: char_move_straight(c, 6); break;
        case 4: char_move_straight(c, 8); break;
        case 5: char_move_diag(c, 4, 2); break;
        case 6: char_move_diag(c, 6, 2); break;
        case 7: char_move_diag(c, 4, 8); break;
        case 8: char_move_diag(c, 6, 8); break;
        case 9: move_random(c); break;
        case 10: move_toward(c, &player); break;
        case 11: move_away(c, &player); break;
        case 12: char_move_straight(c, c->dir); break;
        case 13: { int f = c->dirFix; c->dirFix = 1; char_move_straight(c, rev(c->dir)); c->dirFix = f; break; }
        case 14: char_jump(c, a, b); break;
        case 15: c->waitCount = a - 1; break;
        case 16: char_set_dir(c, 2); break;
        case 17: char_set_dir(c, 4); break;
        case 18: char_set_dir(c, 6); break;
        case 19: char_set_dir(c, 8); break;
        case 20: char_set_dir(c, c->dir == 2 ? 4 : c->dir == 4 ? 8 : c->dir == 6 ? 2 : 6); break;
        case 21: char_set_dir(c, c->dir == 2 ? 6 : c->dir == 4 ? 2 : c->dir == 6 ? 8 : 4); break;
        case 22: char_set_dir(c, rev(c->dir)); break;
        case 23: char_set_dir(c, rnd(2) ? (c->dir == 2 ? 4 : c->dir == 4 ? 8 : c->dir == 6 ? 2 : 6) : (c->dir == 2 ? 6 : c->dir == 4 ? 2 : c->dir == 6 ? 8 : 4)); break;
        case 24: char_set_dir(c, 2 + rnd(4) * 2); break;
        case 25: char_turn_toward(c, &player); break;
        case 26: turn_away(c, &player); break;
        case 27: sw_set(a, true); break;
        case 28: sw_set(a, false); break;
        case 29: c->moveSpeed = a; break;
        case 30: c->moveFreq = a; break;
        case 31: c->walkAnime = 1; break;
        case 32: c->walkAnime = 0; break;
        case 33: c->stepAnime = 1; break;
        case 34: c->stepAnime = 0; break;
        case 35: c->dirFix = 1; break;
        case 36: c->dirFix = 0; break;
        case 37: c->through = 1; break;
        case 38: c->through = 0; break;
        case 39: c->transparent = 1; break;
        case 40: c->transparent = 0; break;
        case 41: c->sheet = a; c->index = b; break;
        case 42: c->opacity = a; break;
        case 44: audio_se(a, b, cmd[3]); break;
        default: break;
    }
}

static void update_routine_move(Char *c)
{
    if (c->waitCount > 0) { c->waitCount--; return; }
    c->success = 1;
    if (c->routeIdx >= c->nroute) { route_end(c); return; }
    if (c->routeIdx < 0) c->routeIdx = 0;
    if (c->nroute <= 0) { route_end(c); return; }
    const int32_t *cmd = c->route + c->routeIdx * 4;
    process_route_cmd(c, cmd);
    /* failsafe (not in RMMZ): a forced route that has been blocked on one command for 4 s skips it,
     * so a collision difference in this port can never soft-lock the game */
    if (c->forcing && !c->success && !c->routeSkippable) {
        if (++c->blockedFrames > 240) { c->blockedFrames = 0; c->success = 1; }
    } else c->blockedFrames = 0;
    /* advanceMoveRouteIndex */
    if (c->route && (c->success || c->routeSkippable)) {
        c->routeIdx++;
        if (c->routeRepeat && c->routeIdx >= c->nroute) c->routeIdx = 0;
    }
}

/* ----------------------------------------------------------------------------- event pages */
static bool meets_conditions(const Char *c, const EvPage *p)
{
    if ((p->cf & 1) && !sw_get(p->sw1)) return false;
    if ((p->cf & 2) && !sw_get(p->sw2)) return false;
    if ((p->cf & 4) && var_get(p->varId) < p->varVal) return false;
    if ((p->cf & 8) && !ss_get(M.id, c->id, p->selfCh)) return false;
    if ((p->cf & 16) && item_count(0, p->itemId) <= 0) return false;
    if ((p->cf & 32) && !party_has(p->actorId)) return false;
    return true;
}

static void setup_page(Char *c)
{
    if (c->pageIdx >= 0) {
        const EvPage *p = &c->def->pages[c->pageIdx];
        c->page = p;
        c->sheet = p->imgKind ? p->sheet : -1; c->index = p->idx;
        c->dir = p->dir ? p->dir : 2; c->pattern = p->pat;
        c->moveSpeed = p->speed; c->moveFreq = p->freq;
        c->walkAnime = p->opt & 1; c->stepAnime = (p->opt >> 1) & 1; c->dirFix = (p->opt >> 2) & 1; c->through = (p->opt >> 3) & 1;
        c->route = p->route; c->nroute = p->nroute; c->routeIdx = 0; c->routeRepeat = p->rep; c->routeSkippable = p->skip;
        c->forcing = 0; c->hasOrig = 0;
        c->moveType = p->moveType; c->trigger = p->trig; c->priority = p->prio;
        c->transparent = 0; c->opacity = 255;
    } else {
        c->page = NULL; c->sheet = -1; c->moveType = 0; c->trigger = -1; c->through = 1; c->forcing = 0;
    }
    c->starting = 0;
}

static void event_refresh(Char *c)
{
    int np = -1;
    if (!c->erased) {
        for (int i = c->def->npages - 1; i >= 0; i--) if (meets_conditions(c, &c->def->pages[i])) { np = i; break; }
    }
    if (np != c->pageIdx) { c->pageIdx = np; setup_page(c); }
}

void map_refresh_events(void)
{
    for (int i = 0; i < g_nevs; i++) event_refresh(&evs[i]);
    g_needs_refresh = 0;
}

bool char_is_trigger_in(const Char *c, int mask) { return c->trigger >= 0 && (mask >> c->trigger) & 1; }

void char_event_start(Char *c)
{
    if (!c->page || c->page->ncmd <= 3) return;
    c->starting = 1;
    if (char_is_trigger_in(c, 7)) {
        if (!c->locked) { c->prelockDir = c->dir; char_turn_toward(c, &player); c->locked = 1; }
    }
}

static void event_unlock(Char *c)
{
    if (c->locked) { c->locked = 0; char_set_dir(c, c->prelockDir); }
}
void map_erase_event(int id)
{
    Char *c = map_event(id);
    if (c) { c->erased = 1; c->locked = 0; g_needs_refresh = 1; }
}
void map_unlock_event(int id) { Char *c = map_event(id); if (c) event_unlock(c); }

static void check_touch(Char *c, int x, int y)
{
    if (c->kind == CK_PLAYER) {
        if (g_interp.running || msg_busy()) return;
        for (int i = 0; i < g_nevs; i++) {
            Char *e = &evs[i];
            if (e->x == x && e->y == y && char_is_trigger_in(e, 6) && is_normal_priority(e)) char_event_start(e);
        }
    } else if (c->kind == CK_EVENT) {
        if (g_interp.running) return;
        if (c->trigger == 2 && player.x == x && player.y == y && !jumping(c) && is_normal_priority(c)) char_event_start(c);
    }
}

/* ----------------------------------------------------------------------------- per-frame update */
static bool near_player(const Char *c) { return abs(c->x - player.x) <= 20 && abs(c->y - player.y) <= 14; }

static void event_self_move(Char *c)
{
    if (c->locked || !near_player(c) || c->stopCount <= 30 * (5 - c->moveFreq)) return;
    switch (c->moveType) {
        case 1:
            switch (rnd(6)) { case 0: case 1: move_random(c); break; case 2: case 3: case 4: char_move_straight(c, c->dir); break; default: c->stopCount = 0; }
            break;
        case 2:
            if (abs(c->x - player.x) + abs(c->y - player.y) < 20) {
                switch (rnd(6)) { case 0: case 1: case 2: case 3: move_toward(c, &player); break; case 4: move_random(c); break; default: char_move_straight(c, c->dir); }
            } else move_random(c);
            break;
        case 3: update_routine_move(c); break;
        default: break;
    }
}

static void update_animation(Char *c)
{
    if (char_is_moving(c) && c->walkAnime) c->animCount += 1.5f;
    else if (c->stepAnime || c->pattern != 1) c->animCount += 1.0f;
    float wait = (9 - char_real_speed(c)) * 3;
    if (c->animCount >= wait) {
        if (!c->stepAnime && c->stopCount > 0) c->pattern = 1;
        else c->pattern = (c->pattern + 1) % 4;
        c->animCount = 0;
    }
}

void char_update(Char *c)
{
    if (char_is_stopping(c)) {
        c->stopCount++;
        if (c->kind == CK_EVENT && c->locked) c->stopCount = 0;
        if (c->forcing) update_routine_move(c);
        else if (c->kind == CK_EVENT) event_self_move(c);
    }
    if (jumping(c)) {
        c->jumpCount--;
        c->rx = (c->rx * c->jumpCount + c->x) / (c->jumpCount + 1.0f);
        c->ry = (c->ry * c->jumpCount + c->y) / (c->jumpCount + 1.0f);
        if (c->jumpCount == 0) { c->rx = (float)c->x; c->ry = (float)c->y; }
    } else if (char_is_moving(c)) {
        float d = dist_per_frame(c);
        if (c->x < c->rx) c->rx = fmaxf(c->rx - d, (float)c->x);
        if (c->x > c->rx) c->rx = fminf(c->rx + d, (float)c->x);
        if (c->y < c->ry) c->ry = fmaxf(c->ry - d, (float)c->y);
        if (c->y > c->ry) c->ry = fminf(c->ry + d, (float)c->y);
    }
    update_animation(c);
    if (c->balloonCount > 0) { c->balloonCount--; if (c->balloonCount == 0) c->balloon = 0; }
}

void char_show_balloon(Char *c, int id) { c->balloon = id; c->balloonCount = 8 * 8 + 12; }

void map_update_events(void)
{
    if (g_needs_refresh) map_refresh_events();
    for (int i = 0; i < g_nevs; i++) {
        Char *c = &evs[i];
        if (c->pageIdx < 0 && c->erased) continue;
        char_update(c);
        if (c->trigger == 3) char_event_start(c);   /* autorun */
    }
}

bool map_setup_starting_event(void)
{
    if (g_needs_refresh) map_refresh_events();
    for (int i = 0; i < g_nevs; i++) {
        Char *c = &evs[i];
        if (c->starting && c->page) {
            c->starting = 0;
            interp_setup(&g_interp, c->page->cmd, c->page->ncmd, c->id);
            return true;
        }
    }
    for (int i = 1; i < db.ncommon; i++) {
        CommonEventDef *ce = &db.common[i];
        if (ce->exists && ce->trigger == 1 && ce->ncmd > 3 && sw_get(ce->switchId)) {
            interp_setup(&g_interp, ce->cmd, ce->ncmd, 0);
            return true;
        }
    }
    return false;
}

/* ----------------------------------------------------------------------------- player */
static int s_xfer_map = -1, s_xfer_x, s_xfer_y, s_xfer_dir, s_xfer_fade;
void player_reserve_transfer(int map, int x, int y, int dir, int fade)
{
    s_xfer_map = map; s_xfer_x = x; s_xfer_y = y; s_xfer_dir = dir; s_xfer_fade = fade;
}
bool player_transfer_pending(void) { return s_xfer_map >= 0; }
int player_transfer_fade(void) { return s_xfer_fade; }

bool player_perform_transfer(void)
{
    if (s_xfer_map < 0) return false;
    int mp = s_xfer_map; s_xfer_map = -1;
    if (mp != M.id || !M.raw) {
        if (!map_load(mp)) return false;
        g.mapId = mp;
        if (M.bgm >= 0) audio_bgm(M.bgm, M.bgmVol);     /* maps without autoplay keep the current music */
        pics_clear();
    }
    player.route = player.oroute = NULL; player.nroute = player.noroute = 0; player.forcing = 0; player.hasOrig = 0;
    for (int i = 0; i < MAX_PARTY - 1; i++) { followers[i].route = followers[i].oroute = NULL; followers[i].forcing = 0; followers[i].hasOrig = 0; }
    char_locate(&player, s_xfer_x, s_xfer_y);
    if (s_xfer_dir) player.dir = s_xfer_dir;
    g.mapId = mp; g.px = s_xfer_x; g.py = s_xfer_y;
    game_refresh_followers();
    for (int i = 0; i < MAX_PARTY - 1; i++) { char_locate(&followers[i], s_xfer_x, s_xfer_y); followers[i].dir = player.dir; }
    map_refresh_events();
    map_center_on_player();
    return true;
}

bool player_can_move(void)
{
    if (g_interp.running || msg_busy() || scrolltext.active) return false;
    if (player.forcing) return false;
    if (player_transfer_pending() || g_fade_target != g_fade) return false;
    return true;
}

static void follower_chase(Char *f, const Char *pre)
{
    int sx = f->x - pre->x, sy = f->y - pre->y;
    if (sx != 0 && sy != 0) char_move_diag(f, sx > 0 ? 4 : 6, sy > 0 ? 8 : 2);
    else if (sx != 0) char_move_straight(f, sx > 0 ? 4 : 6);
    else if (sy != 0) char_move_straight(f, sy > 0 ? 8 : 2);
    f->moveSpeed = player.moveSpeed; f->dashing = player.dashing;
}
static void follower_chase_all(void)
{
    if (!followers_visible()) return;
    for (int i = g.nparty - 2; i >= 0; i--) {
        if (i >= MAX_PARTY - 1) continue;
        follower_chase(&followers[i], i > 0 ? &followers[i - 1] : &player);
    }
}

void game_refresh_followers(void)
{
    Battler *lead = party_member(0);
    if (lead) { player.sheet = db.actors[lead->id].charId; player.index = db.actors[lead->id].charIdx; }
    for (int i = 0; i < MAX_PARTY - 1; i++) {
        Char *f = &followers[i];
        if (!f->used) { char_init(f); f->kind = CK_FOLLOWER; f->used = 1; f->through = 1; f->x = player.x; f->y = player.y; f->rx = f->x; f->ry = f->y; }
        Battler *b = party_member(i + 1);
        if (b) { f->sheet = db.actors[b->id].charId; f->index = db.actors[b->id].charIdx; }
        else f->sheet = -1;
    }
}

void player_start_new(void)
{
    char_init(&player); player.kind = CK_PLAYER; player.used = 1; player.id = -1; player.moveSpeed = 4;
    for (int i = 0; i < MAX_PARTY - 1; i++) memset(&followers[i], 0, sizeof followers[i]);
}

static int input_dir4(void)
{
    static int last_axis;   /* 0 vertical, 1 horizontal */
    uint32_t h = g_in.held, d = g_in.down;
    if (d & (K_LEFT | K_RIGHT)) last_axis = 1;
    if (d & (K_UP | K_DOWN)) last_axis = 0;
    int horz = (h & K_LEFT) ? 4 : ((h & K_RIGHT) ? 6 : 0);
    int vert = (h & K_UP) ? 8 : ((h & K_DOWN) ? 2 : 0);
    if (horz && vert) return last_axis ? horz : vert;
    return horz ? horz : vert;
}

static bool any_event_starting(void)
{
    for (int i = 0; i < g_nevs; i++) if (evs[i].starting && evs[i].page) return true;
    return false;
}

static void player_start_map_event(int x, int y, int mask, bool normal)
{
    if (g_interp.running) return;
    for (int i = 0; i < g_nevs; i++) {
        Char *e = &evs[i];
        if (e->x == x && e->y == y && char_is_trigger_in(e, mask) && is_normal_priority(e) == normal) char_event_start(e);
    }
}
static void check_here(int mask) { player_start_map_event(player.x, player.y, mask, false); }
static void check_there(int mask)
{
    int x2 = map_xwd(player.x, player.dir), y2 = map_ywd(player.y, player.dir);
    player_start_map_event(x2, y2, mask, true);
    if (!any_event_starting() && map_counter(x2, y2))
        player_start_map_event(map_xwd(x2, player.dir), map_ywd(y2, player.dir), mask, true);
}

void player_update(bool active)
{
    bool was_moving = char_is_moving(&player);
    bool can = player_can_move();
    /* dashing */
    if (!char_is_moving(&player)) {
        player.dashing = (can && !M.noDash && (g_in.held & K_Y)) ? 1 : 0;
    }
    /* input */
    if (active && !char_is_moving(&player) && !jumping(&player) && can) {
        int d = input_dir4();
        if (d) char_move_straight(&player, d);
    }
    char_update(&player);
    if (!char_is_moving(&player) && !jumping(&player)) {
        if (!g_interp.running) {
            if (was_moving) {
                check_here(6);
                if (map_setup_starting_event()) goto after_trigger;
            }
            if (active && can && (g_in.down & K_A)) {
                check_here(1);
                if (map_setup_starting_event()) goto after_trigger;
                check_there(7);
                if (map_setup_starting_event()) goto after_trigger;
            }
        }
    }
after_trigger:
    if (followers_visible())
        for (int i = 0; i < g.nparty - 1 && i < MAX_PARTY - 1; i++) char_update(&followers[i]);
    g.px = player.x; g.py = player.y; g.pdir = player.dir;
}

/* ----------------------------------------------------------------------------- camera */
static float clamp_axis(float v, int mapSize, float viewSize)
{
    if (mapSize >= viewSize) { if (v < 0) v = 0; if (v > mapSize - viewSize) v = mapSize - viewSize; return v; }
    return (mapSize - viewSize) / 2.0f;
}
void map_update_scroll(void)
{
    g_disp_x = clamp_axis(player.rx - (VIEW_TW - 1) / 2.0f, M.w, VIEW_TW);
    g_disp_y = clamp_axis(player.ry - (VIEW_TH - 1) / 2.0f, M.h, VIEW_TH);
}
void map_center_on_player(void) { map_update_scroll(); }
void map_setup_scroll(void) { map_update_scroll(); }

int char_screen_x(const Char *c) { return (int)floorf((c->rx - g_disp_x) * TILE + TILE / 2); }
int char_screen_y(const Char *c)
{
    float jh = 0;
    if (c->jumpCount > 0) { float d = fabsf((float)(c->jumpCount - c->jumpPeak)); jh = ((float)c->jumpPeak * c->jumpPeak - d * d) / 2.0f / 2.0f; }
    int shift = 3;
    if (c->sheet >= 0 && c->sheet < db.nchars && (db.chars[c->sheet].flags & 2)) shift = 0;
    return (int)floorf((c->ry - g_disp_y) * TILE + TILE - shift - jh);
}
