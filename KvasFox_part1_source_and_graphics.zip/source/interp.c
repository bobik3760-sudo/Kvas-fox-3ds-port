/* interp.c - event command interpreter (port of Game_Interpreter), message/choice logic, pictures, fade. */
#include "game.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

Interp g_interp, g_binterp;
Msg msg;
ScrollText scrolltext;
Pic pics[MAX_PIC];
int g_fade, g_fade_target, g_fade_speed = 11, g_fade_white;
ShopGoods g_shop;
int g_battle_request, g_battle_can_escape, g_battle_can_lose, g_battle_result = -1;
int g_shop_request, g_scene_request = -1;

#define MSG_TEXT_SCALE 0.5f
#define MSG_W 392
#define MSG_LINES 4

void fmt_msg(char *out, int cap, const char *fmt, ...)
{
    va_list ap; va_start(ap, fmt); vsnprintf(out, cap, fmt, ap); va_end(ap);
}

/* ----------------------------------------------------------------------------- switches & variables */
bool sw_get(int id) { return id > 0 && id < SW_MAX && g.sw[id]; }
void sw_set(int id, bool v) { if (id > 0 && id < SW_MAX && g.sw[id] != (uint8_t)v) { g.sw[id] = v; g_needs_refresh = 1; } }
int var_get(int id) { return id > 0 && id < VAR_MAX ? g.var[id] : 0; }
void var_set(int id, int v) { if (id > 0 && id < VAR_MAX && g.var[id] != v) { g.var[id] = v; g_needs_refresh = 1; } }
bool ss_get(int map, int ev, int ch)
{
    for (int i = 0; i < g.nss; i++) if (g.ss[i].map == map && g.ss[i].ev == ev && g.ss[i].ch == ch) return true;
    return false;
}
void ss_set(int map, int ev, int ch, bool v)
{
    for (int i = 0; i < g.nss; i++) if (g.ss[i].map == map && g.ss[i].ev == ev && g.ss[i].ch == ch) {
        if (!v) { g.ss[i] = g.ss[--g.nss]; g_needs_refresh = 1; }
        return;
    }
    if (v && g.nss < SS_MAX) { g.ss[g.nss].map = map; g.ss[g.nss].ev = ev; g.ss[g.nss].ch = ch; g.nss++; g_needs_refresh = 1; }
}

/* ----------------------------------------------------------------------------- message window */
bool msg_busy(void) { return msg.active || scrolltext.active; }
bool msg_choices_ready(void)
{
    if (!msg.active || !msg.hasChoices) return false;
    int pages = (msg.nlines + MSG_LINES - 1) / MSG_LINES;
    if (msg.page + 1 < pages) return false;
    int total = 0;
    for (int i = 0; i < msg.pageLines; i++) total += (int)strlen(msg.lines[msg.pageStart + i]) + 1;
    return msg.shown >= total;
}

void msg_expand(const char *src, char *dst, int cap)
{
    int o = 0;
    for (const char *p = src; *p && o < cap - 8; p++) {
        if (*p != '\\') { dst[o++] = *p; continue; }
        p++;
        if (!*p) break;
        if (*p == 'G' || *p == 'g') { const char *c = tx(db.currency); while (*c && o < cap - 2) dst[o++] = *c++; }
        else if (*p == 'N' || *p == 'n') {
            int n = 0; if (p[1] == '[') { p += 2; while (*p >= '0' && *p <= '9') n = n * 10 + (*p++ - '0'); }
            Battler *b = actor_get(n); const char *s = b ? b_name(b) : "";
            while (*s && o < cap - 2) dst[o++] = *s++;
        } else if (*p == 'V' || *p == 'v') {
            int n = 0; if (p[1] == '[') { p += 2; while (*p >= '0' && *p <= '9') n = n * 10 + (*p++ - '0'); }
            o += snprintf(dst + o, cap - o, "%d", var_get(n));
        } else if (*p == 'C' || *p == 'c' || *p == 'I' || *p == 'i') { if (p[1] == '[') { p += 2; while (*p && *p != ']') p++; } }
        else if (*p == '\\') dst[o++] = '\\';
        /* other codes (\. \| \! \{ \}) are ignored */
    }
    dst[o] = 0;
}

static float text_area_w(void) { return MSG_W - 16 - (msg.face >= 0 ? 76 : 0); }

static void layout_text(const char *text)
{
    msg.nlines = 0;
    char line[200]; line[0] = 0;
    const char *p = text;
    float maxw = text_area_w();
    while (*p && msg.nlines < 24) {
        /* take next word */
        char word[200]; int wl = 0;
        while (*p == ' ') { if (wl < 190) word[wl++] = *p; p++; if (wl >= 1) break; }
        while (*p && *p != ' ' && *p != '\n' && wl < 190) word[wl++] = *p++;
        word[wl] = 0;
        bool nl = (*p == '\n'); if (nl) p++;
        if (wl > 0) {
            char trial[400]; snprintf(trial, sizeof trial, "%s%s", line, word);
            if (plat_text_w(trial, MSG_TEXT_SCALE) <= maxw || line[0] == 0) {
                if (line[0] == 0 && plat_text_w(word, MSG_TEXT_SCALE) > maxw) {
                    /* a single over-long word: split by characters */
                    char cur[200]; cur[0] = 0; int cl = 0; const char *q = word;
                    while (*q) {
                        int clen = 1; while ((q[clen] & 0xC0) == 0x80) clen++;
                        char t2[220]; memcpy(t2, cur, cl); memcpy(t2 + cl, q, clen); t2[cl + clen] = 0;
                        if (plat_text_w(t2, MSG_TEXT_SCALE) > maxw && cl > 0) {
                            snprintf(msg.lines[msg.nlines++], 200, "%s", cur); cur[0] = 0; cl = 0;
                            if (msg.nlines >= 24) break;
                        }
                        memcpy(cur + cl, q, clen); cl += clen; cur[cl] = 0; q += clen;
                    }
                    snprintf(line, sizeof line, "%s", cur);
                } else snprintf(line, sizeof line, "%s", trial);
            } else {
                snprintf(msg.lines[msg.nlines++], 200, "%s", line);
                const char *w = word; while (*w == ' ') w++;
                snprintf(line, sizeof line, "%s", w);
            }
        }
        if (nl) { snprintf(msg.lines[msg.nlines++], 200, "%s", line); line[0] = 0; }
    }
    if (line[0] && msg.nlines < 24) snprintf(msg.lines[msg.nlines++], 200, "%s", line);
}

void msg_relayout(void)
{
    if (!msg.active || msg.textStr < 0) return;
    char buf[1100];
    msg_expand(tx(msg.textStr), buf, sizeof buf);
    layout_text(buf);
    int pageCount = (msg.nlines + MSG_LINES - 1) / MSG_LINES;
    if (msg.page >= pageCount && pageCount > 0) msg.page = pageCount - 1;
    msg.pageStart = msg.page * MSG_LINES;
    msg.pageLines = msg.nlines - msg.pageStart; if (msg.pageLines > MSG_LINES) msg.pageLines = MSG_LINES;
    msg.shown = 0x7fffffff;      /* after a language switch show everything at once */
}

void msg_start_text(int face, int faceIdx, int bg, int pos, int nameStr, int textStr)
{
    memset(&msg, 0, sizeof msg);
    msg.active = 1; msg.face = face; msg.faceIdx = faceIdx; msg.bg = bg; msg.pos = pos; msg.nameStr = nameStr;
    msg.textStr = textStr; msg.choiceResult = -1;
    char buf[1100]; msg_expand(tx(textStr), buf, sizeof buf);
    layout_text(buf);
    msg.page = 0; msg.pageStart = 0;
    msg.pageLines = msg.nlines > MSG_LINES ? MSG_LINES : msg.nlines;
    msg.shown = 0;
}

static int page_bytes(void)
{
    int n = 0;
    for (int i = 0; i < msg.pageLines; i++) n += (int)strlen(msg.lines[msg.pageStart + i]) + 1;
    return n;
}

void msg_update(void)
{
    if (!msg.active) return;
    int total = page_bytes();
    if (msg.shown < total) {
        if (g_in.down & (K_A | K_B) || g_in.touch_down) msg.shown = total;
        else msg.shown += 2;
        if (msg.shown >= total) msg.shown = total;
        return;
    }
    int pages = (msg.nlines + MSG_LINES - 1) / MSG_LINES;
    bool more = msg.page + 1 < pages;
    if (more) {
        if (g_in.down & (K_A | K_B) || g_in.touch_down) {
            msg.page++; msg.pageStart = msg.page * MSG_LINES;
            msg.pageLines = msg.nlines - msg.pageStart; if (msg.pageLines > MSG_LINES) msg.pageLines = MSG_LINES;
            msg.shown = 0; audio_sys(SND_CURSOR);
        }
        return;
    }
    if (msg.hasChoices) {
        ui_choice_update();               /* sets choiceDone */
        if (msg.choiceDone) msg.active = 0;
        return;
    }
    if (g_in.down & (K_A | K_B) || g_in.touch_down) msg.active = 0;
}

/* ----------------------------------------------------------------------------- pictures / fade */
void pics_clear(void)
{
    for (int i = 0; i < MAX_PIC; i++) { if (pics[i].tex) plat_tex_free(pics[i].tex); memset(&pics[i], 0, sizeof pics[i]); }
}
void fade_update(void)
{
    if (g_fade < g_fade_target) { g_fade += g_fade_speed; if (g_fade > g_fade_target) g_fade = g_fade_target; }
    else if (g_fade > g_fade_target) { g_fade -= g_fade_speed; if (g_fade < g_fade_target) g_fade = g_fade_target; }
}

void interp_update_scroll(void)
{
    if (!scrolltext.active) return;
    float sp = scrolltext.speed * 0.3f;
    if (!scrolltext.noFast && (g_in.held & K_A)) sp *= 3;
    scrolltext.y -= sp;
    if (scrolltext.y + scrolltext.nlines * 14 < 0) scrolltext.active = 0;
}

/* ----------------------------------------------------------------------------- interpreter */
void interp_setup(Interp *it, const int32_t *list, int n, int eventId)
{
    memset(it, 0, sizeof *it);
    it->running = 1; it->list = list; it->n = n; it->eventId = eventId;
}

static int next_pc(const Interp *it, int pc) { return pc + 3 + it->list[pc + 2]; }

static void skip_branch(Interp *it)
{
    for (;;) {
        int nx = next_pc(it, it->pc);
        if (nx >= it->n) break;
        if (it->list[nx + 1] > it->indent) it->pc = nx; else break;
    }
}

static Char *resolve(const Interp *it, int charId)
{
    if (charId < 0) return &player;
    if (charId == 0) return it->isBattle ? NULL : map_event(it->eventId);
    return map_event(charId);
}

static int operand(int type, int v) { return type == 0 ? v : var_get(v); }

static void finish(Interp *it)
{
    it->running = 0;
    if (!it->isBattle && it->eventId > 0) map_unlock_event(it->eventId);
}

static bool still_waiting(Interp *it)
{
    switch (it->waitMode) {
        case WM_NONE: return false;
        case WM_MESSAGE:
            if (msg_busy()) return true;
            if (it->waitArg >= 0 && msg.hasChoices) it->branch[it->waitArg] = msg.choiceResult;
            break;
        case WM_MOVE: { Char *c = resolve(it, it->waitArg); if (c && c->forcing) return true; break; }
        case WM_FADE: if (g_fade != g_fade_target) return true; break;
        case WM_BATTLE:
            if (g_battle_result < 0) return true;
            it->branch[it->waitArg] = g_battle_result;
            break;
        case WM_SHOP: if (ui_shop_active()) return true; break;
        case WM_TRANSFER: if (player_transfer_pending() || g_fade != g_fade_target) return true; break;
        case WM_SCROLL: if (scrolltext.active) return true; break;
        case WM_BALLOON: { Char *c = resolve(it, it->waitArg); if (c && c->balloonCount > 0) return true; break; }
        case WM_SAVE: if (ui_save_active()) return true; break;
        default: break;
    }
    it->waitMode = WM_NONE;
    return false;
}

static bool eval_condition(Interp *it, const int32_t *p)
{
    switch (p[0]) {
        case 0: return sw_get(p[1]) == (p[2] == 0);
        case 1: {
            int lhs = var_get(p[1]), rhs = operand(p[2], p[3]);
            switch (p[4]) { case 0: return lhs == rhs; case 1: return lhs >= rhs; case 2: return lhs <= rhs;
                            case 3: return lhs > rhs; case 4: return lhs < rhs; default: return lhs != rhs; }
        }
        case 2: return it->eventId > 0 && ss_get(M.id, it->eventId, p[1]) == (p[2] == 0);
        case 4: return party_has(p[1]);
        case 7: return p[2] == 0 ? g.gold >= p[1] : (p[2] == 1 ? g.gold <= p[1] : g.gold < p[1]);
        case 8: return item_count(0, p[1]) > 0;
        case 9: return item_count(1, p[1]) > 0;
        case 10: return item_count(2, p[1]) > 0;
        default: return false;
    }
}

static void iter_actors(int type, int id, void (*fn)(Battler *, int), int arg)
{
    if (type == 1) id = var_get(id);
    if (id == 0) { for (int i = 0; i < g.nparty; i++) { Battler *b = party_member(i); if (b) fn(b, arg); } }
    else { Battler *b = actor_get(id); if (b) fn(b, arg); }
}
static void fn_hp(Battler *b, int v) { b_gain_hp(b, v); }
static void fn_hp_nodeath(Battler *b, int v) { int nv = b->hp + v; if (nv < 1) nv = 1; b_gain_hp(b, nv - b->hp); }
static void fn_recover(Battler *b, int v) { (void)v; b_recover_all(b); }

static void exec(Interp *it, int code, int indent, int np, const int32_t *p)
{
    (void)np;
    switch (code) {
        case 0: case 118: case 112: case 404: case 412: case 604: break;
        case 101: {
            msg_start_text(p[0], p[1], p[2], p[3], p[4], p[5]);
            it->waitArg = -1;
            int nx = next_pc(it, it->pc);
            if (nx < it->n && it->list[nx] == 102) {
                const int32_t *q = &it->list[nx + 3];
                msg.cancelType = q[0]; msg.defaultType = q[1]; msg.nchoices = q[4] > 8 ? 8 : q[4]; msg.hasChoices = 1;
                for (int i = 0; i < msg.nchoices; i++) msg.choiceStr[i] = q[5 + i];
                it->waitArg = it->list[nx + 1];
                it->pc = nx;                      /* consume the 102 */
            }
            it->waitMode = WM_MESSAGE;
            break;
        }
        case 102: {
            memset(&msg, 0, sizeof msg);
            msg.active = 1; msg.face = -1; msg.textStr = -1; msg.choiceResult = -1;
            msg.cancelType = p[0]; msg.defaultType = p[1]; msg.nchoices = p[4] > 8 ? 8 : p[4]; msg.hasChoices = 1;
            for (int i = 0; i < msg.nchoices; i++) msg.choiceStr[i] = p[5 + i];
            msg.shown = 0;
            it->waitArg = indent; it->waitMode = WM_MESSAGE;
            break;
        }
        case 402: if (it->branch[indent] != p[0]) skip_branch(it); break;
        case 403: if (it->branch[indent] >= 0) skip_branch(it); break;
        case 105: {
            memset(&scrolltext, 0, sizeof scrolltext);
            scrolltext.speed = p[0]; scrolltext.noFast = p[1];
            int pc = next_pc(it, it->pc);
            while (pc < it->n && it->list[pc] == 405 && scrolltext.nlines < 200) {
                scrolltext.str[scrolltext.nlines++] = it->list[pc + 3];
                it->pc = pc; pc = next_pc(it, pc);
            }
            scrolltext.y = SCR_H; scrolltext.active = 1;
            it->waitMode = WM_SCROLL;
            break;
        }
        case 405: break;
        case 111: {
            bool r = eval_condition(it, p);
            it->branch[indent] = r;
            if (!r) skip_branch(it);
            break;
        }
        case 411: if (it->branch[indent] != 0) skip_branch(it); break;
        case 413: {
            int cur = 0, start = 0;
            while (cur < it->pc) { if (it->list[cur] == 112 && it->list[cur + 1] == indent) start = cur; cur = next_pc(it, cur); }
            it->pc = start;
            break;
        }
        case 113: {
            int depth = 0;
            for (;;) {
                int nx = next_pc(it, it->pc);
                if (nx >= it->n) break;
                it->pc = nx;
                if (it->list[nx] == 112) depth++;
                if (it->list[nx] == 413) { if (depth > 0) depth--; else break; }
            }
            break;
        }
        case 115: it->pc = it->n; return;
        case 117: {
            if (p[0] > 0 && p[0] < db.ncommon && db.common[p[0]].exists && it->sp < 4) {
                it->stack[it->sp].list = it->list; it->stack[it->sp].n = it->n;
                it->stack[it->sp].pc = next_pc(it, it->pc); it->stack[it->sp].indent = it->indent; it->stack[it->sp].eventId = it->eventId;
                it->sp++;
                it->list = db.common[p[0]].cmd; it->n = db.common[p[0]].ncmd; it->pc = 0; it->indent = 0;
                memset(it->branch, 0, sizeof it->branch);
                it->pc = -1000000;               /* marker: pc is already set, do not advance */
            }
            break;
        }
        case 119: {
            for (int cur = 0; cur < it->n; cur = next_pc(it, cur))
                if (it->list[cur] == 118 && it->list[cur + 3] == p[0]) { it->pc = cur; break; }
            break;
        }
        case 121: for (int i = p[0]; i <= p[1]; i++) sw_set(i, p[2] == 0); break;
        case 122: {
            int val = 0;
            switch (p[3]) { case 0: val = p[4]; break; case 1: val = var_get(p[4]); break;
                            case 2: val = p[4] + rnd(p[5] - p[4] + 1); break; default: val = 0; }
            for (int i = p[0]; i <= p[1]; i++) {
                int cur = var_get(i);
                switch (p[2]) { case 0: cur = val; break; case 1: cur += val; break; case 2: cur -= val; break; case 3: cur *= val; break;
                                case 4: if (val) cur /= val; break; case 5: if (val) cur %= val; break; }
                var_set(i, cur);
            }
            break;
        }
        case 123: if (it->eventId > 0) ss_set(M.id, it->eventId, p[0], p[1] == 0); break;
        case 125: { int v = operand(p[1], p[2]); g.gold = clampi(g.gold + (p[0] ? -v : v), 0, 99999999); break; }
        case 126: case 127: case 128: {
            int v = operand(p[2], p[3]); item_gain(code - 126, p[0], p[1] ? -v : v); break;
        }
        case 129: if (p[1] == 0) party_add(p[0]); else party_remove(p[0]); break;
        case 201: {
            int mp = p[1], x = p[2], y = p[3];
            if (p[0] == 1) { mp = var_get(p[1]); x = var_get(p[2]); y = var_get(p[3]); }
            player_reserve_transfer(mp, x, y, p[4], p[5]);
            if (p[5] != 2) { g_fade_target = 255; g_fade_white = (p[5] == 1); }
            it->waitMode = WM_TRANSFER;
            break;
        }
        case 203: {
            Char *c = resolve(it, p[0]);
            int x = p[2], y = p[3];
            if (p[1] == 1) { x = var_get(p[2]); y = var_get(p[3]); }
            if (c) {
                if (p[1] == 2) {                      /* exchange with another event */
                    Char *o = resolve(it, p[2]);
                    if (o) { int ox = o->x, oy = o->y; char_locate(o, c->x, c->y); char_locate(c, ox, oy); }
                } else char_locate(c, x, y);
                if (p[4]) char_set_dir(c, p[4]);
                if (c->kind == CK_PLAYER) for (int i = 0; i < MAX_PARTY - 1; i++) { char_locate(&followers[i], x, y); followers[i].dir = c->dir; }
            }
            break;
        }
        case 205: {
            Char *c = resolve(it, p[0]);
            if (c) {
                char_force_route(c, p + 5, p[4], p[1], p[2]);
                if (p[3]) { it->waitMode = WM_MOVE; it->waitArg = (p[0] == 0) ? it->eventId : p[0]; }
            }
            break;
        }
        case 211: player.transparent = p[0] == 0; break;
        case 213: {
            Char *c = resolve(it, p[0]);
            if (c) { char_show_balloon(c, p[1]); if (p[2]) { it->waitMode = WM_BALLOON; it->waitArg = (p[0] == 0) ? it->eventId : p[0]; } }
            break;
        }
        case 214: if (it->eventId > 0) map_erase_event(it->eventId); break;
        case 221: g_fade_target = 255; g_fade_white = 0; it->waitMode = WM_FADE; break;
        case 222: g_fade_target = 0; it->waitMode = WM_FADE; break;
        case 230: it->waitCount = p[0]; break;
        case 231: {
            int id = clampi(p[0], 1, MAX_PIC - 1);
            Pic *pc = &pics[id];
            if (pc->tex) plat_tex_free(pc->tex);
            memset(pc, 0, sizeof *pc);
            char n[16]; snprintf(n, sizeof n, "p%02d", p[1]);
            pc->tex = plat_tex_load(n); pc->used = pc->tex != NULL; pc->pic = p[1];
            pc->origin = p[2];
            pc->x = p[3] == 0 ? p[4] : var_get(p[4]); pc->y = p[3] == 0 ? p[5] : var_get(p[5]);
            pc->sx = p[6]; pc->sy = p[7]; pc->opacity = p[8];
            break;
        }
        case 235: { int id = clampi(p[0], 1, MAX_PIC - 1); if (pics[id].tex) plat_tex_free(pics[id].tex); memset(&pics[id], 0, sizeof pics[id]); break; }
        case 241: audio_bgm(p[0], p[1]); break;
        case 242: audio_bgm_fade(p[0] * 60); break;
        case 249: audio_me(p[0], p[1]); break;
        case 250: audio_se(p[0], p[1], p[2]); break;
        case 301: {
            int troop = p[0] == 0 ? p[1] : (p[0] == 1 ? var_get(p[1]) : p[1]);
            g_battle_request = troop; g_battle_can_escape = p[2]; g_battle_can_lose = p[3]; g_battle_result = -1;
            it->waitMode = WM_BATTLE; it->waitArg = indent;
            break;
        }
        case 601: if (it->branch[indent] != 0) skip_branch(it); break;
        case 602: if (it->branch[indent] != 1) skip_branch(it); break;
        case 603: if (it->branch[indent] != 2) skip_branch(it); break;
        case 302: {
            memset(&g_shop, 0, sizeof g_shop);
            g_shop.purchaseOnly = p[0]; g_shop.n = p[1] > 40 ? 40 : p[1];
            for (int i = 0; i < g_shop.n; i++) { g_shop.kind[i] = p[2 + i * 3]; g_shop.id[i] = p[3 + i * 3]; g_shop.price[i] = p[4 + i * 3]; }
            g_shop_request = 1; ui_shop_begin();
            it->waitMode = WM_SHOP;
            break;
        }
        case 311: {
            int v = operand(p[3], p[4]); if (p[2]) v = -v;
            iter_actors(p[0], p[1], p[5] ? fn_hp : fn_hp_nodeath, v);
            break;
        }
        case 314: iter_actors(p[0], p[1], fn_recover, 0); break;
        case 333: battle_cmd_enemy_state(p[0], p[1], p[2]); break;
        case 335: battle_cmd_enemy_appear(p[0]); break;
        case 352: ui_save_begin(); it->waitMode = WM_SAVE; break;
        case 353: g_scene_request = SC_GAMEOVER; it->pc = it->n; return;
        case 354: g_scene_request = SC_TITLE; it->pc = it->n; return;
        default: break;                           /* unsupported command: ignored */
    }
}

void interp_update(Interp *it)
{
    int guard = 0;
    for (;;) {
        if (!it->running) return;
        if (still_waiting(it)) return;
        if (it->waitCount > 0) { it->waitCount--; return; }
        if (it->pc >= it->n) {
            if (it->sp > 0) {
                it->sp--;
                it->list = it->stack[it->sp].list; it->n = it->stack[it->sp].n; it->pc = it->stack[it->sp].pc;
                it->indent = it->stack[it->sp].indent; it->eventId = it->stack[it->sp].eventId;
                continue;
            }
            finish(it);
            return;
        }
        const int32_t *c = &it->list[it->pc];
        int code = c[0], indent = c[1], np = c[2];
        it->indent = indent;
        int before = it->pc;
        exec(it, code, indent, np, c + 3);
        if (code == 117 && it->pc == -1000000) it->pc = 0;           /* entered a common event */
        else if (it->pc == it->n && (code == 115 || code == 353 || code == 354)) { /* exit */ }
        else it->pc = next_pc(it, it->pc);
        (void)before;
        if (++guard > 20000) return;
    }
}
