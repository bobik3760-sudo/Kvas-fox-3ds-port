/* game.h - runtime types and cross-module API of the Kvas Fox engine */
#ifndef GAME_H
#define GAME_H

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "platform.h"
#include "data.h"

#define TILE 24
#define SW_MAX 1024
#define VAR_MAX 1024
#define SS_MAX 1024
#define ACTOR_MAX 16
#define MAX_EV 160
#define MAX_PIC 20
#define MAX_PARTY 4
#define MAX_SHEETS 32
#define NSLOTS 3

/* ----------------------------------------------------------------------------- map data */
typedef struct {
    int cf, sw1, sw2, varId, varVal, selfCh, itemId, actorId;
    int imgKind, sheet, idx, dir, pat;
    int moveType, speed, freq, rep, skip, nroute;
    const int32_t *route;
    int opt, prio, trig, ncmd;
    const int32_t *cmd;
} EvPage;

typedef struct { int id, x, y, npages; EvPage *pages; } EvDef;

typedef struct {
    int id, w, h;
    uint8_t *raw;
    const uint16_t *lower, *upper;
    const uint8_t *pass;
    int bgm, bgmVol, bgs, displayName, noDash, overworld;
    int natlas;
    struct { int w, h, cols, cap; PTex *tex; } atlas[8];
    int nev; EvDef *evs;
} MapData;

/* ----------------------------------------------------------------------------- characters */
enum { CK_EVENT, CK_PLAYER, CK_FOLLOWER };

typedef struct Char {
    int used, kind, id;
    int x, y; float rx, ry;
    int dir, pattern; float animCount; int stopCount;
    int sheet, index;
    int through, transparent, dirFix, walkAnime, stepAnime, priority;
    int moveSpeed, moveFreq, moveType;
    int success;
    const int32_t *route; int nroute, routeIdx, routeRepeat, routeSkippable, forcing, waitCount;
    const int32_t *oroute; int noroute, oRouteIdx, oRepeat, oSkip;   /* saved original route while forcing */
    int hasOrig;
    int jumpCount, jumpPeak, blockedFrames;
    int locked, starting, prelockDir;
    int erased, pageIdx;
    const EvPage *page; const EvDef *def;
    int trigger;
    int balloon, balloonCount;
    int dashing, opacity;
} Char;

/* ----------------------------------------------------------------------------- battlers */
typedef struct { int kind; int id; int target; } BAction;      /* kind: 0 none 1 attack 2 guard 3 skill 4 item */

typedef struct {
    int isActor, id, valid;
    int hp, mp, tp, level, exp;
    int plus[8], equips[5];
    uint8_t learned[MAX_DB];
    int buff[8], buffTurns[8];
    uint8_t state[MAX_STATES]; int stateTurns[MAX_STATES];
    /* battle only */
    int hidden, speed, x, y, collapse, flash;
    BAction act;
    int popup, popupTimer, popupKind, popupCrit;
    int lastTarget;
} Battler;

/* ----------------------------------------------------------------------------- game state (saved) */
typedef struct {
    uint8_t sw[SW_MAX];
    int var[VAR_MAX];
    struct { int map, ev, ch; } ss[SS_MAX]; int nss;
    int gold;
    int items[MAX_DB], weapons[MAX_DB], armors[MAX_DB];
    Battler actors[ACTOR_MAX];
    int party[MAX_PARTY], nparty;
    int mapId, px, py, pdir;
    uint32_t playtime;           /* frames */
    int steps;
    int menuDisabled, saveDisabled;
} GameState;

extern GameState g;
extern MapData M;               /* current map */
extern Char evs[MAX_EV];        /* events of the current map */
extern Char player, followers[MAX_PARTY - 1];
extern int g_nevs;
extern int g_needs_refresh;
extern float g_disp_x, g_disp_y; /* camera, in tiles */
extern PInput g_in;
extern uint32_t g_frame;

/* ----------------------------------------------------------------------------- util */
int rnd(int n);                          /* 0 .. n-1 */
float rndf(void);
void rng_seed(uint32_t s);
int clampi(int v, int lo, int hi);
void utf8_trim_to(char *s, int nbytes);  /* cut at a UTF-8 boundary */

/* ----------------------------------------------------------------------------- audio.c */
void audio_init(void);
void audio_update(void);
void audio_bgm(int id, int vol);
void audio_bgm_stop(void);
void audio_bgm_fade(int frames);
void audio_me(int id, int vol);
void audio_se(int id, int vol, int pitch);
void audio_sys(int sysId);
int audio_cur_bgm(void);
void audio_bgm_save(void);
void audio_bgm_resume(void);

/* ----------------------------------------------------------------------------- battlers (battler.c) */
void battler_init_actor(Battler *b, int actorId);
void battler_init_enemy(Battler *b, int enemyId);
int  b_param(const Battler *b, int p);          /* 0 mhp 1 mmp 2 atk 3 def 4 mat 5 mdf 6 agi 7 luk */
float b_xparam(const Battler *b, int id);       /* hit eva cri cev mev mrf cnt hrg mrg trg */
float b_sparam(const Battler *b, int id);       /* tgr grd rec pha mcr tcr pdr mdr fdr exr */
int  b_trait_sum(const Battler *b, int code, int id);
float b_trait_pi(const Battler *b, int code, int id);
bool b_trait_has(const Battler *b, int code, int id);
bool b_alive(const Battler *b);
bool b_dead(const Battler *b);
bool b_can_move(const Battler *b);
bool b_has_state(const Battler *b, int id);
void b_add_state(Battler *b, int id);
void b_remove_state(Battler *b, int id);
void b_set_hp(Battler *b, int hp);
void b_gain_hp(Battler *b, int v);
void b_gain_mp(Battler *b, int v);
void b_recover_all(Battler *b);
const char *b_name(const Battler *b);
int  actor_exp_for_level(int classId, int level);
int  actor_max_level(const Battler *b);
void actor_gain_exp(Battler *b, int exp, int *levelsGained);
void actor_level_up(Battler *b);
void actor_change_equip(Battler *b, int slot, int item);
bool actor_skill_known(const Battler *b, int skillId);
int  actor_equip_type(int slot);
bool actor_has_skill_type(const Battler *b, int stype);
double eval_formula_d(const Damage *d, const Battler *a, const Battler *bt);

/* actions (shared by battle and menus) */
typedef struct { int hit, evaded, missed, critical, hpDmg, mpDmg, used, added[4], nadded, removed[4], nremoved; } ActResult;
bool action_is_item(const BAction *a);
const Damage *action_damage(const BAction *a);
int  action_scope(const BAction *a);
int  action_hit_type(const BAction *a);
void action_apply(Battler *subject, const BAction *a, Battler *target, ActResult *res, bool inBattle);
bool action_usable_on(const BAction *a, const Battler *target);
bool item_can_use(int itemId, const Battler *target);
bool skill_can_pay(const Battler *b, int skillId);
void skill_pay(Battler *b, int skillId);

/* ----------------------------------------------------------------------------- party / inventory */
Battler *actor_get(int actorId);
Battler *party_member(int i);
int  party_count(void);
void party_add(int actorId);
void party_remove(int actorId);
bool party_has(int actorId);
int  item_count(int kind, int id);               /* kind 0 item 1 weapon 2 armor */
void item_gain(int kind, int id, int n);
void game_new(void);
void game_refresh_followers(void);

/* ----------------------------------------------------------------------------- switches / variables */
bool sw_get(int id);
void sw_set(int id, bool v);
int  var_get(int id);
void var_set(int id, int v);
bool ss_get(int map, int ev, int ch);
void ss_set(int map, int ev, int ch, bool v);

/* ----------------------------------------------------------------------------- map.c */
bool map_load(int id);
void map_unload(void);
void map_free_deferred(void);
bool map_valid(int x, int y);
bool map_passable(int x, int y, int d);          /* tile passability when moving in direction d */
bool map_counter(int x, int y);
int  map_xwd(int x, int d); int map_ywd(int y, int d);   /* x/y with direction */
Char *map_event(int eventId);
Char *map_char(int id);                          /* -1 player, 0 = interpreter's event (resolved by caller), n event */
void map_refresh_events(void);
void map_update_events(void);
void map_setup_scroll(void);
void map_update_scroll(void);
void map_center_on_player(void);
PTex *map_sheet_tex(int sheet);
PTex *face_tex(int face);
void char_init(Char *c);
bool char_is_moving(const Char *c);
bool char_is_stopping(const Char *c);
bool char_can_pass(Char *c, int x, int y, int d);
void char_move_straight(Char *c, int d);
void char_move_diag(Char *c, int h, int v);
void char_set_dir(Char *c, int d);
void char_update(Char *c);
void char_jump(Char *c, int dx, int dy);
void char_locate(Char *c, int x, int y);
void char_force_route(Char *c, const int32_t *route, int n, int repeat, int skippable);
bool char_route_done(const Char *c);
void char_turn_toward(Char *c, const Char *o);
void char_event_start(Char *c);
bool char_is_trigger_in(const Char *c, int mask);
float char_real_speed(const Char *c);
int  char_screen_x(const Char *c);
int  char_screen_y(const Char *c);
void char_show_balloon(Char *c, int id);

void player_update(bool active);
void player_reserve_transfer(int map, int x, int y, int dir, int fade);
bool player_transfer_pending(void);
int  player_transfer_fade(void);
void map_unlock_event(int id);
bool player_perform_transfer(void);
bool player_can_move(void);
void player_start_new(void);
bool map_setup_starting_event(void);              /* sets up map interpreter; returns true if started */

/* ----------------------------------------------------------------------------- interpreter + message */
typedef struct {
    int running;
    const int32_t *list; int n, pc, indent;
    int branch[40];
    int eventId;
    struct { const int32_t *list; int n, pc, indent, eventId; } stack[4]; int sp;
    int waitCount, waitMode, waitArg;
    int isBattle, guard;
} Interp;

enum { WM_NONE, WM_MESSAGE, WM_MOVE, WM_FADE, WM_BATTLE, WM_SHOP, WM_TRANSFER, WM_SCROLL, WM_PIC, WM_NAME, WM_SAVE, WM_BALLOON };

typedef struct {
    int active;                 /* window shown */
    int face, faceIdx, bg, pos, nameStr, textStr;
    char lines[24][200]; int nlines;
    int page, shown, pageStart, pageLines;
    int waitKey;                /* all of the current page is visible, waiting for A */
    int nchoices, choiceStr[8], cancelType, defaultType, choiceDone, choiceResult, choiceCursor;
    int hasChoices, choiceCursorInit;
    int closing;
} Msg;

typedef struct { int active, nlines; int str[200]; float y; int speed, noFast; } ScrollText;

typedef struct {
    int used, pic, origin, x, y, sx, sy, opacity;
    PTex *tex;
} Pic;

extern Msg msg;
extern ScrollText scrolltext;
extern Pic pics[MAX_PIC];
extern Interp g_interp;          /* map interpreter */
extern Interp g_binterp;         /* battle event interpreter */
extern int g_fade;               /* 0 = visible .. 255 = black */
extern int g_fade_target, g_fade_speed, g_fade_white;

void interp_setup(Interp *it, const int32_t *list, int n, int eventId);
void interp_update(Interp *it);
void msg_update(void);
void msg_relayout(void);
void msg_start_text(int face, int faceIdx, int bg, int pos, int nameStr, int textStr);
bool msg_busy(void);
void msg_expand(const char *src, char *dst, int cap);
void pics_clear(void);
void fade_update(void);
void interp_update_scroll(void);
void fmt_msg(char *out, int cap, const char *fmt, ...);

/* shop / battle / scenes requests set by interpreter */
typedef struct { int n; int kind[40], id[40], price[40]; int purchaseOnly; } ShopGoods;
extern ShopGoods g_shop;
extern int g_battle_request;     /* troop id or 0 */
extern int g_battle_can_escape, g_battle_can_lose;
extern int g_battle_result;      /* 0 win 1 escape 2 lose, -1 pending */
extern int g_shop_request, g_scene_request;

/* ----------------------------------------------------------------------------- scenes */
enum { SC_TITLE, SC_MAP, SC_BATTLE, SC_GAMEOVER };
extern int g_scene;

void battle_start(int troopId, bool canEscape, bool canLose);
void battle_update(void);
void battle_draw(void);
bool battle_finished(void);
int  battle_result(void);
void battle_end_cleanup(void);

void ui_init(void);
void ui_update_map(void);                 /* bottom-screen HUD / menus while on the map */
void ui_draw_map_bottom(void);
bool ui_menu_open(void);
void ui_title_update(void);
void ui_title_draw(void);
void ui_gameover_update(void);
void ui_gameover_draw(void);
void ui_shop_begin(void);
bool ui_shop_active(void);
void ui_choice_update(void);              /* choice list on the bottom screen */
void ui_choice_draw(void);
void ui_draw_window(float x, float y, float w, float h);
void ui_text_centered(const char *s, float cx, float y, float scale, uint32_t col);
void ui_draw_bar(float x, float y, float w, float h, int cur, int max, uint32_t col1, uint32_t col2);
bool ui_button(float x, float y, float w, float h, const char *label, bool enabled, bool *pressed);

void draw_map_scene(void);
void draw_messages(void);
void draw_pics_and_fade(void);

bool save_write(int slot);
bool save_read(int slot);
bool save_info(int slot, char *out, int cap);
void config_load(void);
void config_save(void);

void game_set_scene(int sc);
void game_begin_new(void);
bool game_begin_load(int slot);
void ui_toggle_lang(void);
void ui_apply_loaded_events(void);
void ui_draw_menu_top(void);
void game_frame(const PInput *in);
bool game_init(void);


/* ----------------------------------------------------------------------------- UI list widget (ui.c) */
#define LIST_MAX 96
typedef struct {
    int n, cursor, scroll, rowH, x, y, w, h;
    char label[LIST_MAX][72]; char right[LIST_MAX][20]; uint8_t enabled[LIST_MAX];
    int dragging, dragStartY, dragScroll, touchRow;
} UiList;
void ui_list_init(UiList *l, int x, int y, int w, int h, int rowH);
void ui_list_clear(UiList *l);
void ui_list_add(UiList *l, const char *label, const char *right, bool enabled);
int  ui_list_update(UiList *l);          /* -2 nothing, -1 cancel, >=0 confirmed row */
void ui_list_draw(const UiList *l);
void ui_build_slot_list(UiList *l, bool forSave);
bool ui_tap(float x, float y, float w, float h);
bool ui_msg_choices_ready(void);
bool ui_save_active(void);
void ui_save_begin(void);
void ui_status_row(float x, float y, float w, const Battler *b, bool showFace);

bool msg_choices_ready(void);
void map_erase_event(int id);
void battle_cmd_enemy_state(int index, int op, int stateId);
void battle_cmd_enemy_appear(int index);
bool battle_active(void);
void battle_input(void);

const char *ui_s(int id);                 /* built-in UI string in the current language */
#include "strings_ui.h"

#endif
