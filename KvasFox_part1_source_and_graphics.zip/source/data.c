/* data.c - loads db.bin / strings.bin written by tools/convert.py */
#include "data.h"
#include "platform.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

Database db;
int g_lang = LANG_EN;

static uint8_t *s_strbuf;
static uint32_t s_nstr;
static const uint32_t *s_off_ru, *s_off_en;
static const char *s_blob;

const char *str_lang(int id, int lang)
{
    if (id < 0 || (uint32_t)id >= s_nstr) return "";
    return s_blob + (lang == LANG_RU ? s_off_ru[id] : s_off_en[id]);
}

const char *tx(int id) { return str_lang(id, g_lang); }

/* ---- binary reader ---------------------------------------------------------------- */
typedef struct { const int32_t *p, *end; } R;

static int32_t rd(R *r)
{
    if (r->p >= r->end) { fprintf(stderr, "db.bin: read past end\n"); exit(1); }
    return *r->p++;
}
static void mark(R *r, int n)
{
    int32_t v = rd(r);
    if (v != 0x5EC70000 + n) { fprintf(stderr, "db.bin: section %d out of sync (got %08x)\n", n, v); exit(1); }
}
static void *xcalloc(size_t n, size_t s) { void *p = calloc(n ? n : 1, s); if (!p) { fprintf(stderr, "out of memory\n"); exit(1); } return p; }

static void rd_traits(R *r, Traits *t)
{
    t->n = rd(r);
    t->v = xcalloc(t->n, sizeof(Trait));
    for (int i = 0; i < t->n; i++) { t->v[i].code = rd(r); t->v[i].id = rd(r); t->v[i].val = rd(r); }
}
static void rd_effects(R *r, int *n, Effect **fx)
{
    *n = rd(r);
    *fx = xcalloc(*n, sizeof(Effect));
    for (int i = 0; i < *n; i++) { (*fx)[i].code = rd(r); (*fx)[i].id = rd(r); (*fx)[i].v1 = rd(r); (*fx)[i].v2 = rd(r); }
}
static void rd_damage(R *r, Damage *d)
{
    d->type = rd(r); d->element = rd(r); d->variance = rd(r); d->critical = rd(r); d->n = rd(r);
    d->rpn = r->p;
    for (int i = 0; i < d->n * 2; i++) rd(r);
}
static const int32_t *rd_cmds(R *r, int *n)
{
    *n = rd(r);
    const int32_t *p = r->p;
    for (int i = 0; i < *n; i++) rd(r);
    return p;
}

bool data_init(void)
{
    size_t sz;
    s_strbuf = plat_read_file("strings.bin", &sz);
    if (!s_strbuf) { fprintf(stderr, "strings.bin missing\n"); return false; }
    s_nstr = *(uint32_t *)s_strbuf;
    s_off_ru = (uint32_t *)(s_strbuf + 4);
    s_off_en = s_off_ru + s_nstr;
    s_blob = (const char *)(s_off_en + s_nstr);

    uint8_t *buf = plat_read_file("db.bin", &sz);   /* kept for the whole run: commands point into it */
    if (!buf) { fprintf(stderr, "db.bin missing\n"); return false; }
    R r = { (const int32_t *)buf, (const int32_t *)(buf + sz) };
    if (rd(&r) != 0x4B564442 || rd(&r) != 1) { fprintf(stderr, "db.bin: bad header\n"); return false; }

    db.startMap = rd(&r); db.startX = rd(&r); db.startY = rd(&r);
    db.nparty = rd(&r);
    for (int i = 0; i < db.nparty; i++) { int v = rd(&r); if (i < 8) db.party[i] = v; }
    db.currency = rd(&r);
    db.nsounds = rd(&r);
    for (int i = 0; i < db.nsounds; i++) { int v = rd(&r); if (i < 32) db.sounds[i] = v; }
    db.titleBgm = rd(&r); db.victoryMe = rd(&r); db.defeatMe = rd(&r); db.gameoverMe = rd(&r);
    db.followers = rd(&r);
    mark(&r, 10);

    db.nactors = rd(&r); db.actors = xcalloc(db.nactors, sizeof(ActorDef));
    for (int i = 0; i < db.nactors; i++) {
        ActorDef *a = &db.actors[i];
        if (!(a->exists = rd(&r))) continue;
        a->name = rd(&r); a->classId = rd(&r); a->initLevel = rd(&r); a->maxLevel = rd(&r);
        a->charId = rd(&r); a->charIdx = rd(&r); a->faceId = rd(&r); a->faceIdx = rd(&r);
        for (int k = 0; k < 5; k++) a->equips[k] = rd(&r);
        rd_traits(&r, &a->tr);
    }
    mark(&r, 11);

    db.nclasses = rd(&r); db.classes = xcalloc(db.nclasses, sizeof(ClassDef));
    for (int i = 0; i < db.nclasses; i++) {
        ClassDef *c = &db.classes[i];
        if (!(c->exists = rd(&r))) continue;
        c->name = rd(&r);
        for (int k = 0; k < 4; k++) c->expParams[k] = rd(&r);
        for (int p = 0; p < 8; p++) for (int l = 0; l < 100; l++) c->params[p][l] = rd(&r);
        c->nlearn = rd(&r); c->learn = xcalloc(c->nlearn, sizeof(Learning));
        for (int k = 0; k < c->nlearn; k++) { c->learn[k].level = rd(&r); c->learn[k].skill = rd(&r); }
        rd_traits(&r, &c->tr);
    }
    mark(&r, 12);

    db.nskills = rd(&r); db.skills = xcalloc(db.nskills, sizeof(SkillDef));
    for (int i = 0; i < db.nskills; i++) {
        SkillDef *s = &db.skills[i];
        if (!(s->exists = rd(&r))) continue;
        s->name = rd(&r); s->stype = rd(&r); s->scope = rd(&r); s->occasion = rd(&r); s->hitType = rd(&r);
        s->mpCost = rd(&r); s->tpCost = rd(&r); s->successRate = rd(&r); s->repeats = rd(&r);
        s->anim = rd(&r); s->speed = rd(&r);
        rd_damage(&r, &s->dmg); rd_effects(&r, &s->nfx, &s->fx);
    }
    mark(&r, 13);

    db.nitems = rd(&r); db.items = xcalloc(db.nitems, sizeof(ItemDef));
    for (int i = 0; i < db.nitems; i++) {
        ItemDef *s = &db.items[i];
        if (!(s->exists = rd(&r))) continue;
        s->name = rd(&r); s->desc = rd(&r); s->itype = rd(&r); s->price = rd(&r); s->consumable = rd(&r);
        s->scope = rd(&r); s->occasion = rd(&r); s->hitType = rd(&r); s->successRate = rd(&r);
        s->repeats = rd(&r); s->speed = rd(&r);
        rd_damage(&r, &s->dmg); rd_effects(&r, &s->nfx, &s->fx);
    }
    mark(&r, 14);

    for (int pass = 0; pass < 2; pass++) {
        int n = rd(&r);
        EquipDef *arr = xcalloc(n, sizeof(EquipDef));
        for (int i = 0; i < n; i++) {
            EquipDef *e = &arr[i];
            if (!(e->exists = rd(&r))) continue;
            e->name = rd(&r); e->etype = rd(&r); e->kind = rd(&r); e->price = rd(&r);
            for (int k = 0; k < 8; k++) e->params[k] = rd(&r);
            rd_traits(&r, &e->tr);
        }
        if (pass == 0) { db.nweapons = n; db.weapons = arr; } else { db.narmors = n; db.armors = arr; }
    }
    mark(&r, 15);

    db.nenemies = rd(&r); db.enemies = xcalloc(db.nenemies, sizeof(EnemyDef));
    for (int i = 0; i < db.nenemies; i++) {
        EnemyDef *e = &db.enemies[i];
        if (!(e->exists = rd(&r))) continue;
        e->name = rd(&r); e->img = rd(&r);
        for (int k = 0; k < 8; k++) e->params[k] = rd(&r);
        e->exp = rd(&r); e->gold = rd(&r);
        for (int k = 0; k < 3; k++) { e->drop[k].kind = rd(&r); e->drop[k].id = rd(&r); e->drop[k].den = rd(&r); }
        e->nact = rd(&r); e->act = xcalloc(e->nact, sizeof(EnemyAction));
        for (int k = 0; k < e->nact; k++) {
            e->act[k].skill = rd(&r); e->act[k].rating = rd(&r); e->act[k].ctype = rd(&r);
            e->act[k].cp1 = rd(&r); e->act[k].cp2 = rd(&r);
        }
        rd_traits(&r, &e->tr);
    }
    mark(&r, 16);

    db.nstates = rd(&r); db.states = xcalloc(db.nstates, sizeof(StateDef));
    for (int i = 0; i < db.nstates; i++) {
        StateDef *s = &db.states[i];
        if (!(s->exists = rd(&r))) continue;
        s->name = rd(&r); s->restriction = rd(&r); s->priority = rd(&r); s->autoRemoval = rd(&r);
        s->minTurns = rd(&r); s->maxTurns = rd(&r); s->removeByDamage = rd(&r); s->chanceByDamage = rd(&r);
        rd_traits(&r, &s->tr);
    }
    mark(&r, 17);

    db.ntroops = rd(&r); db.troops = xcalloc(db.ntroops, sizeof(TroopDef));
    for (int i = 0; i < db.ntroops; i++) {
        TroopDef *t = &db.troops[i];
        if (!(t->exists = rd(&r))) continue;
        t->name = rd(&r); t->nmem = rd(&r); t->mem = xcalloc(t->nmem, sizeof(TroopMember));
        for (int k = 0; k < t->nmem; k++) {
            t->mem[k].enemy = rd(&r); t->mem[k].x = rd(&r); t->mem[k].y = rd(&r); t->mem[k].hidden = rd(&r);
        }
        t->npages = rd(&r); t->pages = xcalloc(t->npages, sizeof(TroopPage));
        for (int k = 0; k < t->npages; k++) {
            TroopPage *p = &t->pages[k];
            p->span = rd(&r); p->turnEnding = rd(&r); p->turnValid = rd(&r); p->turnA = rd(&r); p->turnB = rd(&r);
            p->enemyValid = rd(&r); p->enemyIndex = rd(&r); p->enemyHp = rd(&r);
            p->actorValid = rd(&r); p->actorId = rd(&r); p->actorHp = rd(&r);
            p->switchValid = rd(&r); p->switchId = rd(&r);
            p->cmd = rd_cmds(&r, &p->ncmd);
        }
    }
    mark(&r, 18);

    db.ncommon = rd(&r); db.common = xcalloc(db.ncommon, sizeof(CommonEventDef));
    for (int i = 0; i < db.ncommon; i++) {
        CommonEventDef *c = &db.common[i];
        if (!(c->exists = rd(&r))) continue;
        c->trigger = rd(&r); c->switchId = rd(&r);
        c->cmd = rd_cmds(&r, &c->ncmd);
    }
    mark(&r, 19);

    db.nchars = rd(&r); db.chars = xcalloc(db.nchars, sizeof(CharSheetInfo));
    for (int i = 0; i < db.nchars; i++) {
        db.chars[i].w = rd(&r); db.chars[i].h = rd(&r); db.chars[i].cw = rd(&r); db.chars[i].ch = rd(&r); db.chars[i].flags = rd(&r);
    }
    db.nfaces = rd(&r); db.faces = xcalloc(db.nfaces, sizeof(ImgInfo));
    for (int i = 0; i < db.nfaces; i++) { db.faces[i].w = rd(&r); db.faces[i].h = rd(&r); }
    db.npics = rd(&r); db.pics = xcalloc(db.npics, sizeof(ImgInfo));
    for (int i = 0; i < db.npics; i++) { db.pics[i].w = rd(&r); db.pics[i].h = rd(&r); }
    db.nenemyimgs = rd(&r); db.enemyimgs = xcalloc(db.nenemyimgs, sizeof(ImgInfo));
    for (int i = 0; i < db.nenemyimgs; i++) { db.enemyimgs[i].w = rd(&r); db.enemyimgs[i].h = rd(&r); }
    db.naudio = rd(&r); db.audiokind = xcalloc(db.naudio, 1);
    for (int i = 0; i < db.naudio; i++) db.audiokind[i] = (uint8_t)rd(&r);
    mark(&r, 20);
    return true;
}
