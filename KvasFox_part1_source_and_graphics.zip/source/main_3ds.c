/* main_3ds.c - entry point for the Nintendo 3DS build */
#include "game.h"

int main(int argc, char **argv)
{
    (void)argc; (void)argv;
    if (!plat_init()) return 1;
    PInput in;
    if (!game_init()) {
        /* assets missing / corrupt: show a message instead of crashing */
        while (plat_running()) {
            plat_begin_frame(&in);
            plat_target(0);
            plat_text("Kvas Fox: could not load game data (romfs).", 10, 100, 0.5f, RGBA(255, 120, 120, 255));
            plat_text("Press START to exit.", 10, 124, 0.5f, RGBA(255, 255, 255, 255));
            plat_end_frame();
            if (in.down & K_START) break;
        }
        plat_shutdown();
        return 1;
    }
    while (plat_running()) {
        plat_begin_frame(&in);
        game_frame(&in);
        plat_end_frame();
    }
    plat_shutdown();
    return 0;
}
