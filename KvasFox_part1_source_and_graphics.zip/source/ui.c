/* ui.c - all touch/button UI: widgets, title screen, choices, game over, save/load files.
 * Map HUD, menus and shop live in menu.c (same widgets). */
#include "game.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* ----------------------------------------------------------------------------- UI strings */
typedef struct { const char *en, *ru; } UiStr;
static const UiStr s_ui[] = {
#define X_TAB(e, en, ru) { en, ru },
    UI_STRINGS(X_TAB)
#undef X_TAB
};
const char *ui_s(int id) { return (id >= 0 && id < S_COUNT) ? (g_lang == LANG_RU ? s_ui[id].ru : s_ui[id].en) : ""; }

/* ----------------------------------------------------------------------------- drawing helpers */
void ui_draw_window(float x, float y, float w, float h)
{
    plat_rect(x, y, w, h, RGBA(10, 12, 44, 225));
    plat_rect(x, y, w, 2, RGBA(215, 220, 255, 235));
    plat_rect(x, y + h - 2, w, 2, RGBA(215, 220, 255, 235));
    plat_rect(x, y, 2, h, RGBA(215, 220, 255, 235));
    plat_rect(x + w - 2, y, 2, h, RGBA(215, 220, 255, 235));
}

void ui_text_centered(const char *s, float cx, float y, float scale, uint32_t col)
{
    plat_text(s, cx - plat_text_w(s, scale) / 2.0f, y, scale, col);
}

void ui_draw_bar(float x, float y, float w, float h, int cur, int max, uint32_t c1, uint32_t c2)
{
    plat_rect(x, y, w, h, RGBA(0, 0, 0, 200));
    if (max <= 0) return;
    float f = (float)clampi(cur, 0, max) / max;
    plat_rect(x + 1, y + 1, (w - 2) * f, h - 2, c1);
    plat_rect(x + 1, y + 1, (w - 2) * f, (h - 2) / 2, c2);
}

bool ui_tap(float x, float y, float w, float h)
{
    return g_in.touch_down && g_in.tx >= x && g_in.tx < x + w && g_in.ty >= y && g_in.ty < y + h;
}

bool ui_button(float x, float y, float w, float h, const char *label, bool enabled, bool *pressed)
{
    bool inside = g_in.touching && g_in.tx >= x && g_in.tx < x + w && g_in.ty >= y && g_in.ty < y + h;
    bool down = inside && enabled;
    if (pressed) *pressed = down;
    plat_rect(x, y, w, h, down ? RGBA(90, 100, 200, 255) : (enabled ? RGBA(40, 48, 120, 245) : RGBA(40, 40, 50, 230)));
    plat_rect(x, y, w, 2, RGBA(190, 200, 255, enabled ? 255 : 90));
    plat_rect(x, y + h - 2, w, 2, RGBA(0, 0, 20, 255));
    plat_rect(x, y, 2, h, RGBA(190, 200, 255, enabled ? 255 : 90));
    plat_rect(x + w - 2, y, 2, h, RGBA(0, 0, 20, 255));
    float sc = 0.5f;
    while (plat_text_w(label, sc) > w - 8 && sc > 0.3f) sc -= 0.025f;
    ui_text_centered(label, x + w / 2.0f, y + (h - plat_text_h(sc)) / 2.0f, sc, enabled ? RGBA(255, 255, 255, 255) : RGBA(140, 140, 150, 255));
    return ui_tap(x, y, w, h) && enabled;
}

void ui_status_row(float x, float y, float w, const Battler *b, bool showFace)
{
    plat_rect(x, y, w, 33, RGBA(0, 0, 0, 120));
    float tx0 = x + 4;
    if (showFace && b->isActor) {
        const ActorDef *a = &db.actors[b->id];
        PTex *ft = face_tex(a->faceId);
        if (ft) plat_blit(ft, (a->faceIdx % 4) * 72, (a->faceIdx / 4) * 72, 72, 72, x + 2, y + 1, 0.43f, false, 255);
        tx0 = x + 36;
    }
    char t[96];
    snprintf(t, sizeof t, "%s  %s%d", b_name(b), ui_s(S_LV), b->level);
    plat_text(t, tx0, y, 0.5f, b_dead(b) ? RGBA(255, 100, 100, 255) : RGBA(255, 255, 255, 255));
    snprintf(t, sizeof t, "MP %d/%d", b->mp, b_param(b, 1));
    plat_text(t, x + w - plat_text_w(t, 0.42f) - 4, y + 1, 0.42f, RGBA(170, 190, 255, 255));
    snprintf(t, sizeof t, "HP %d/%d", b->hp, b_param(b, 0));
    plat_text(t, tx0, y + 15, 0.42f, RGBA(255, 255, 255, 255));
    float bx = tx0 + plat_text_w(t, 0.42f) + 8;
    ui_draw_bar(bx, y + 19, x + w - 6 - bx, 6, b->hp, b_param(b, 0), RGBA(220, 70, 70, 255), RGBA(255, 150, 120, 255));
    ui_draw_bar(tx0, y + 28, x + w - 6 - tx0, 3, b->mp, b_param(b, 1), RGBA(60, 90, 230, 255), RGBA(120, 160, 255, 255));
}

/* ----------------------------------------------------------------------------- list widget */
void ui_list_init(UiList *l, int x, int y, int w, int h, int rowH)
{
    memset(l, 0, sizeof *l);
    l->x = x; l->y = y; l->w = w; l->h = h; l->rowH = rowH; l->touchRow = -1;
}
void ui_list_clear(UiList *l) { l->n = 0; l->cursor = 0; l->scroll = 0; }
void ui_list_add(UiList *l, const char *label, const char *right, bool enabled)
{
    if (l->n >= LIST_MAX) return;
    snprintf(l->label[l->n], sizeof l->label[0], "%s", label ? label : "");
    snprintf(l->right[l->n], sizeof l->right[0], "%s", right ? right : "");
    l->enabled[l->n] = enabled;
    l->n++;
}

static int vis_rows(const UiList *l) { int v = l->h / l->rowH; return v < 1 ? 1 : v; }
static void keep_visible(UiList *l)
{
    int v = vis_rows(l);
    if (l->cursor < l->scroll) l->scroll = l->cursor;
    if (l->cursor >= l->scroll + v) l->scroll = l->cursor - v + 1;
    int maxs = l->n - v; if (maxs < 0) maxs = 0;
    l->scroll = clampi(l->scroll, 0, maxs);
}

int ui_list_update(UiList *l)
{
    static int hold_up, hold_down;
    if (g_in.down & K_B) return -1;
    if (l->n == 0) return -2;
    l->cursor = clampi(l->cursor, 0, l->n - 1);
    /* d-pad with auto repeat */
    hold_up = (g_in.held & K_UP) ? hold_up + 1 : 0;
    hold_down = (g_in.held & K_DOWN) ? hold_down + 1 : 0;
    bool up = (g_in.down & K_UP) || (hold_up > 18 && hold_up % 4 == 0);
    bool dn = (g_in.down & K_DOWN) || (hold_down > 18 && hold_down % 4 == 0);
    if (up && l->cursor > 0) { l->cursor--; audio_sys(SND_CURSOR); }
    if (dn && l->cursor < l->n - 1) { l->cursor++; audio_sys(SND_CURSOR); }
    if ((g_in.down & K_L) && l->cursor > 0) l->cursor = clampi(l->cursor - vis_rows(l), 0, l->n - 1);
    if ((g_in.down & K_R) && l->cursor < l->n - 1) l->cursor = clampi(l->cursor + vis_rows(l), 0, l->n - 1);
    if (up || dn || (g_in.down & (K_L | K_R))) keep_visible(l);

    if (g_in.down & K_A) {
        if (l->enabled[l->cursor]) return l->cursor;
        audio_sys(SND_BUZZER); return -2;
    }
    /* touch: tap selects, vertical drag scrolls */
    bool inside = g_in.tx >= l->x && g_in.tx < l->x + l->w && g_in.ty >= l->y && g_in.ty < l->y + l->h;
    if (g_in.touch_down && inside) {
        l->touchRow = l->scroll + (g_in.ty - l->y) / l->rowH; l->dragging = 0;
        l->dragStartY = g_in.ty; l->dragScroll = l->scroll;
    }
    if (g_in.touching && l->touchRow >= -1 && l->dragStartY) {
        if (abs(g_in.ty - l->dragStartY) > 7) l->dragging = 1;
        if (l->dragging) {
            int v = vis_rows(l), maxs = l->n - v; if (maxs < 0) maxs = 0;
            l->scroll = clampi(l->dragScroll + (l->dragStartY - g_in.ty) / l->rowH, 0, maxs);
        }
    }
    if (g_in.touch_up && l->touchRow >= 0) {
        int row = l->touchRow; bool was_drag = l->dragging;
        l->touchRow = -1; l->dragging = 0; l->dragStartY = 0;
        if (!was_drag && row < l->n && inside) {
            l->cursor = row;
            if (l->enabled[row]) return row;
            audio_sys(SND_BUZZER);
        }
    }
    return -2;
}

void ui_list_draw(const UiList *l)
{
    int v = vis_rows(l);
    for (int k = 0; k < v; k++) {
        int i = l->scroll + k;
        if (i >= l->n) break;
        float y = l->y + k * l->rowH;
        bool sel = (i == l->cursor);
        plat_rect(l->x, y, l->w, l->rowH - 2, sel ? RGBA(70, 80, 170, 235) : RGBA(0, 0, 0, 120));
        uint32_t col = l->enabled[i] ? RGBA(255, 255, 255, 255) : RGBA(130, 130, 145, 255);
        float ty = y + (l->rowH - 2 - plat_text_h(0.5f)) / 2.0f;
        float rw = l->right[i][0] ? plat_text_w(l->right[i], 0.5f) + 12 : 0;
        float sc = 0.5f;
        while (plat_text_w(l->label[i], sc) > l->w - rw - 14 && sc > 0.3f) sc -= 0.025f;
        plat_text(l->label[i], l->x + 8, y + (l->rowH - 2 - plat_text_h(sc)) / 2.0f, sc, col);
        if (l->right[i][0]) plat_text(l->right[i], l->x + l->w - rw + 2, ty, 0.5f, col);
    }
    if (l->n > v) {   /* scroll bar */
        float bh = l->h * (float)v / l->n, by = l->y + (l->h - bh) * (l->scroll / (float)(l->n - v));
        plat_rect(l->x + l->w - 4, l->y, 3, l->h, RGBA(0, 0, 0, 120));
        plat_rect(l->x + l->w - 4, by, 3, bh, RGBA(200, 210, 255, 220));
    }
}

/* ----------------------------------------------------------------------------- config + save files */
void config_load(void)
{
    FILE *f = plat_open_user("config.dat", false);
    if (!f) return;
    int v = fgetc(f); fclose(f);
    if (v == LANG_RU || v == LANG_EN) g_lang = v;
}
void config_save(void)
{
    FILE *f = plat_open_user("config.dat", true);
    if (!f) return;
    fputc(g_lang, f); fclose(f);
}

typedef struct { char magic[8]; int version, size, lead, leadLevel, nparty, mapId, bgm; uint32_t playtime; } SaveHead;
typedef struct { int8_t erased, dir; int16_t x, y; } EvSave;

static void slot_name(int slot, char *out, int cap) { snprintf(out, cap, "save%d.sav", slot + 1); }

bool save_write(int slot)
{
    char nm[32]; slot_name(slot, nm, sizeof nm);
    FILE *f = plat_open_user(nm, true);
    if (!f) return false;
    SaveHead hd; memset(&hd, 0, sizeof hd);
    memcpy(hd.magic, "KVASFOX", 8); hd.version = 1; hd.size = (int)sizeof(GameState);
    Battler *lead = party_member(0);
    hd.lead = lead ? lead->id : 0; hd.leadLevel = lead ? lead->level : 1; hd.nparty = g.nparty; hd.mapId = g.mapId;
    hd.bgm = audio_cur_bgm(); hd.playtime = g.playtime;
    g.mapId = M.id; g.px = player.x; g.py = player.y; g.pdir = player.dir;
    EvSave es[MAX_EV]; memset(es, 0, sizeof es);
    for (int i = 0; i < g_nevs; i++) { es[i].erased = evs[i].erased; es[i].dir = evs[i].dir; es[i].x = evs[i].x; es[i].y = evs[i].y; }
    int ne = g_nevs;
    bool ok = fwrite(&hd, sizeof hd, 1, f) == 1 && fwrite(&g, sizeof g, 1, f) == 1 && fwrite(&ne, sizeof ne, 1, f) == 1 &&
              fwrite(es, sizeof es[0], ne, f) == (size_t)ne;
    fclose(f);
    return ok;
}

bool save_info(int slot, char *out, int cap)
{
    char nm[32]; slot_name(slot, nm, sizeof nm);
    FILE *f = plat_open_user(nm, false);
    if (!f) return false;
    SaveHead hd;
    bool ok = fread(&hd, sizeof hd, 1, f) == 1 && !memcmp(hd.magic, "KVASFOX", 8) && hd.version == 1 && hd.size == (int)sizeof(GameState);
    fclose(f);
    if (!ok) return false;
    if (out) {
        int secs = (int)(hd.playtime / 60);
        const char *name = (hd.lead > 0 && hd.lead < db.nactors) ? tx(db.actors[hd.lead].name) : "?";
        snprintf(out, cap, "%s %s%d  %d:%02d", name, ui_s(S_LV), hd.leadLevel, secs / 3600, (secs / 60) % 60);
    }
    return true;
}

static EvSave s_loaded_ev[MAX_EV]; static int s_loaded_nev; static int s_loaded_bgm;

bool save_read(int slot)
{
    char nm[32]; slot_name(slot, nm, sizeof nm);
    FILE *f = plat_open_user(nm, false);
    if (!f) return false;
    SaveHead hd; static GameState tmp;
    bool ok = fread(&hd, sizeof hd, 1, f) == 1 && !memcmp(hd.magic, "KVASFOX", 8) && hd.version == 1 && hd.size == (int)sizeof(GameState) &&
              fread(&tmp, sizeof tmp, 1, f) == 1 && fread(&s_loaded_nev, sizeof s_loaded_nev, 1, f) == 1 &&
              s_loaded_nev >= 0 && s_loaded_nev <= MAX_EV && fread(s_loaded_ev, sizeof s_loaded_ev[0], s_loaded_nev, f) == (size_t)s_loaded_nev;
    fclose(f);
    if (!ok) return false;
    g = tmp; s_loaded_bgm = hd.bgm;
    return true;
}

void ui_apply_loaded_events(void)
{
    for (int i = 0; i < g_nevs && i < s_loaded_nev; i++) {
        evs[i].erased = s_loaded_ev[i].erased; evs[i].x = s_loaded_ev[i].x; evs[i].y = s_loaded_ev[i].y;
        evs[i].rx = evs[i].x; evs[i].ry = evs[i].y; evs[i].dir = s_loaded_ev[i].dir ? s_loaded_ev[i].dir : evs[i].dir;
    }
    g_needs_refresh = 1;
    if (s_loaded_bgm >= 0) audio_bgm(s_loaded_bgm, 90);
}

void ui_toggle_lang(void)
{
    g_lang = g_lang == LANG_EN ? LANG_RU : LANG_EN;
    config_save();
    msg_relayout();
}

/* ----------------------------------------------------------------------------- title screen */
static int s_title_cursor;
static PTex *s_title_tex;
static int s_title_slot_menu;     /* 1 = choosing a save slot to continue */
static UiList s_title_list;
static int s_title_msg_timer; static char s_title_msg[64];

static bool any_save(void) { for (int i = 0; i < NSLOTS; i++) if (save_info(i, NULL, 0)) return true; return false; }

void ui_init(void)
{
    s_title_tex = plat_tex_load("title");
}

static void build_slot_list(UiList *l, bool forSave)
{
    ui_list_init(l, 10, 40, 300, 150, 40);
    ui_list_clear(l);
    for (int i = 0; i < NSLOTS; i++) {
        char lab[48], info[96];
        snprintf(lab, sizeof lab, ui_s(S_SLOT), i + 1);
        bool has = save_info(i, info, sizeof info);
        char both[130]; snprintf(both, sizeof both, "%s: %s", lab, has ? info : ui_s(S_EMPTY_SLOT));
        ui_list_add(l, both, "", forSave || has);
    }
}
void ui_build_slot_list(UiList *l, bool forSave) { build_slot_list(l, forSave); }

void ui_title_update(void)
{
    if (audio_cur_bgm() != db.titleBgm) audio_bgm(db.titleBgm, 90);
    if (s_title_msg_timer > 0) s_title_msg_timer--;
    if (g_in.down & K_SELECT) ui_toggle_lang();
    if (s_title_slot_menu) {
        int r = ui_list_update(&s_title_list);
        if (r == -1 || ui_tap(220, 200, 90, 30)) { s_title_slot_menu = 0; audio_sys(SND_CANCEL); }
        else if (r >= 0) {
            audio_sys(SND_LOAD);
            if (!game_begin_load(r)) { snprintf(s_title_msg, sizeof s_title_msg, "%s", ui_s(S_NO_SAVE)); s_title_msg_timer = 120; }
            s_title_slot_menu = 0;
        }
        return;
    }
    bool hasSave = any_save();
    const int N = 4;
    if (g_in.down & K_UP) { s_title_cursor = (s_title_cursor + N - 1) % N; audio_sys(SND_CURSOR); }
    if (g_in.down & K_DOWN) { s_title_cursor = (s_title_cursor + 1) % N; audio_sys(SND_CURSOR); }
    int pick = -1;
    for (int i = 0; i < N; i++) if (ui_tap(40, 20 + i * 52, 240, 44)) pick = i;
    if (g_in.down & K_A) pick = s_title_cursor;
    if (g_in.down & K_START) pick = 0;
    if (pick < 0) return;
    s_title_cursor = pick;
    switch (pick) {
        case 0: audio_sys(SND_OK); game_begin_new(); break;
        case 1:
            if (!hasSave) { audio_sys(SND_BUZZER); snprintf(s_title_msg, sizeof s_title_msg, "%s", ui_s(S_NO_SAVE)); s_title_msg_timer = 120; break; }
            audio_sys(SND_OK); build_slot_list(&s_title_list, false); s_title_slot_menu = 1; break;
        case 2: audio_sys(SND_OK); ui_toggle_lang(); break;
        case 3: plat_exit_request(); break;
    }
}

void ui_title_draw(void)
{
    plat_target(0);
    plat_rect(0, 0, SCR_W, SCR_H, RGBA(0, 0, 0, 255));
    if (s_title_tex) plat_blit(s_title_tex, 0, 0, 314, 240, 43, 0, 1.0f, false, 255);
    ui_text_centered(ui_s(S_TITLE_HINT), 200, 222, 0.42f, RGBA(255, 255, 255, 230));
    plat_target(1);
    plat_rect(0, 0, BSCR_W, BSCR_H, RGBA(18, 18, 34, 255));
    if (s_title_slot_menu) {
        ui_text_centered(ui_s(S_LOAD_HERE), 160, 12, 0.55f, RGBA(255, 235, 150, 255));
        ui_list_draw(&s_title_list);
        ui_button(220, 200, 90, 30, ui_s(S_BACK), true, NULL);
        return;
    }
    const char *labels[4] = { ui_s(S_NEWGAME), ui_s(S_CONTINUE), ui_s(S_LANGUAGE), ui_s(S_EXIT) };
    for (int i = 0; i < 4; i++) {
        bool en = !(i == 1 && !any_save());
        ui_button(40, 20 + i * 52, 240, 44, labels[i], en, NULL);
        if (i == s_title_cursor) plat_rect(30, 20 + i * 52 + 14, 6, 16, RGBA(255, 230, 90, 255));
    }
    if (s_title_msg_timer > 0) ui_text_centered(s_title_msg, 160, 226, 0.5f, RGBA(255, 150, 150, 255));
}

/* ----------------------------------------------------------------------------- choices (bottom screen) */
static int s_choice_cursor;

void ui_choice_update(void)
{
    int n = msg.nchoices;
    if (n <= 0) { msg.choiceDone = 1; msg.choiceResult = -1; return; }
    if (!msg.choiceCursorInit) { s_choice_cursor = clampi(msg.defaultType, 0, n - 1); msg.choiceCursorInit = 1; }
    if (g_in.down & K_UP) { s_choice_cursor = (s_choice_cursor + n - 1) % n; audio_sys(SND_CURSOR); }
    if (g_in.down & K_DOWN) { s_choice_cursor = (s_choice_cursor + 1) % n; audio_sys(SND_CURSOR); }
    float rh = n <= 4 ? 44 : (n <= 6 ? 32 : 24), gap = 6;
    float total = n * rh + (n - 1) * gap, y0 = (BSCR_H - total) / 2.0f;
    int pick = -1;
    for (int i = 0; i < n; i++) if (ui_tap(30, y0 + i * (rh + gap), 260, rh)) pick = i;
    if (g_in.down & K_A) pick = s_choice_cursor;
    if (pick >= 0) {
        audio_sys(SND_OK);
        msg.choiceDone = 1; msg.choiceResult = pick; msg.choiceCursorInit = 0; return;
    }
    if ((g_in.down & K_B) && msg.cancelType != -1) {
        audio_sys(SND_CANCEL);
        msg.choiceDone = 1; msg.choiceResult = msg.cancelType; msg.choiceCursorInit = 0;
    }
}

void ui_choice_draw(void)
{
    plat_rect(0, 0, BSCR_W, BSCR_H, RGBA(18, 18, 34, 255));
    int n = msg.nchoices;
    if (!msg_choices_ready()) {
        ui_text_centered(ui_s(S_TAP_NEXT), 160, 108, 0.5f, RGBA(220, 220, 240, 255));
        return;
    }
    float rh = n <= 4 ? 44 : (n <= 6 ? 32 : 24), gap = 6;
    float total = n * rh + (n - 1) * gap, y0 = (BSCR_H - total) / 2.0f;
    for (int i = 0; i < n; i++) {
        ui_button(30, y0 + i * (rh + gap), 260, rh, tx(msg.choiceStr[i]), true, NULL);
        if (i == s_choice_cursor) plat_rect(20, y0 + i * (rh + gap) + rh / 2 - 8, 6, 16, RGBA(255, 230, 90, 255));
    }
}

/* ----------------------------------------------------------------------------- game over */
void ui_gameover_update(void)
{
    if ((g_in.down & (K_A | K_START)) || g_in.touch_down) { audio_bgm_stop(); g_scene_request = SC_TITLE; }
}
void ui_gameover_draw(void)
{
    plat_target(0);
    plat_rect(0, 0, SCR_W, SCR_H, RGBA(0, 0, 0, 255));
    ui_text_centered(ui_s(S_GAMEOVER), 200, 100, 1.2f, RGBA(220, 40, 40, 255));
    plat_target(1);
    plat_rect(0, 0, BSCR_W, BSCR_H, RGBA(18, 18, 34, 255));
    ui_text_centered(ui_s(S_GO_HINT), 160, 110, 0.5f, RGBA(220, 220, 240, 255));
}
