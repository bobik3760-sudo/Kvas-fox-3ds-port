/* data.h - static game database (loaded from romfs:/db.bin + strings.bin) */
#ifndef DATA_H
#define DATA_H

#include <stdint.h>
#include <stdbool.h>

#define LANG_RU 0
#define LANG_EN 1

#define MAX_DB 512
#define MAX_STATES 64

typedef struct { int code, id, val; } Trait;            /* val is value * 10000 */
typedef struct { int n; Trait *v; } Traits;
typedef struct { int code, id, v1, v2; } Effect;        /* v1, v2 are value * 10000 */
typedef struct { int type, element, variance, critical, n; const int32_t *rpn; } Damage;

typedef struct {
    int exists, name, stype, scope, occasion, hitType, mpCost, tpCost, successRate, repeats, anim, speed;
    Damage dmg; int nfx; Effect *fx;
} SkillDef;

typedef struct {
    int exists, name, desc, itype, price, consumable, scope, occasion, hitType, successRate, repeats, speed;
    Damage dmg; int nfx; Effect *fx;
} ItemDef;

typedef struct { int exists, name, etype, kind, price, params[8]; Traits tr; } EquipDef;

typedef struct {
    int exists, name, classId, initLevel, maxLevel, charId, charIdx, faceId, faceIdx, equips[5];
    Traits tr;
} ActorDef;

typedef struct { int level, skill; } Learning;
typedef struct {
    int exists, name, expParams[4];
    int params[8][100];
    int nlearn; Learning *learn;
    Traits tr;
} ClassDef;

typedef struct { int skill, rating, ctype, cp1, cp2; } EnemyAction;
typedef struct { int kind, id, den; } DropDef;
typedef struct {
    int exists, name, img, params[8], exp, gold;
    DropDef drop[3];
    int nact; EnemyAction *act;
    Traits tr;
} EnemyDef;

typedef struct {
    int exists, name, restriction, priority, autoRemoval, minTurns, maxTurns, removeByDamage, chanceByDamage;
    Traits tr;
} StateDef;

typedef struct { int enemy, x, y, hidden; } TroopMember;
typedef struct {
    int span, turnEnding, turnValid, turnA, turnB, enemyValid, enemyIndex, enemyHp,
        actorValid, actorId, actorHp, switchValid, switchId;
    int ncmd; const int32_t *cmd;
} TroopPage;
typedef struct {
    int exists, name, nmem; TroopMember *mem; int npages; TroopPage *pages;
} TroopDef;

typedef struct { int exists, trigger, switchId, ncmd; const int32_t *cmd; } CommonEventDef;

typedef struct { int w, h, cw, ch, flags; } CharSheetInfo;   /* flags: 1 big ($), 2 object (!) */
typedef struct { int w, h; } ImgInfo;

typedef struct {
    int startMap, startX, startY, nparty, party[8];
    int currency, nsounds, sounds[32];
    int titleBgm, victoryMe, defeatMe, gameoverMe, followers;

    int nactors; ActorDef *actors;
    int nclasses; ClassDef *classes;
    int nskills; SkillDef *skills;
    int nitems; ItemDef *items;
    int nweapons; EquipDef *weapons;
    int narmors; EquipDef *armors;
    int nenemies; EnemyDef *enemies;
    int nstates; StateDef *states;
    int ntroops; TroopDef *troops;
    int ncommon; CommonEventDef *common;

    int nchars; CharSheetInfo *chars;
    int nfaces; ImgInfo *faces;
    int npics; ImgInfo *pics;
    int nenemyimgs; ImgInfo *enemyimgs;
    int naudio; uint8_t *audiokind;
} Database;

extern Database db;
extern int g_lang;                      /* current language, LANG_RU / LANG_EN */

bool data_init(void);
const char *str_lang(int id, int lang);
const char *tx(int id);                 /* text in the current language ("" for id < 0) */

/* sounds from System.json */
enum { SND_CURSOR, SND_OK, SND_CANCEL, SND_BUZZER, SND_EQUIP, SND_SAVE, SND_LOAD, SND_BATTLE_START,
       SND_ESCAPE, SND_ENEMY_ATTACK, SND_ENEMY_DAMAGE, SND_ENEMY_COLLAPSE, SND_BOSS1, SND_BOSS2,
       SND_ACTOR_DAMAGE, SND_ACTOR_COLLAPSE, SND_RECOVERY, SND_MISS, SND_EVASION, SND_MAGIC_EVASION,
       SND_REFLECTION, SND_SHOP, SND_USE_ITEM, SND_USE_SKILL };

#endif
