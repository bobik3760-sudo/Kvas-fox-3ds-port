#include "../source/data.h"
#include "../source/platform.h"
#include "host.h"
#include <stdio.h>
int main(void)
{
    host_set_roots("romfs", "tests/hostgfx", "tests/user");
    plat_init();
    if (!data_init()) return 1;
    printf("start map %d (%d,%d) party %d first=%d\n", db.startMap, db.startX, db.startY, db.nparty, db.party[0]);
    printf("actors %d classes %d skills %d items %d weapons %d armors %d enemies %d states %d troops %d common %d\n",
           db.nactors, db.nclasses, db.nskills, db.nitems, db.nweapons, db.narmors, db.nenemies, db.nstates, db.ntroops, db.ncommon);
    printf("chars %d faces %d pics %d enemyimgs %d audio %d\n", db.nchars, db.nfaces, db.npics, db.nenemyimgs, db.naudio);
    printf("currency RU='%s' EN='%s'\n", str_lang(db.currency, 0), str_lang(db.currency, 1));
    for (int i = 1; i < db.nactors; i++) if (db.actors[i].exists)
        printf("actor %d: %s / %s class %d lv%d equips %d %d %d %d %d\n", i, str_lang(db.actors[i].name, 0), str_lang(db.actors[i].name, 1),
               db.actors[i].classId, db.actors[i].initLevel, db.actors[i].equips[0], db.actors[i].equips[1], db.actors[i].equips[2], db.actors[i].equips[3], db.actors[i].equips[4]);
    printf("skill 1: %s dmg n=%d fx=%d speed=%d; skill 2 speed=%d\n", str_lang(db.skills[1].name, 1), db.skills[1].dmg.n, db.skills[1].nfx, db.skills[1].speed, db.skills[2].speed);
    printf("troop 1: %d members, %d pages, page0 ncmd=%d\n", db.troops[1].nmem, db.troops[1].npages, db.troops[1].pages[0].ncmd);
    return 0;
}
