"""view.py <prefix> -> <prefix>.png : top+bottom screens side by side with the logged text drawn on top."""
import sys
from PIL import Image, ImageDraw, ImageFont
pre = sys.argv[1]
def load(path): return Image.open(path).convert('RGBA')
top = load(pre + '_top.ppm'); bot = load(pre + '_bottom.ppm')
FONTS = ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/dejavu/DejaVuSans.ttf']
fp = next((f for f in FONTS if __import__('os').path.exists(f)), None)
canvas = Image.new('RGBA', (400 + 20 + 320, 240), (60, 60, 60, 255))
canvas.paste(top, (0, 0)); canvas.paste(bot, (420, 0))
d = ImageDraw.Draw(canvas, 'RGBA')
for line in open(pre + '_text.txt', encoding='utf-8').read().split('\n'):
    if not line.strip(): continue
    try: scr, x, y, sc, col, txt = line.split('\t', 5)
    except ValueError: continue
    sc = float(sc)
    if sc <= 0.05: continue
    col = int(col, 16); r, g, b, a = col & 255, (col >> 8) & 255, (col >> 16) & 255, (col >> 24) & 255
    size = max(6, int(30 * sc * 0.62))
    f = ImageFont.truetype(fp, size) if fp else ImageFont.load_default()
    ox = 0 if scr == '0' else 420
    d.text((ox + float(x), float(y)), txt, font=f, fill=(r, g, b, a))
canvas = canvas.resize((canvas.width * 2, canvas.height * 2), Image.NEAREST)
canvas.convert('RGB').save(pre + '.png'); print('wrote', pre + '.png')
