/* host.h - extra API of the PC test platform (not used on 3DS) */
#ifndef HOST_H
#define HOST_H
#include <stdint.h>
#include <stdbool.h>
void host_set_roots(const char *romfs_dir, const char *hostgfx_dir, const char *user_dir);
void host_set_held(uint32_t mask);          /* buttons held this frame */
void host_set_touch(bool touching, int x, int y);
void host_dump(const char *prefix);         /* writes <prefix>_top.ppm, _bottom.ppm, _text.txt */
void host_quit(void);
extern int host_se_count, host_bgm_starts;
#endif
