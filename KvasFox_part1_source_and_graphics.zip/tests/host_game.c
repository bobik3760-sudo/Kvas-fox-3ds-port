/* Host harness: runs the real game engine headlessly with scripted input and dumps screenshots. */
#include "../source/game.h"
#include "host.h"
#include <stdio.h>
#include <stdlib.h>

static PInput in;
static void step(uint32_t held)
{
    host_set_held(held);
    plat_begin_frame(&in);
    game_frame(&in);
    plat_end_frame();
}
static void run(int n, uint32_t held) { for (int i = 0; i < n; i++) step(held); }
static void tap_touch(int x, int y) { host_set_touch(true, x, y); step(0); host_set_touch(false, x, y); step(0); }
static void shot(const char *name) { char p[256]; snprintf(p, sizeof p, "tests/out/%s", name); host_dump(p); }

int main(int argc, char **argv)
{
    int mode = argc > 1 ? atoi(argv[1]) : 0;
    host_set_roots("romfs", "tests/hostgfx", "tests/user");
    plat_init();
    if (!game_init()) { fprintf(stderr, "game_init failed\n"); return 1; }
    g_lang = LANG_EN;
    run(5, 0);
    shot("00_title");
    if (mode == 0) {
        tap_touch(160, 40);                 /* New Game button */
        printf("scene after tap: %d (1 = map), map id %d\n", g_scene, M.id);
        run(30, 0);  shot("01_intro_a");
        for (int i = 0; i < 6; i++) { run(40, 0); step(K_A); step(0); }
        shot("02_intro_b");
        printf("player at %d,%d on map %d; interp running=%d msg=%d\n", player.x, player.y, M.id, g_interp.running, msg.active);
    }
    if (mode == 6) {                       /* ending / credits event: must end on the title screen */
        for (int mapId = 43; mapId <= 46; mapId++) {
            char pth[64]; snprintf(pth, sizeof pth, "maps/m%03d.bin", mapId); size_t sz; uint8_t *pr = plat_read_file(pth, &sz); if (!pr) continue; free(pr);
            tap_touch(160, 40); run(2, 0);
            map_unload(); player_reserve_transfer(mapId, 3, 3, 2, 2); player_perform_transfer();
            for (int e = 0; e < M.nev; e++) for (int pg = 0; pg < M.evs[e].npages; pg++) {
                const EvPage *page = &M.evs[e].pages[pg];
                int has354 = 0; for (int i = 0; i < page->ncmd; ) { if (page->cmd[i] == 354) has354 = 1; i += 3 + page->cmd[i + 2]; }
                if (!has354) continue;
                g_scene = SC_MAP; g_interp.running = 0; msg.active = 0; scrolltext.active = 0; g_fade = 0; g_fade_target = 0; g_scene_request = -1;
                interp_setup(&g_interp, page->cmd, page->ncmd, M.evs[e].id);
                int f = 0, sawScroll = 0;
                while (f++ < 12000 && g_scene == SC_MAP) { step((f % 7 == 0) ? K_A : 0); if (scrolltext.active) sawScroll = 1; }
                printf("map %d event %d page %d: ended after %d frames -> scene=%d (0=title) sawScrollText=%d\n", mapId, M.evs[e].id, pg, f, g_scene, sawScroll);
                if (g_scene != SC_TITLE) { g_scene = SC_MAP; }
                shot("30_ending");
            }
        }
        return 0;
    }
    if (mode == 5) {                       /* save / load round trip */
        remove("tests/user/save2.sav");
        tap_touch(160, 40);
        int f = 0; while (f++ < 4000 && !(M.id == 1 && !g_interp.running && !msg.active && g_fade == 0 && f > 400)) step((f % 10) < 2 ? K_A : 0);
        run(40, K_DOWN); run(30, K_RIGHT); run(40, 0);
        g.gold = 1234; g.var[5] = 77; sw_set(9, true); item_gain(0, 1, 3); party_add(3);
        int px = player.x, py = player.y, mapid = M.id, np = g.nparty;
        printf("before save: map %d at %d,%d gold %d var5 %d sw9 %d potions %d party %d\n", mapid, px, py, g.gold, g.var[5], sw_get(9), g.items[1], np);
        printf("save_write: %d\n", save_write(1));
        char info[128]; save_info(1, info, sizeof info); printf("slot info: '%s'\n", info);
        g_scene_request = SC_TITLE; run(3, 0);
        printf("back at title: scene=%d\n", g_scene);
        shot("20_title_with_save");
        tap_touch(160, 92);             /* Continue */
        run(2, 0); shot("21_continue_slots");
        tap_touch(160, 85);             /* slot 2 (row 2) */
        run(5, 0); shot("22_loaded");
        printf("after load: scene=%d map %d at %d,%d gold %d var5 %d sw9 %d potions %d party %d\n", g_scene, M.id, player.x, player.y, g.gold, g.var[5], sw_get(9), g.items[1], g.nparty);
        int ok = (g_scene == SC_MAP && M.id == mapid && player.x == px && player.y == py && g.gold == 1234 && g.var[5] == 77 && sw_get(9) && g.items[1] == 3 && g.nparty == np);
        printf("ROUNDTRIP %s\n", ok ? "PASSED" : "FAILED");
        g_lang = LANG_RU; run(3, 0); shot("23_russian_hud");
        return !ok;
    }
    if (mode == 4) {                       /* run every event page of every map through the interpreter */
        int pages_run = 0, stuck = 0, nmaps = 0;
        srand(7);
        int startMap = argc > 2 ? atoi(argv[2]) : 1;
        int endMap = argc > 3 ? atoi(argv[3]) : 59;
        for (int mapId = startMap; mapId <= endMap; mapId++) {
            char pth[64]; snprintf(pth, sizeof pth, "maps/m%03d.bin", mapId);
            size_t sz; uint8_t *probe = plat_read_file(pth, &sz); if (!probe) continue; free(probe);
            tap_touch(160, 40); run(2, 0);
            nmaps++;
            map_unload(); player_reserve_transfer(mapId, 1, 1, 2, 2); player_perform_transfer();
            party_add(2); party_add(3); party_add(4);
            int ne = g_nevs;
            for (int e = 0; e < ne; e++) {
              if (M.id != mapId) { map_unload(); player_reserve_transfer(mapId, 1, 1, 2, 2); player_perform_transfer(); }
              int np = M.evs[e].npages;
              for (int pg = 0; pg < np; pg++) {
                if (M.id != mapId) { map_unload(); player_reserve_transfer(mapId, 1, 1, 2, 2); player_perform_transfer(); }
                const EvPage *page = &M.evs[e].pages[pg];
                if (page->ncmd <= 3) continue;
                g_scene = SC_MAP; g_interp.running = 0; msg.active = 0; scrolltext.active = 0; pics_clear();
                g_fade = 0; g_fade_target = 0; g_battle_request = 0; g_scene_request = -1; player_reserve_transfer(-1, 0, 0, 0, 0);
                int evid = M.evs[e].id;
                interp_setup(&g_interp, page->cmd, page->ncmd, evid);
                int f = 0;
                while (f++ < 500 && (g_interp.running || msg.active || scrolltext.active || g_fade != g_fade_target)) {
                    uint32_t held = (f % 3 == 0) ? K_A : 0; if (f % 17 == 0) held |= (rand() % 2) ? K_DOWN : K_UP;
                    step(held);
                    if (g_battle_request) { g_battle_result = rand() % 3 == 0 ? 1 : 0; g_battle_request = 0; }
                    if (g_scene_request >= 0) { g_scene = SC_MAP; g_scene_request = -1; g_interp.running = 0; }
                    if (g_scene == SC_BATTLE) { g_scene = SC_MAP; g_battle_result = 0; }
                    if (player_transfer_pending() && g_fade >= 255) { player_reserve_transfer(-1, 0, 0, 0, 0); g_fade = 0; g_fade_target = 0; }
                    if (g_scene != SC_MAP) g_scene = SC_MAP;
                }
                pages_run++;
                if (f >= 500) { stuck++; printf("STUCK? map %d event %d page %d (running=%d waitMode=%d waitArg=%d waitCount=%d pc=%d/%d)\n", mapId, evid, pg, g_interp.running, g_interp.waitMode, g_interp.waitArg, g_interp.waitCount, g_interp.pc, g_interp.n); }
              }
            }
            printf("map %d done (%d events)\n", mapId, ne); fflush(stdout);
        }
        printf("ALL DONE: %d maps, %d pages executed, %d stuck\n", nmaps, pages_run, stuck);
        return 0;
    }
    if (mode == 3) {                       /* battle test over all troops */
        int only = argc > 2 ? atoi(argv[2]) : 0;
        for (int troop = 1; troop < db.ntroops; troop++) {
            if (only && troop != only) continue;
            tap_touch(160, 40); run(2, 0);
            map_unload(); player_reserve_transfer(6, 25, 25, 2, 2); player_perform_transfer();
            g_interp.running = 0; msg.active = 0; pics_clear(); g_fade = 0; g_fade_target = 0;
            party_add(2); party_add(3); party_add(4);
            for (int i = 0; i < g.nparty; i++) b_recover_all(party_member(i));
            g_scene = SC_MAP; g_battle_request = troop; g_battle_can_escape = 1; g_battle_can_lose = 1; g_battle_result = -1;
            int f = 0, shots = 0;
            while (f++ < 9000) {
                if (g_scene == SC_BATTLE) {
                    int ph = f % 60;
                    if (ph == 0) tap_touch(80, 185);                     /* Fight / Attack */
                    else if (ph == 20) tap_touch(80, 170);               /* Attack in actor menu */
                    else if (ph == 30) tap_touch(100, 60);               /* first target */
                    else step(f % 7 == 0 ? K_A : 0);
                } else step(f % 5 == 0 ? K_A : 0);
                if (g_scene == SC_BATTLE && shots < 3 && f % 400 == 399) { char n[64]; snprintf(n, sizeof n, "b%d_%d", troop, shots++); shot(n); }
                if (g_battle_result >= 0 && g_scene != SC_BATTLE) break;
                if (g_scene == SC_GAMEOVER || g_scene == SC_TITLE) break;
            }
            printf("troop %d: result=%d frames=%d scene=%d gold=%d lvl(lead)=%d hp(lead)=%d\n", troop, g_battle_result, f, g_scene, g.gold, party_member(0)->level, party_member(0)->hp);
            if (g_scene != SC_MAP) { game_set_scene(SC_TITLE); }
            g_battle_result = -1;
        }
        return 0;
    }
    if (mode == 2) {                       /* exploration + menus */
        tap_touch(160, 40);
        int f = 0;
        while (f++ < 4000 && !(M.id == 1 && !g_interp.running && !msg.active && g_fade == 0 && g_fade_target == 0 && f > 400)) { step((f % 10) < 2 ? K_A : 0); }
        printf("control at map %d (%d,%d) frame %d leader=%s party=%d\n", M.id, player.x, player.y, f, b_name(party_member(0)), g.nparty);
        run(30, 0); shot("10_free");
        run(40, K_DOWN); run(30, K_RIGHT); shot("11_walked");
        run(40, 0); printf("after walking: %d,%d\n", player.x, player.y);
        tap_touch(43, 185);  run(3, 0); shot("12_items");           /* Items button */
        step(K_B); run(2, 0);
        tap_touch(280, 185); run(3, 0); shot("13_status_actor");     /* Status button */
        tap_touch(100, 56);  run(3, 0); shot("14_status");
        step(K_B); step(K_B); run(2, 0);
        tap_touch(201, 185); run(3, 0); tap_touch(100, 56); run(3, 0); shot("14b_equip_slots"); tap_touch(100, 56); run(3, 0); shot("14c_equip_items");
        step(K_B); step(K_B); step(K_B); run(3, 0);
        tap_touch(43, 221);  run(3, 0); shot("15_save");             /* Save button */
        tap_touch(100, 60);  run(3, 0); printf("save slot1 ok: %d\n", save_info(0, NULL, 0));
        run(3, 0); shot("16_after_save");
        g_lang = LANG_RU; run(3, 0); shot("17_russian");
        printf("lang=%d\n", g_lang);
    }
    if (mode == 1) {                       /* monkey test: mash A, wander randomly */
        int frames = argc > 2 ? atoi(argv[2]) : 20000; unsigned seed = argc > 3 ? (unsigned)atoi(argv[3]) : 1;
        srand(seed);
        tap_touch(160, 40);
        uint32_t dir = 0; int lastMap = -1, lastScene = -1, nmsg = 0, nbattle = 0, shots = 0; int visited[64] = {0};
        for (int f = 0; f < frames; f++) {
            if (f % 25 == 0) { int r = rand() % 6; dir = r == 0 ? K_UP : r == 1 ? K_DOWN : r == 2 ? K_LEFT : r == 3 ? K_RIGHT : 0; }
            uint32_t held = dir | ((f % 12 < 2) ? K_A : 0) | ((f / 500) % 3 == 0 ? K_Y : 0);
            if (g_scene == SC_BATTLE && (rand() % 4 == 0)) held |= K_A;
            if (g_scene == SC_BATTLE && (f % 40 == 0)) { host_set_touch(true, 60 + rand() % 200, 150 + rand() % 80); step(0); host_set_touch(false, 0, 0); }
            step(held);
            if (g_scene != lastScene) { printf("frame %d: scene %d (map %d)\n", f, g_scene, M.id); lastScene = g_scene; if (g_scene == SC_BATTLE) nbattle++; }
            if (g_scene == SC_MAP && M.id != lastMap) { printf("frame %d: now on map %d at %d,%d party=%d gold=%d\n", f, M.id, player.x, player.y, g.nparty, g.gold); lastMap = M.id; if (M.id < 64) visited[M.id] = 1; }
            if (msg.active && shots < 6 && f > 300 && f % 97 == 0) { char n[64]; snprintf(n, sizeof n, "monkey_msg%d", shots++); shot(n); }
            if (g_scene == SC_BATTLE && nbattle <= 2 && f % 150 == 0) { char n[64]; snprintf(n, sizeof n, "monkey_battle_%d_%d", nbattle, f); shot(n); }
            if (g_scene == SC_TITLE && f > 200) { tap_touch(160, 40); }
            if (g_scene == SC_GAMEOVER) step(K_A);
            if (!plat_running()) break;
        }
        int nv = 0; for (int i = 0; i < 64; i++) nv += visited[i];
        printf("DONE: %d frames, %d distinct maps, %d battles, gold %d\n", frames, nv, nbattle, g.gold);
    }
    return 0;
}
