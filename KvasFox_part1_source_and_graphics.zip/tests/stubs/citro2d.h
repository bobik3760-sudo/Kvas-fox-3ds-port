/* API-shape stub of citro2d/citro3d/tex3ds (only what platform_3ds.c uses) */
#ifndef STUB_C2D_H
#define STUB_C2D_H
#include "3ds.h"
#include <stdio.h>
typedef struct { void *data; union { u32 dim; struct { u16 height; u16 width; }; }; } C3D_Tex;
typedef struct C3D_RenderTarget C3D_RenderTarget;
typedef struct Tex3DS_TextureS *Tex3DS_Texture;
typedef struct { u16 width, height; float left, top, right, bottom; } Tex3DS_SubTexture;
typedef struct { C3D_Tex *tex; const Tex3DS_SubTexture *subtex; } C2D_Image;
typedef struct { u32 corners[4]; } C2D_ImageTint;
typedef struct C2D_TextBuf_s *C2D_TextBuf;
typedef struct { C2D_TextBuf buf; } C2D_Text;
typedef struct C3D_TexCube C3D_TexCube;
enum { GFX_TOP, GFX_BOTTOM }; enum { GFX_LEFT, GFX_RIGHT };
enum { GPU_NEAREST, GPU_LINEAR }; enum { GPU_CLAMP_TO_EDGE };
#define C3D_DEFAULT_CMDBUF_SIZE 0x40000
#define C3D_FRAME_SYNCDRAW 1
#define C2D_WithColor 1
#define C2D_Color32(r, g, b, a) ((u32)((r) | ((g) << 8) | ((b) << 16) | ((a) << 24)))
bool C3D_Init(size_t s); void C3D_Fini(void); bool C2D_Init(size_t m); void C2D_Prepare(void); void C2D_Fini(void);
C3D_RenderTarget *C2D_CreateScreenTarget(int screen, int side);
bool C3D_FrameBegin(u8 f); void C3D_FrameEnd(u8 f);
void C2D_TargetClear(C3D_RenderTarget *t, u32 c); void C2D_SceneBegin(C3D_RenderTarget *t);
C2D_TextBuf C2D_TextBufNew(size_t n); void C2D_TextBufClear(C2D_TextBuf b); void C2D_TextBufDelete(C2D_TextBuf b);
const char *C2D_TextParse(C2D_Text *t, C2D_TextBuf b, const char *s); void C2D_TextOptimize(const C2D_Text *t);
void C2D_DrawText(const C2D_Text *t, u32 flags, float x, float y, float z, float sx, float sy, ...);
void C2D_TextGetDimensions(const C2D_Text *t, float sx, float sy, float *w, float *h);
bool C2D_DrawRectSolid(float x, float y, float z, float w, float h, u32 c);
bool C2D_DrawImageAt(C2D_Image img, float x, float y, float d, const C2D_ImageTint *tint, float sx, float sy);
void C2D_AlphaImageTint(C2D_ImageTint *t, float a);
Tex3DS_Texture Tex3DS_TextureImportStdio(FILE *f, C3D_Tex *tex, C3D_TexCube *cube, bool vram);
void Tex3DS_TextureFree(Tex3DS_Texture t);
void C3D_TexSetFilter(C3D_Tex *t, int mag, int min); void C3D_TexSetWrap(C3D_Tex *t, int u, int v); void C3D_TexDelete(C3D_Tex *t);
#endif
