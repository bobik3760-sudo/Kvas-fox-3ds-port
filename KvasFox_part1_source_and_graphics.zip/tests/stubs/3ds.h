/* API-shape stub of libctru (only what platform_3ds.c uses) - for syntax checking on a PC */
#ifndef STUB_3DS_H
#define STUB_3DS_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef int32_t Result;
#define R_FAILED(res) ((res) < 0)
enum { KEY_A = 1, KEY_B = 2, KEY_SELECT = 4, KEY_START = 8, KEY_DRIGHT = 16, KEY_DLEFT = 32, KEY_DUP = 64, KEY_DDOWN = 128,
       KEY_R = 256, KEY_L = 512, KEY_X = 1024, KEY_Y = 2048, KEY_ZL = 4096, KEY_ZR = 8192, KEY_TOUCH = 1 << 20,
       KEY_CPAD_RIGHT = 1u << 28, KEY_CPAD_LEFT = 1u << 29, KEY_CPAD_UP = 1u << 30, KEY_CPAD_DOWN = 1u << 31 };
typedef struct { u16 px, py; } touchPosition;
void hidScanInput(void); u32 hidKeysDown(void); u32 hidKeysHeld(void); u32 hidKeysUp(void); void hidTouchRead(touchPosition *t);
bool aptMainLoop(void);
Result romfsInit(void); Result romfsExit(void);
void gfxInitDefault(void); void gfxExit(void);
void osSetSpeedupEnable(bool e);
void *linearAlloc(size_t s); void linearFree(void *p);
void DSP_FlushDataCache(const void *a, u32 s);
enum { NDSP_OUTPUT_STEREO = 1 }; enum { NDSP_INTERP_LINEAR = 1 }; enum { NDSP_FORMAT_MONO_PCM16 = 1 };
enum { NDSP_WBUF_FREE = 0, NDSP_WBUF_QUEUED, NDSP_WBUF_PLAYING, NDSP_WBUF_DONE };
typedef struct { union { int16_t *data_pcm16; const void *data_vaddr; }; u32 nsamples; void *adpcm_data; u32 offset; bool looping; u8 status; u16 sequence_id; } ndspWaveBuf;
Result ndspInit(void); void ndspExit(void); void ndspSetOutputMode(int m);
void ndspChnReset(int c); void ndspChnSetInterp(int c, int i); void ndspChnSetRate(int c, float r); void ndspChnSetFormat(int c, u16 f);
void ndspChnSetMix(int c, float mix[12]); void ndspChnWaveBufAdd(int c, ndspWaveBuf *w); void ndspChnWaveBufClear(int c);
#endif
