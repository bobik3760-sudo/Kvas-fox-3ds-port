import struct, sys, numpy as np
from PIL import Image
mid=int(sys.argv[1]); out=sys.argv[2]
d=open(f'romfs/maps/m{mid:03d}.bin','rb').read()
ints=np.frombuffer(d,dtype='<i4')
p=0
def nxt():
    global p; v=int(ints[p]); p+=1; return v
assert nxt()==0x4D415031
w=nxt();h=nxt()
bgm,vol,bgs,dn,nodash,over=[nxt() for _ in range(6)]
npg=nxt(); pages=[(nxt(),nxt(),nxt(),nxt()) for _ in range(npg)]
def blob():
    global p
    n=nxt(); b=ints[p:p+(n+3)//4].tobytes()[:n]; p+=(n+3)//4; return b
lower=np.frombuffer(blob(),'<u2');upper=np.frombuffer(blob(),'<u2');ps=np.frombuffer(blob(),'u1')
assert nxt()==0x5EC70001
atl=[Image.open(f'gfx_src/t{mid:03d}_{i}.png') for i in range(npg)]
def tile(v):
    n=v-1;k=0
    for pi,(pw,ph,cols,cap) in enumerate(pages):
        if n<k+cap:
            s=n-k;return atl[pi].crop(((s%cols)*24,(s//cols)*24,(s%cols)*24+24,(s//cols)*24+24))
        k+=cap
img=Image.new('RGBA',(w*24,h*24),(40,40,60,255))
for lay in (lower,upper):
    for y in range(h):
        for x in range(w):
            v=int(lay[y*w+x])
            if v: img.alpha_composite(tile(v),(x*24,y*24))
# passability overlay: red = impassable all dirs
from PIL import ImageDraw
dr=ImageDraw.Draw(img,'RGBA')
for y in range(h):
    for x in range(w):
        if ps[y*w+x]&0xF==0: dr.rectangle((x*24,y*24,x*24+23,y*24+23),fill=(255,0,0,60))
img.convert('RGB').save(out); print(mid,w,h,img.size)
