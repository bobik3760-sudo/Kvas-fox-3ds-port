#include "../source/game.h"
#include "host.h"
#include <stdio.h>
int ima_decode_block(const uint8_t *blk, int blockAlign, int16_t *out);
GameState g_dummy;
int main(int argc, char **argv)
{   /* decode a.ima fully and write raw pcm for comparison with ffmpeg */
    FILE *f = fopen(argv[1], "rb"); uint8_t hd[24]; fread(hd, 1, 24, f);
    uint32_t v[5]; memcpy(v, hd + 4, 20); int ba = v[1];
    uint8_t blk[8192]; int16_t out[8200]; FILE *o = fopen(argv[2], "wb"); long total = 0;
    uint32_t read = 0;
    while (read + ba <= v[4] && fread(blk, 1, ba, f) == (size_t)ba) { int n = ima_decode_block(blk, ba, out); fwrite(out, 2, n, o); total += n; read += ba; }
    fclose(o); printf("decoded %ld samples (header says %u)\n", total, v[3]); return 0;
}
int g_needs_refresh; void game_refresh_followers(void) {}
