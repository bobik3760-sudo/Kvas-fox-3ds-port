/* main_3ds.c - BARE TEST build (no game code).
 * Runs one plain system action per step and waits for A, to find which one makes the console show
 * "The SD card was removed".  Delete KvasFox_part5_baretest.zip from the repo to get the game back. */
#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

static bool s_quit;

static void wait_a(const char *next)
{
    if (s_quit) return;
    printf("\n>> NEXT: %s\n   A = run it, START = quit\n", next);
    while (aptMainLoop()) {
        hidScanInput();
        u32 k = hidKeysDown();
        if (k & KEY_START) { s_quit = true; return; }
        if (k & KEY_A) return;
        gfxFlushBuffers(); gfxSwapBuffers(); gspWaitForVBlank();
    }
    s_quit = true;
}

int main(int argc, char **argv)
{
    (void)argc; (void)argv;
    bool romfs_ok = false;

    gfxInitDefault();
    consoleInit(GFX_TOP, NULL);
    printf("Kvas Fox BARE TEST (no game code)\n");
    printf("If you can read this, the app itself started fine.\n");

    wait_a("1: open the game files (romfsInit)");
    if (!s_quit) {
        Result rc = romfsInit();
        romfs_ok = R_SUCCEEDED(rc);
        printf("   romfsInit = %08lX (0 = OK)\n", (unsigned long)rc);
    }

    wait_a("2: write + read a small file on the SD card");
    if (!s_quit) {
        static unsigned char buf[4096];
        mkdir("sdmc:/3ds", 0777);
        mkdir("sdmc:/3ds/KvasFox", 0777);
        errno = 0;
        FILE *f = fopen("sdmc:/3ds/KvasFox/test.bin", "wb");
        if (!f) printf("   cannot create the file (errno %d)\n", errno);
        else {
            memset(buf, 0x5A, sizeof buf);
            size_t w = fwrite(buf, 1, sizeof buf, f);
            fclose(f);
            printf("   wrote %u bytes\n", (unsigned)w);
            f = fopen("sdmc:/3ds/KvasFox/test.bin", "rb");
            size_t r = f ? fread(buf, 1, sizeof buf, f) : 0;
            if (f) fclose(f);
            printf("   read back %u bytes\n", (unsigned)r);
        }
    }

    wait_a("3: read a 7 MB music file from the game files");
    if (!s_quit) {
        if (!romfs_ok) printf("   skipped (romfs not open)\n");
        else {
            static unsigned char big[65536];
            errno = 0;
            FILE *f = fopen("romfs:/audio/a050.ima", "rb");
            if (!f) printf("   cannot open it (errno %d)\n", errno);
            else {
                size_t total = 0, n;
                while ((n = fread(big, 1, sizeof big, f)) > 0) total += n;
                fclose(f);
                printf("   read %u bytes (expected 7449624)\n", (unsigned)total);
            }
        }
    }

    wait_a("4: start sound (NDSP)");
    if (!s_quit) {
        Result rc = ndspInit();
        printf("   ndspInit = %08lX (0 = OK; anything else just means silent)\n", (unsigned long)rc);
        if (R_SUCCEEDED(rc)) ndspExit();
    }

    wait_a("5: start the graphics engine (citro3d/citro2d)");
    if (!s_quit) {
        gfxExit();
        gfxInitDefault();                      /* leave console mode */
        C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
        C2D_Init(8192);
        C2D_Prepare();
        C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
        C2D_TextBuf tb = C2D_TextBufNew(1024);
        while (aptMainLoop()) {
            hidScanInput();
            if (hidKeysDown() & KEY_START) break;
            C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
            C2D_TextBufClear(tb);
            C2D_TargetClear(top, C2D_Color32(0, 0, 0, 255));
            C2D_SceneBegin(top);
            C2D_Text t;
            C2D_TextParse(&t, tb, "Graphics OK. Press START to exit.");
            C2D_TextOptimize(&t);
            C2D_DrawText(&t, C2D_WithColor, 10.0f, 100.0f, 0.5f, 0.6f, 0.6f, C2D_Color32(120, 255, 120, 255));
            C3D_FrameEnd(0);
        }
        C2D_TextBufDelete(tb);
        C2D_Fini();
        C3D_Fini();
    }

    if (romfs_ok) romfsExit();
    gfxExit();
    return 0;
}
